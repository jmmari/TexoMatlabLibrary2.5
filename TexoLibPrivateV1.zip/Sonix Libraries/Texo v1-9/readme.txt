Introduction
------------

The following Readme is for the texo SDK, which is created and distributed
by Ultrasonix Medical Corporation. Texo is used to create custom ultrasound
sequences by programming individual scanlines. Once the sequence is run, data
can be acquired.


File Definitions
----------------

/readme.txt			This file.

/doc/texo.chm			Reference Guide.

/bin/common/wd_utils.dll	Driver module.
/bin/d				Debug binaries
/bin/r				Release binaries
/bin/./utx_utils.dll		Utilities library.
/bin/./utx_driver.dll		Electronics interface library.
/bin/./utx_seq.dll		Image programming library.
/bin/./texo.dll			Core library.

/lib/d				Debug library files.
/lib/r				Release library files.
/lib/./texo.lib			Core library. Applications must link to this.

/inc/texo.h			Core programming interface.
/inc/texo_def.h			Parameter definitions.

/dat/probes.lst			Probes definition.
/dat/*.bit			Firmware programs.

/demo/console			Console based demo program.
/demo/elTest			Graphical based transducer element tester.

Usage
-----

- In your program, link with the library 'texo.lib'
- Include the header file 'texo.h' to use the pando class