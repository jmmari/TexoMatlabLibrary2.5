#include "stdafx.h"
#include "elTest.h"
#include "AdvancedDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CElTestApp theApp;

CElementsWnd::CElementsWnd()
{
    m_numElements = 0;
    m_parent = 0;
    m_tested = false;
    m_highlightChannel = false;
    m_channelHighlight = -1;

    SetColorScheme(0);
}

CElementsWnd::~CElementsWnd()
{
}

BEGIN_MESSAGE_MAP(CElementsWnd, CWnd)
	//{{AFX_MSG_MAP(CElementsWnd)
	ON_WM_PAINT()
    ON_WM_LBUTTONUP()
    ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

bool CElementsWnd::Create(CRect r, DWORD style, CAdvancedDlg * parent, UINT id)
{
    bool ret = false;

	m_parent = parent;

    ret = CWnd::Create(0, _T(""), style, r, (CWnd*)parent, id) ? true : false;

    SetTimer(1, 500, 0);

    return ret;
}

void CElementsWnd::SetColorScheme(int scheme)
{
    m_colors[0] = (scheme == 0) ? RGB(255, 0, 0) : RGB(0,   0,   0);
    m_colors[1] = (scheme == 0) ? RGB(200, 0, 0) : RGB(50,  50,  50);
    m_colors[2] = (scheme == 0) ? RGB(100, 0, 0) : RGB(100, 100, 100);
    m_colors[3] = (scheme == 0) ? RGB(0, 100, 0) : RGB(150, 150, 150);
    m_colors[4] = (scheme == 0) ? RGB(0, 200, 0) : RGB(200, 200, 200);
    m_colors[5] = (scheme == 0) ? RGB(0, 255, 0) : RGB(255, 255, 255);
}

void CElementsWnd::OnLButtonUp(UINT, CPoint point)
{
    CRect r;    
    GetClientRect(&r);

    if(m_numElements == 0)
        return;

    int el, elSz = r.Width() / m_numElements;

    el = point.x / elSz;

    m_parent->SetSelectedElement(el);
}

void CElementsWnd::OnTimer(UINT event) 
{
    if(event == 1)
    {
        m_highlightChannel = m_highlightChannel ? false : true;
        RedrawWindow();
    }
}

void CElementsWnd::OnPaint() 
{
	CPaintDC dc(this);

    CRect r;    
    GetClientRect(&r);

    if(m_numElements == 0)
        return;

    int i, elSz = r.Width() / m_numElements;
    double * elementData = m_parent->GetElementData();
    COLORREF col;

    dc.MoveTo(r.left, r.top);
    dc.LineTo(m_numElements * elSz, r.top);
    dc.MoveTo(r.left, r.bottom - 1);
    dc.LineTo(m_numElements * elSz, r.bottom - 1);

    for(i = 0; i < m_numElements + 1; i++)
    {
        dc.MoveTo(i * elSz, r.top);
        dc.LineTo(i * elSz, r.bottom);
        
        col = RGB(127, 127, 127);
        if(m_tested && i < m_numElements)
        {
            if(elementData[i]      < 0.10)
                col = m_colors[0];
            else if(elementData[i] < 0.25)
                col = m_colors[1];
            else if(elementData[i] < 0.50)
                col = m_colors[2];
            else if(elementData[i] < 0.75)
                col = m_colors[3];
            else if(elementData[i] < 0.95)
                col = m_colors[4];
            else
                col = m_colors[5];
        }

        // highlight channels if specified
        if(m_highlightChannel && (i % 32) == m_channelHighlight)
            col = RGB(255, 255, 0);

        if(i < m_numElements)
            dc.FillSolidRect(i * elSz + 1, r.top + 1, elSz, r.Height() - 2, col);
    }
}

CAdvancedDlg::CAdvancedDlg(texo * tex, CWnd* pParent) : CDialog(CAdvancedDlg::IDD, pParent)
{
    int i;

	//{{AFX_DATA_INIT(CAdvancedDlg)
	c_probe = -1;	
	c_selectedElement = _T("");
	c_channelFailures = _T("");
	c_colorscheme = 0;
	//}}AFX_DATA_INIT

    m_texo = tex;
    
    for(i = 0; i < MAXELEMENTS; i++)
        m_elementData[i] = 0.0;
}

void CAdvancedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvancedDlg)
	DDX_Control(pDX, IDC_HIGHLIGHTCHANNEL, c_channelHighlight);
	DDX_Radio(pDX, IDC_PROBE1, c_probe);	
	DDX_Text(pDX, IDC_SELECTSIGNAL, c_selectedElement);
	DDX_Text(pDX, IDC_CHANNELFAILURES, c_channelFailures);
	DDX_Radio(pDX, IDC_COLOR1, c_colorscheme);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAdvancedDlg, CDialog)
	//{{AFX_MSG_MAP(CAdvancedDlg)
	ON_BN_CLICKED(IDC_PROBE1, OnSelectProbe)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_CBN_SELCHANGE(IDC_HIGHLIGHTCHANNEL, OnSelectChannelHighlight)
	ON_BN_CLICKED(IDC_COLOR1, OnColorScheme)
	ON_BN_CLICKED(IDC_COPY, OnCopy)
	ON_BN_CLICKED(IDC_PROBE2, OnSelectProbe)
	ON_BN_CLICKED(IDC_PROBE3, OnSelectProbe)
	ON_BN_CLICKED(IDC_COLOR2, OnColorScheme)
	ON_BN_CLICKED(IDC_WORD, OnWord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAdvancedDlg::OnInitDialog() 
{
    int i;
    CString str;

	CDialog::OnInitDialog();
	
    CWnd *img = GetDlgItem(IDC_ELEMENTS);

    CRect r;
	img->GetWindowRect(&r);
	ScreenToClient(&r);

    if(!m_elements.Create(r, WS_VISIBLE, this, 0))
        return FALSE;

    theApp.LoadProbes(this);
	
    c_channelHighlight.AddString(_T("None"));
    for(i = 0; i < NUMCHANNELS; i++)
    {
        str.Format(_T("%d"), i);
        c_channelHighlight.AddString(str);
    }

    c_channelHighlight.SetCurSel(0);

	return TRUE;
}

void CAdvancedDlg::Reset()
{
    c_selectedElement = _T("");
    c_channelFailures = _T("");
    UpdateData(FALSE);

    m_elements.SetTested(false);
    m_elements.SetNumElements(m_texo->getProbeNumElements());
    
    m_elements.RedrawWindow();
}

void CAdvancedDlg::SetSelectedElement(int el)
{
    double v;

    if(m_elements.GetTested() && el >= 0 && el < m_texo->getProbeNumElements())
    {
        // since the data is based on a percentage of the average, don't show the
        // percentage as greater than 100, when it is over the average
        v = m_elementData[el];
        if(v > 1.0)
            v = 1.0;

        c_selectedElement.Format(_T("E%d  C%d  V%.2f"), el, el % NUMCHANNELS, v);
        UpdateData(FALSE);
    }
}

void CAdvancedDlg::OnSelectProbe() 
{
	UpdateData();
    if(c_probe != -1)
        GetDlgItem(IDC_TEST)->EnableWindow(TRUE);

    m_texo->activateProbeConnector(c_probe);

    Reset();
}

void CAdvancedDlg::OnTest() 
{    
    Reset();

    CWaitCursor wc;

    if(!theApp.CreateSequence())
    {
        AfxMessageBox(_T("Error creating sequence"), MB_ICONERROR, 0);
        return;
    }

    m_texo->runImage();
    ::Sleep(2000);
    m_texo->stopImage();
        
    theApp.AnalyzeData(m_elementData);	

    int i, numElements = m_texo->getProbeNumElements();
    unsigned char channelData[NUMCHANNELS];
    memset(channelData, 0, NUMCHANNELS);
    CString str;

    // set failure threshold to 75% of average signal level
    // if probe is PA or has less than 128 elements, then dont do channel analysis
    double failureThreshold = numElements < 128 ? 0.00 : 0.75;
    // set channel threshold failure to 3 or more elements failing on the channel
    int channelFailureThreshold = numElements / NUMCHANNELS;
    
    for(i = 0; i < numElements; i++)
    {
        // check for a failure
        if(m_elementData[i] < failureThreshold)
            channelData[i % NUMCHANNELS]++;        
    }
    
    // update channels which may have failed
    for(i = 0; i < NUMCHANNELS; i++)
    {
        // set a channel failure if X or more elements failed (4 maximum)
        if(channelData[i] >= channelFailureThreshold)
        {
            str.Format(_T("C%d "), i);
            c_channelFailures += str;
        }
    }

    UpdateData(FALSE);

    m_elements.SetTested(true);
    m_elements.RedrawWindow();
}

void CAdvancedDlg::OnSelectChannelHighlight() 
{
    m_elements.SetChannelHighlight(c_channelHighlight.GetCurSel() - 1);
    m_elements.RedrawWindow();
}

void CAdvancedDlg::OnColorScheme() 
{
    UpdateData();
    m_elements.SetColorScheme(c_colorscheme);    
}

void CAdvancedDlg::OnWord() 
{
    Copy(true);

    // Run Word
	ShellExecute(GetSafeHwnd(), _T("open"), _T("winword.exe"), NULL, NULL, SW_SHOWNORMAL);

	Sleep(500);

	// Run the keyboard sequence to paste the image in the document
	keybd_event(VK_CONTROL,0,0,0);
    keybd_event('V',0,0,0);
    keybd_event('V',0,KEYEVENTF_KEYUP,0);
    keybd_event(VK_CONTROL,0,KEYEVENTF_KEYUP,0);
}

void CAdvancedDlg::OnCopy() 
{
    Copy(false);
}

bool CAdvancedDlg::Copy(bool /*rotate*/)
{
    CDC dc;
    CDC * mainDC = GetDC();
    CBitmap bm;

    CRect cr;
    GetClientRect(&cr);

    int w = cr.Width(), h = cr.Height();
    
	dc.CreateCompatibleDC(mainDC);
	bm.CreateCompatibleBitmap(mainDC, w, h);
	dc.SelectObject(&bm);	
	dc.SetBrushOrg(0, 0);
	dc.BitBlt(0, 0, w, h, mainDC, 0, 0, SRCCOPY);
    
    HBITMAP hbm = (HBITMAP)bm.Detach();
    
	OpenClipboard();
	EmptyClipboard();
	SetClipboardData(CF_BITMAP, hbm);
	CloseClipboard();

    return true;
}

bool CAdvancedDlg::CreatePDF()
{
	return Print(_T("PDF995"));
}

bool CAdvancedDlg::SelectPrinter()
{
	CPrintDialog dlg(FALSE, 0);
	
    if(dlg.GetDefaults())
		return Print(dlg.GetDeviceName());

    return false;
}

bool CAdvancedDlg::Print(CString device)
{
    return true;
}

