#include "stdafx.h"
#include "elTest.h"
#include "elTestDlg.h"
#include "AdvancedDlg.h"
#include "utils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CElTestApp theApp;

CElTestDlg::CElTestDlg(texo * tex, CWnd* pParent) : CDialog(CElTestDlg::IDD, pParent)
{
    int i;

	//{{AFX_DATA_INIT(CElTestDlg)
	c_probe = -1;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_texo = tex;

    for(i = 0; i < MAXELEMENTS; i++)
        m_elementData[i] = 0.0;
}

void CElTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CElTestDlg)
	DDX_Control(pDX, IDC_RESULTS, c_results);
	DDX_Radio(pDX, IDC_PROBE1, c_probe);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CElTestDlg, CDialog)
	//{{AFX_MSG_MAP(CElTestDlg)
	ON_BN_CLICKED(IDC_PROBE1, OnSelectProbe)
	ON_BN_CLICKED(IDC_QUICKTEST, OnQuickTest)
	ON_BN_CLICKED(IDC_PROBE2, OnSelectProbe)
	ON_BN_CLICKED(IDC_PROBE3, OnSelectProbe)
	ON_BN_CLICKED(IDC_ADVANCED, OnAdvanced)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CElTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

    theApp.LoadProbes(this);

	return TRUE;
}

void CElTestDlg::OnOK() 
{
	CDialog::OnOK();
}

void CElTestDlg::OnAdvanced() 
{
    CAdvancedDlg dlg(m_texo);
    dlg.DoModal();
}

void CElTestDlg::OnSelectProbe()
{
    UpdateData();
    if(c_probe != -1)
        GetDlgItem(IDC_QUICKTEST)->EnableWindow(TRUE);

    m_texo->activateProbeConnector(c_probe);

    c_results.SetWindowText(_T(""));
}

void CElTestDlg::OnQuickTest() 
{
    c_results.SetWindowText(_T(""));

    CWaitCursor wc;

    if(!theApp.CreateSequence())
    {
        AfxMessageBox(_T("Error creating sequence"), MB_ICONERROR, 0);
        return;
    }

    m_texo->runImage();
    ::Sleep(2000);
    m_texo->stopImage();
    
    theApp.AnalyzeData(m_elementData);

    PublishResults();
}

void CElTestDlg::PublishResults()
{
    CString str;
    int i, numElements = m_texo->getProbeNumElements();
    int badcount = 0, besideCount = 0;
    unsigned int result = 0;
    unsigned char channelData[NUMCHANNELS];
    memset(channelData, 0, NUMCHANNELS);
    
    // set failure threshold to 60% of average signal level
    double failureThreshold = (double)AfxGetApp()->GetProfileInt(_T(""), _T("FailThreshold"), 60) / 100.0;
    // set consecutive failed elements before failing test to 3
    int consecutiveThreshold = AfxGetApp()->GetProfileInt(_T(""), _T("ConsecutiveFailed"), 2);
    // set maximum failed elements before failing test to 10%
    double maxFailedThreshold = (double)AfxGetApp()->GetProfileInt(_T(""), _T("MaxFailed"), 10) / 100.0;
    
    // set channel threshold failure to 3 or more elements failing on the channel
    int channelFailureThreshold = 3;
    
    for(i = 0; i < numElements; i++)
    {
        // check for a failure
        if(m_elementData[i] < failureThreshold)
        {
            badcount++;       
            besideCount++;
            channelData[i % NUMCHANNELS]++;
        }
        else
            besideCount = 0;

        // FAIL, if there are X or more elements beside each other that are bad
        if(besideCount >= consecutiveThreshold)
            result |= 0x00000001;
    }

    // FAIL, if more than X% of the elements are bad
    if(badcount >= numElements * maxFailedThreshold)
        result |= 0x00000002;
    
    if(result == 0)
        theApp.AddText(&c_results, "Probe Passed\r\n");
    else
    {
        theApp.AddText(&c_results, "Probe Failed\r\n");

        if(result & 0x00000001)
        {
            str.Format(_T(">= %d consecutive elements failed\r\n"), consecutiveThreshold);
            theApp.AddText(&c_results, str);
        }

        if(result & 0x00000002)
        {
            str.Format(_T(">= %.0f%% of elements failed\r\n"), maxFailedThreshold * 100.0);
            theApp.AddText(&c_results, str);
        }

        // give a result of the channels
        for(i = 0; i < NUMCHANNELS; i++)
        {
            // set a channel failure if X or more elements failed (4 maximum)
            if(channelData[i] >= channelFailureThreshold)
            {
                str.Format(_T("Channel %d failed\r\n"), i);
                theApp.AddText(&c_results, str);
            }
        }
    }    
}