//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by elTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAIN                        102
#define IDC_ADVANCED                    103
#define IDC_TEST                        104
#define IDC_COPY                        105
#define IDC_WORD                        106
#define IDR_MAINFRAME                   128
#define IDD_ADVANCED                    129
#define IDC_PROBE1                      1000
#define IDC_PROBE2                      1001
#define IDC_PROBE3                      1002
#define IDC_RESULTS                     1004
#define IDC_QUICKTEST                   1005
#define IDC_ELEMENTS                    1006
#define IDC_AVGSIGNAL                   1007
#define IDC_SELECTSIGNAL                1008
#define IDC_CHANNELFAILURES             1010
#define IDC_HIGHLIGHTCHANNEL            1011
#define IDC_COLOR1                      1012
#define IDC_COLOR2                      1013
#define IDC_EDIT1                       1014
#define IDC_CUSTOMTEST                  1015
#define IDC_FREQUENCY                   1016
#define IDC_CENTERELEMENT               1017
#define IDC_FOCUSDEPTH                  1018
#define IDC_ACQUISITIONDEPTH            1019
#define IDC_FREQLABEL                   1020
#define IDC_CENTERELEMENTLABEL          1021
#define IDC_FOCDEPTHLABEL               1022
#define IDC_ACQDEPTHLABEL               1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
