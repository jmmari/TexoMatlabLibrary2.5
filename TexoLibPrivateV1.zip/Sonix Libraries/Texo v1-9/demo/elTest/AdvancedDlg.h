#if !defined(AFX_ADVANCEDDLG_H__A09631B1_E5AC_4986_96D7_E44F1C2B2370__INCLUDED_)
#define AFX_ADVANCEDDLG_H__A09631B1_E5AC_4986_96D7_E44F1C2B2370__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

class texo;
class CAdvancedDlg;

class CElementsWnd : public CWnd
{
public:
    CElementsWnd();
    ~CElementsWnd();

    bool Create(CRect r, DWORD style, CAdvancedDlg * parent, UINT id);
    void SetColorScheme(int scheme);

    void SetChannelHighlight(int ch) { m_channelHighlight = ch; }
    void SetNumElements(int numElements) { m_numElements = numElements; }
    void SetTested(bool tested) { m_tested = tested; }
    bool GetTested() { return m_tested; }

protected:
    //{{AFX_MSG(CElementsWnd)
    afx_msg void OnPaint();
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnTimer(UINT event);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

    int m_numElements;
    int m_channelHighlight;
    CAdvancedDlg * m_parent;
    bool m_tested;
    bool m_highlightChannel;
    COLORREF m_colors[6];
};

class CAdvancedDlg : public CDialog
{
public:
	CAdvancedDlg(texo * tex, CWnd* pParent = 0);
    void SetSelectedElement(int el);
    void Reset();
    double * GetElementData() { return m_elementData; }

	//{{AFX_DATA(CAdvancedDlg)
	enum { IDD = IDD_ADVANCED };
	CComboBox	c_channelHighlight;
	int		c_probe;
	CString	c_selectedElement;
	CString	c_channelFailures;
	int		c_colorscheme;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CAdvancedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
    //}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CAdvancedDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectProbe();
	afx_msg void OnTest();
	afx_msg void OnSelectChannelHighlight();
	afx_msg void OnColorScheme();
	afx_msg void OnCopy();
	afx_msg void OnWord();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:    
    bool Copy(bool rotate);
    bool CreatePDF();
    bool SelectPrinter();
    bool Print(CString device);

private:
    texo * m_texo;
    CElementsWnd m_elements;
    double m_elementData[MAXELEMENTS];    
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_ADVANCEDDLG_H__A09631B1_E5AC_4986_96D7_E44F1C2B2370__INCLUDED_)

