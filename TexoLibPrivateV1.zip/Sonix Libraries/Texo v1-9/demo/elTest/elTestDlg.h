#if !defined(AFX_ELTESTDLG_H__0408874A_606A_4D4F_8687_12D1D4595708__INCLUDED_)
#define AFX_ELTESTDLG_H__0408874A_606A_4D4F_8687_12D1D4595708__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

class texo;

class CElTestDlg : public CDialog
{
public:
	CElTestDlg(texo * tex, CWnd* pParent = 0);

	//{{AFX_DATA(CElTestDlg)
	enum { IDD = IDD_MAIN };
	CEdit	c_results;
	int		c_probe;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CElTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	HICON m_hIcon;
    
    //{{AFX_MSG(CElTestDlg)
	virtual BOOL OnInitDialog();	
	virtual void OnOK();
	afx_msg void OnSelectProbe();
	afx_msg void OnQuickTest();
	afx_msg void OnAdvanced();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    void PublishResults();

private:
    texo * m_texo;
    double m_elementData[MAXELEMENTS];
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_ELTESTDLG_H__0408874A_606A_4D4F_8687_12D1D4595708__INCLUDED_)
