#if !defined(AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_)
#define AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"

#include <texo.h>
#include <texo_def.h>

class CElTestApp : public CWinApp
{
public:
	CElTestApp();
    
    void LoadProbes(CDialog * dlg);
    bool CreateSequence();    
    bool AnalyzeData(double * elementData);    
    static bool AddText(CEdit * e, CString s);    
    static HBITMAP GetRotatedBitmap( CDC * sourceDC, int srcW, int srcH, float radians, COLORREF clrBack );

	//{{AFX_VIRTUAL(CElTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CElTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:    
    texo m_texo;
};


//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_)
