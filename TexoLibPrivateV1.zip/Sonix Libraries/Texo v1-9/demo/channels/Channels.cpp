#include "stdafx.h"
#include "Channels.h"
#include "MainDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CChannelsApp, CWinApp)
	//{{AFX_MSG_MAP(CChannelsApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

CChannelsApp::CChannelsApp()
{
}

CChannelsApp theApp;

BOOL CChannelsApp::InitInstance()
{
	AfxEnableControlContainer();
	
    DEVMODE DisplayMode;
   
	if (EnumDisplaySettings(NULL,ENUM_CURRENT_SETTINGS,&DisplayMode))
	{
		if(DisplayMode.dmPelsWidth < 1024 && DisplayMode.dmPelsHeight < 768)
		{
			DisplayMode.dmPelsWidth = 1024;
			DisplayMode.dmPelsHeight = 768;
			DisplayMode.dmBitsPerPel = 32;	  

			ChangeDisplaySettings(&DisplayMode,CDS_FULLSCREEN);			
		}
	}

	CMainDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	
	return FALSE;
}

bool CChannelsApp::AddText(CEdit * e, CString s)
{
	if(!e)
		return false;
	
	// get the string content
	TCHAR *buf = s.GetBuffer(255);

	// append it in the CEdit
	e->SetSel(32767, 32767);
	e->ReplaceSel(buf, s.GetLength());
	
	// release the string buffer
	s.ReleaseBuffer();

    return true;
}


CString strformat(char * str)
{
    CString cstr;
    int i, len = strlen(str);
    
    for(i = 0; i < len; i++) 
        cstr += str[i];

    return cstr;
}