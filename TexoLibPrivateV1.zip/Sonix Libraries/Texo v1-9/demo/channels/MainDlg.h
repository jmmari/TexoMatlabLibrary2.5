#if !defined(AFX_HWTESTDLG_H__B66C1BC7_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
#define AFX_HWTESTDLG_H__B66C1BC7_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif

#include "ChannelsDlg.h"
#include <texo.h>
#include <texo_def.h>

class texo;

class CMainDlg : public CDialog
{
public:
	int DoModal();

	CMainDlg(CWnd* pParent = NULL);

	//{{AFX_DATA(CMainDlg)
	enum { IDD = IDD_HWTEST_DIALOG };
	CEdit	m_log;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	
	HICON m_hIcon;

	//{{AFX_MSG(CMainDlg)
	
	virtual BOOL OnInitDialog();
	afx_msg void OnInitHW();
	afx_msg void OnClose();
	afx_msg void OnReadProbes();
	afx_msg void OnChannelTest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	// texo interface
	texo *m_texo;
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_HWTESTDLG_H__B66C1BC7_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
