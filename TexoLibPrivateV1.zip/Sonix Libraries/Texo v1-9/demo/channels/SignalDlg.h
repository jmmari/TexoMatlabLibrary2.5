#if !defined(AFX_SIGNALDLG_H__B30A6715_D2D5_446D_A16B_4ADB2054E88E__INCLUDED_)
#define AFX_SIGNALDLG_H__B30A6715_D2D5_446D_A16B_4ADB2054E88E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FFTGraphic.h"

class CFFTDlg : public CDialog
{
public:
	CFFTDlg();
	
    bool Create(CWnd *pParent);
    void UpdateFFT(CDWordArray * data);
	
	//{{AFX_DATA(CFFTDlg)
	enum { IDD = IDD_FFTDLG };	
	CSliderCtrl	m_sliderfftoffset;
	CSliderCtrl	m_sliderfftzoom;
	CSliderCtrl	m_sliderfftamplitude;	
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CFFTDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:

	//{{AFX_MSG(CFFTDlg)
	virtual void OnOK();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnDestroy();
	afx_msg void OnCalibrate();	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:	
    CDialog *m_parent;

	CFFTGraphic* CreateFFTGraphicWindow(int);
	CFFTGraphic* m_fftgraphic;
	int m_fftzoompos;
	int m_fftamplitude;
	int	m_fftoffsetpos;	
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_SIGNALDLG_H__B30A6715_D2D5_446D_A16B_4ADB2054E88E__INCLUDED_)
