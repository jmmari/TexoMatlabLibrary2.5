#if !defined(AFX_FFTGRAPHIC_H__F7557529_726A_43A5_96AF_B0C2229715F0__INCLUDED_)
#define AFX_FFTGRAPHIC_H__F7557529_726A_43A5_96AF_B0C2229715F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

class CFFTGraphic : public CWnd
{
public:
	CFFTGraphic();
	virtual ~CFFTGraphic();

	//{{AFX_VIRTUAL(CFFTGraphic)
	//}}AFX_VIRTUAL

public:
	void Calibrate();
	void DrawText(CDC *, CRect);
	void DrawTickMarks(CDC *, CRect);
	void Modulus(double *, double*, int);
	void Process(CDWordArray *);
	void FFT(double *data, int nn, int isign);
	
	int m_zoom;
	int m_offset;
	int m_amplitude;
	double  m_avgcoef;
	bool m_bColor;
	bool m_wantcopy;	
	CDWordArray m_data;	
	double *m_fftdata;
	double *m_fftpreviousdata;
	double *m_calibrationdata;

protected:
	//{{AFX_MSG(CFFTGraphic)
	afx_msg void OnPaint();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnCopybitmap();
	afx_msg void OnChangecolor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_FFTGRAPHIC_H__F7557529_726A_43A5_96AF_B0C2229715F0__INCLUDED_)
