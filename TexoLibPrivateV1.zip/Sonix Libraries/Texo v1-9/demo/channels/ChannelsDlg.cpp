#include "stdafx.h"
#include "Channels.h"
#include "ChannelsDlg.h"
#include <texo.h>
#include <mmsystem.h>

#define NCHANNELSDISPLAYED	32

extern CChannelsApp theApp;
extern CString strformat(char *);

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

unsigned char * CChannelsDialog::m_data = 0;

CChannelsDialog::CChannelsDialog(texo *tex, CWnd* pParent /*=NULL*/)
	:CDialog(CChannelsDialog::IDD, pParent) 
{
	m_running = false;
	m_texo = tex;

	m_amplitude = 1;
	m_channel = NCHANNELSDISPLAYED;
	
	//{{AFX_DATA_INIT(CChannelsDialog)
	c_line = 64;
	c_focusdistance = 30;
	c_filter = FALSE;
	c_angle = 0;
	c_txfreq = 8;
	c_excitation = _T("+-");
	c_power = 15;
	c_gain = 50;
	c_depth = 30;
    c_saveDelay = 0;
	c_txApt = 32;
	c_path = _T("D:\\channels.dat");	
	c_rfDecimation = 1;
    c_zoomall = FALSE;
    c_show64 = FALSE;
    //}}AFX_DATA_INIT
}

void CChannelsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChannelsDialog)
	DDX_Control(pDX, IDC_DATATYPE, c_dataSelection);
	DDX_Control(pDX, IDC_SEQLIST, c_seqList);
	DDX_Control(pDX, IDC_PROBES, c_probeslist);
	DDX_Control(pDX, IDC_SLIDERAMPLITUDE, m_slideramplitude);
	DDX_Control(pDX, IDC_SLIDEROFFSET, m_slideroffset);
	DDX_Control(pDX, IDC_SLIDERZOOM, m_sliderzoom);	
	DDX_Text(pDX, IDC_LINE, c_line);
	DDV_MinMaxInt(pDX, c_line, 0, 127);	
	DDX_Text(pDX, IDC_FOCUSDISTANCE, c_focusdistance);
	DDV_MinMaxInt(pDX, c_focusdistance, 0, 400);
	DDX_Check(pDX, IDC_FILTER, c_filter);	
	DDX_Check(pDX, IDC_ZOOMDELAY, c_zoomall);	
    DDX_Check(pDX, IDC_64CHANNELS, c_show64);
	DDX_Text(pDX, IDC_ANGLE, c_angle);
	DDV_MinMaxInt(pDX, c_angle, -100, 100);
	DDX_Text(pDX, IDC_TXFREQ, c_txfreq);
	DDV_MinMaxInt(pDX, c_txfreq, 1, 20);
	DDX_Text(pDX, IDC_EXSTYLE, c_excitation);
	DDX_Text(pDX, IDC_POWER, c_power);
	DDV_MinMaxInt(pDX, c_power, 0, 15);
	DDX_Text(pDX, IDC_ANALOGGAIN, c_gain);
	DDV_MinMaxInt(pDX, c_gain, 0, 100);
	DDX_Text(pDX, IDC_NSAMPLES, c_depth);
	DDV_MinMaxInt(pDX, c_depth, 5, 200);
	DDX_Text(pDX, IDC_TXAPT, c_txApt);
	DDV_MinMaxInt(pDX, c_txApt, 1, 64);
	DDX_Text(pDX, IDC_PATH, c_path);	
	DDX_Text(pDX, IDC_RFDECIM, c_rfDecimation);
	DDV_MinMaxInt(pDX, c_rfDecimation, 0, 3);
    DDX_Text(pDX, IDC_SAVEDELAY, c_saveDelay);
	DDV_MinMaxInt(pDX, c_saveDelay, 0, 100); 
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CChannelsDialog, CDialog)
	//{{AFX_MSG_MAP(CChannelsDialog)
	ON_BN_CLICKED(IDC_RUN, OnRun)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_ZOOMDELAY, OnUpdateView)
	ON_WM_VSCROLL()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_FILTER, OnApply)	
	ON_CBN_SELCHANGE(IDC_PROBES, OnChangeProbe)
	ON_MESSAGE(WM_CHANNEL_SELECT, OnSignalSelect)
	ON_BN_CLICKED(IDC_SAVE, OnSave)	
	ON_BN_CLICKED(IDC_EXCEL, OnExcel)
	ON_BN_CLICKED(IDC_64CHANNELS, On64Channels)
	ON_BN_CLICKED(IDC_SHOWFFT, OnShowFFT)
	ON_BN_CLICKED(IDC_VIEWDELAY, OnUpdateView)
	ON_CBN_SELCHANGE(IDC_SEQLIST, OnApply)
	ON_BN_CLICKED(IDC_APPLY, OnApply)
	ON_CBN_SELCHANGE(IDC_DATATYPE, OnApply)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CChannelsDialog::DoModal()
{ 
	return CDialog::DoModal();
}

void CChannelsDialog::OnClose()
{
	if(m_running)
		m_texo->stopImage();

	CDialog::OnClose();
}

BOOL CChannelsDialog::OnInitDialog() 
{
	int i;

	CDialog::OnInitDialog();

    m_texo->setCallback(newImageCallback, this);

	LoadSequences();

	// create the data graphic windows
	for(i = 0; i < NCHANNELSDISPLAYED; i++)
		m_channelDisplay[i] = CreateDataGraphicWindow(IDC_USLINEDATA0 + i, i);
	m_globalDisplay = CreateDataGraphicWindow(IDC_USLINEDATAGLOBAL, NCHANNELSDISPLAYED);

	for(i = 0; i < NCHANNELSDISPLAYED; i++)
		m_channelText[i] = (CStatic*) GetDlgItem(IDC_USMINMAX0 + i);
	m_globalText = (CStatic*) GetDlgItem(IDC_USMINMAXGLOBAL);

	OnSignalSelect(m_channel, 0);
	InitSliders();
	
	m_slideramplitude.SetRange(1, 100);
	m_slideramplitude.SetPos(m_amplitude);
	
    // no 64 channels right now
	GetDlgItem(IDC_64CHANNELS)->EnableWindow(FALSE);

    c_dataSelection.AddString(_T("RF (16b)"));
    c_dataSelection.AddString(_T("Envelope (16b)"));
    c_dataSelection.AddString(_T("Envelope (8b)"));
    c_dataSelection.SetCurSel(0);

    if(!LoadProbes())
	{
		AfxMessageBox(_T("No probe connected"));
		SelectProbe(2, 0);
	}
	else
	{
		c_probeslist.SetCurSel(0);
		OnChangeProbe();
    }

	return TRUE;
}

bool CChannelsDialog::newImageCallback(void *, unsigned char * data, int /*frameID*/)
{
    // go past the frame tag
    m_data = data + 4;
	return true;
}

void CALLBACK CChannelsDialog::InvokeUpdateTimer(UINT uID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
    UNUSED_ALWAYS(dw2);
    UNUSED_ALWAYS(dw1);
    UNUSED_ALWAYS(uMsg);
    UNUSED_ALWAYS(uID);
    
	CChannelsDialog *dlg = (CChannelsDialog*)dwUser;
	dlg->UpdateAllChannels();

}

bool CChannelsDialog::UpdateAllChannels()
{	
	if(!m_running)
		return false;

	// set min/max every 3 seconds
	bool setminmax = ((::GetTickCount() - m_lastcalltime) > 3000);
	if (setminmax)
		m_lastcalltime = ::GetTickCount();

	int	i, offset1 = -1, offset2 = -1, numChannels = 32;
	int extraChannelOffset = (c_show64 && numChannels == 64) ? 32 : 0;

	// update all 32 channels
	for(i = 0; i < NCHANNELSDISPLAYED; i++)
	{
		if(m_curveselection == CURVESELECTION_32HFORIGINAL)
		{
			offset1 = (extraChannelOffset + i) * m_numSamples;
			offset2 = -1;
		}
		else if(m_curveselection == CURVESELECTION_32HFDELAYED)
		{
			offset1 = (extraChannelOffset + numChannels + i) * m_numSamples;
			offset2 = -1;
		}
		else if(m_curveselection == CURVESELECTION_32HFBOTH)
		{
			offset1 = (extraChannelOffset + i) * m_numSamples;
			offset2 = (extraChannelOffset + numChannels + i) * m_numSamples;
		}		
		else
		{
			offset1 = -1;
			offset2 = -1;
		}

		ReadUSProcessingDataInGraphic(offset1, offset2, m_channelDisplay[i], setminmax ? m_channelText[i] : NULL, m_numSamples);
		
		if(c_zoomall)
		{
			m_channelDisplay[i]->m_npoints = m_zoom;
			m_channelDisplay[i]->m_offset = m_offset;
		}
		else
			m_channelDisplay[i]->m_offset = 0;
	}
	
	// update the global channel
	if(m_channel == NCHANNELSDISPLAYED)
	{
		offset1 = (numChannels * 2) * m_numSamples;		
		offset2 = -1;
	}
	else
	{
		if(m_curveselection == CURVESELECTION_32HFORIGINAL)
		{
			offset1 = (extraChannelOffset + m_channel) * m_numSamples;
			offset2 = -1;
		}
		else if(m_curveselection == CURVESELECTION_32HFDELAYED)
		{
			offset1 = (numChannels + extraChannelOffset + m_channel) * m_numSamples;
			offset2 = -1;
			
		}
		else if(m_curveselection == CURVESELECTION_32HFBOTH)
		{
			offset1 = (extraChannelOffset + m_channel) * m_numSamples;
			offset2 = (numChannels + extraChannelOffset + m_channel) * m_numSamples;
		}	
	}
	
	ReadUSProcessingDataInGraphic(offset1, offset2, m_globalDisplay, m_globalText, m_numSamples);	

	m_globalDisplay->m_npoints = m_zoom;
	m_globalDisplay->m_offset = m_offset;

    if(m_fftDlg.m_hWnd)
    {
        m_fftDlg.UpdateFFT(&m_globalDisplay->m_data);
    }

	return true;
}

// read 500 words from usdatabase+offset to the data graphic.
void CChannelsDialog::ReadUSProcessingDataInGraphic(int offset1, int offset2, CDataGraphic * dg, CStatic *minmax, int nSamples)
{
    if(!m_data)
        return;

	short * pshort = (short*)m_data;
    unsigned char *pbyte = m_data;
	double amp = (double)m_amplitude / 500.0;
    int i, sel = c_dataSelection.GetCurSel(), 
        min = (sel == 2) ? 0 : -16383, max = (sel == 2) ? 255 : 16384;
        

	// empty the dg->m_data and dg->m_data1 structures
	dg->m_data.RemoveAll();
	dg->m_data1.RemoveAll();
	dg->SetMinMax((int)(min * amp), (int)(max * amp));

	for(i = 0; i < nSamples; i++)
	{
        if(sel == 2)
        {
            if(offset1 >= 0)
			    dg->m_data.Add(pbyte[offset1+i]);
		    if(offset2 >= 0)
			    dg->m_data1.Add(pbyte[offset2+i]);
        }
        else
        {
		    if(offset1 >= 0)
			    dg->m_data.Add(pshort[offset1+i]);
		    if(offset2 >= 0)
			    dg->m_data1.Add(pshort[offset2+i]);
        }
	}	

	// fixed amplitude for readibility	
	dg->m_npoints = nSamples;

	CString	s;

	// if minmax, set min/max value
	if(minmax && dg->m_data.GetSize())
	{		
		int	min, max, v;		
		min = max = dg->m_data.GetAt(0);
		for(i=1; i<dg->m_data.GetSize(); i++)
		{
			v = dg->m_data.GetAt(i);
			if (v & 0x8000) v |= 0xffff8000;
			if (v < min) min = v;
			if (v > max) max = v;
		}
		s.Format(_T("%d/%d/%d"), min, max, max-min);
		minmax->SetWindowText(s);
	}

	// ask for dg update
	dg->InvalidateRect(NULL);
}

// run the scanner
void CChannelsDialog::OnRun() 
{
	Run();
}

// stop the scanner
void CChannelsDialog::OnStop() 
{
	Stop();
}


bool CChannelsDialog::Run()
{
	if(m_running)
		return false;

	if(!createSequence())
		return false;
	
	if(m_texo->runImage())
	{
		m_running = true;
	
		// set the timer, called every 100 ms for graphics updates
		m_lastcalltime = 0;
		m_timerID = timeSetEvent(100, 10, CChannelsDialog::InvokeUpdateTimer, (DWORD)this, TIME_PERIODIC);
		return true;
	}

	return false;
}

bool CChannelsDialog::Stop()
{
	if(!m_running)
		return false;

	if(m_texo->stopImage())
		timeKillEvent(m_timerID);

	m_running = false;
    m_data = 0;
		
	return true;
}

bool CChannelsDialog::createSequence()
{ 
	if(!m_running)
	{
		// build sequence
		if(sequenceSingleChannel())
			return true;
	}

	return false;
}

// transmits and receives across the entire probe to acquire single channel RF data (full transmit still)
bool CChannelsDialog::sequenceSingleChannel()
{
	int i, c;
    texoTransmitParams tx;
    texoReceiveParams rx;
	int numChannels = 32;
	texoDataFormat dataType = rfData;
	int sel = c_dataSelection.GetCurSel();

	if(sel == 0)
		dataType = rfData;
	else if(sel == 1)
		dataType = envNoCompression;
	else if(sel == 2)
		dataType = envData;

	// retrieve the dialog data and create the sequencing object
	UpdateData();

	m_texo->clearTGCs();
	m_texo->addTGC((double)c_gain / 100.0);

	m_texo->setPower(c_power, 15, 15);

	// tell program to initialize for new sequence
	if(!m_texo->beginSequence())
		return false;

    rx.centerElement = c_line * 10;
    rx.angle = c_angle * 1000;
	rx.aperture = numChannels; 
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = c_depth * 1000;
    rx.saveDelay = c_saveDelay * 1000;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = false;
    rx.useManualDelays = false;
    rx.decimation = c_rfDecimation;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;

    tx.centerElement = c_line * 10; 
	tx.angle = c_angle;
    tx.aperture = c_txApt;
    tx.focusDistance = 30000;
    tx.frequency = c_txfreq * 1000 * 1000; 
    strcpy(tx.pulseShape, "");
    for(i = 0; i < c_excitation.GetLength(); i++)
        tx.pulseShape[i] = c_excitation[i];
    tx.pulseShape[i] = '\0';
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;

	m_texo->addReceive(rx);
	rx.applyFocus = true;
	m_texo->addReceive(rx);

	 // 1) loop for 32 shoot/receive, no focus
	 // 2) loop for 32 shoot/receive, with focus
	 // 3) add a line that sums all the channels
    for(i = 0; i <= numChannels * 2; i++)
    {
		if(i == numChannels*2)
		{
			rx.tableIndex = 0;
			rx.channelMask[0] = 0xFFFFFFFF;
			rx.channelMask[1] = 0xFFFFFFFF;
		}
		else
		{
			c = i % numChannels;
			
			rx.tableIndex = (i < numChannels) ? 0 : 1;
			rx.channelMask[0] = (c <  32) ? (1 << c) : 0;
			rx.channelMask[1] = (c >=  32) ? (1 << (c-32)) : 0;
		}
	
        m_numSamples = m_texo->addLine(dataType, tx, rx) / 2;

        if(m_numSamples == -1)
            return false;
	}

	// depending on the focusing mode, create different processings with m_numSamples samples
	m_curveselection = c_seqList.GetItemData(c_seqList.GetCurSel());

	// tell program to finish sequence
	if(m_texo->endSequence() == -1)
		return false;

    InitSliders();

	return true;
}


// called when the user moves the zoom cursor
void CChannelsDialog::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	m_zoom = m_sliderzoom.GetPos();
	m_offset = m_slideroffset.GetPos();
}

// get the rectangle of control #frameID, and create a CDataGraphic
// window object in this rectangle.
CDataGraphic * CChannelsDialog::CreateDataGraphicWindow(int frameID, int index)
{
	CWnd			*cnt = GetDlgItem(frameID);
	CRect			r;

	// retrieve the control's rectangle in local coordinates
	cnt->GetWindowRect(&r);
	ScreenToClient(&r);

	// create a CDataGraphic object in the rectangle r
	CDataGraphic	*dg;
	dg = new CDataGraphic;
	dg->m_index = index;
	dg->m_display.Format(_T("%d"), index);
	dg->Create(NULL, NULL, WS_BORDER | WS_CHILD | WS_VISIBLE, r, this, 0);

	// return the newly created data graphic object
	return dg;
}

void CChannelsDialog::OnUpdateView() 
{	
	UpdateData();	
}

// called when the user moves the amplitude cursor
void CChannelsDialog::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);

	m_amplitude = m_slideramplitude.GetPos();
}

void CChannelsDialog::OnDestroy() 
{
	// stop all DMA transfers
	if(m_running)
		Stop();

	UpdateData();
		
	int i;
	for(i = 0; i < NCHANNELSDISPLAYED; i++)
		delete m_channelDisplay[i];
	
	CDialog::OnDestroy();	
}

void CChannelsDialog::OnApply()
{
	Stop();
	UpdateData();	
	Run();

    InitSliders();
}

void CChannelsDialog::InitSliders()
{
	m_zoom = m_numSamples;
	m_offset = 0;
	m_sliderzoom.SetRange(1, m_numSamples, TRUE);	
	m_sliderzoom.SetPos(m_zoom);	
	m_slideroffset.SetRange(0, m_numSamples, TRUE);
	m_slideroffset.SetPos(m_offset);	
}

void CChannelsDialog::OnChangeProbe() 
{    
	int connector = c_probeslist.GetItemData(c_probeslist.GetCurSel());
    int	probeID = m_texo->getProbeCode(connector);

	Stop();
	SelectProbe(probeID, connector);
	Run();
}

HRESULT CChannelsDialog::OnSignalSelect(WPARAM wParam, LPARAM lParam)
{
    UNUSED_ALWAYS(lParam);

	m_channel = (int)wParam;
	
	if(m_channel >= 0 && m_channel < NCHANNELSDISPLAYED)
		m_globalDisplay->m_display.Format(_T("%d"), m_channel);
	else
		m_globalDisplay->m_display = _T("Sum");

	return 0;
}

bool CChannelsDialog::LoadProbes()
{
	CString msg;
    int i;
	int cct = 0;

    char name[80];
	CString prbName = _T("");
	c_probeslist.ResetContent();

    for(i = 0; i < 3; i++)
    {
        if(m_texo->getProbeName(i, name, 80))    
		{
			prbName = strformat(name);
			c_probeslist.SetItemData(c_probeslist.AddString(prbName), i);
			cct++;
		}

    }
	
	if(cct)
		return true;


	return false;
}

bool CChannelsDialog::SelectProbe(int probeID, int connector)
{
    UpdateData();
    if(probeID != -1)
		m_texo->activateProbeConnector(connector);

	return true;
}

void CChannelsDialog::OnSave() 
{
	UpdateData();
	Save(c_path);
}

void CChannelsDialog::LoadSequences()
{
	c_seqList.ResetContent();

	c_seqList.SetItemData(c_seqList.AddString(_T("Non-delayed RF")), CURVESELECTION_32HFORIGINAL);
	c_seqList.SetItemData(c_seqList.AddString(_T("Delayed RF")), CURVESELECTION_32HFDELAYED);
	c_seqList.SetItemData(c_seqList.AddString(_T("Overlapped RF")), CURVESELECTION_32HFBOTH);	
		
	c_seqList.SetCurSel(0);
	m_curveselection = c_seqList.GetItemData(c_seqList.GetCurSel());
}

bool CChannelsDialog::Save(CString sPath)
{	
	int	i, j, v;
	CString s;
	CStdioFile f;
	FILE *fp;

	fp = _tfopen(sPath, _T("wb+"));
	if(!fp)
		return false;

	for(i = 0; i < NCHANNELSDISPLAYED; i++)
	{
		v = m_channelDisplay[i]->m_data.GetSize();
		fwrite(&v, sizeof(int), 1, fp);
		
		for(j = 0; j < m_channelDisplay[i]->m_data.GetSize(); j++)
		{
			v = m_channelDisplay[i]->m_data.GetAt(j);
			if(v & 0x8000) v |= 0xffff8000;
			fwrite(&v, sizeof(int), 1, fp);
		}
	}

	fclose(fp);

	return true;
}

void CChannelsDialog::OnExcel() 
{
    int i, j, v, size;
    CString s, data;
	
	// Run Excel
	ShellExecute(GetSafeHwnd(), _T("open"), _T("excel.exe"), NULL, NULL, SW_SHOWNORMAL);
    Sleep(500);

    // go through each channel
    for(i = 0; i < NCHANNELSDISPLAYED; i++)
	{
        data.Empty();

		for(j = 0; j < m_channelDisplay[i]->m_data.GetSize(); j++)
		{
			v = m_channelDisplay[i]->m_data.GetAt(j);
			if(v & 0x8000) v |= 0xffff8000;
			s.Format(_T("%d\r\n"), v);
            data += s;
        }
        
        OpenClipboard();
    	EmptyClipboard();
	
	    size = data.GetLength() + 1;
	    HANDLE hData = ::GlobalAlloc(GMEM_MOVEABLE, (size) * sizeof(TCHAR));
	    LPTSTR pData = (LPTSTR)::GlobalLock(hData);
	    ::lstrcpy(pData, data.GetBuffer(size));
	    ::GlobalUnlock(hData);

    #ifdef _UNICODE
	    SetClipboardData(CF_UNICODETEXT, hData);
    #else
	    SetClipboardData(CF_TEXT, hData);
    #endif

	    CloseClipboard();

	    // Run the keyboard sequence to paste the data and create a graph
	    keybd_event(VK_CONTROL,0,0,0);
        keybd_event('V',0,0,0);
        keybd_event('V',0,KEYEVENTF_KEYUP,0);
        keybd_event(VK_CONTROL,0,KEYEVENTF_KEYUP,0);

        keybd_event(VK_RIGHT,0,0,0);
		keybd_event(VK_RIGHT,0,KEYEVENTF_KEYUP,0);
	}	
}

void CChannelsDialog::On64Channels() 
{
	int i;

	UpdateData();

	for(i = 0; i < NCHANNELSDISPLAYED; i++)
		m_channelDisplay[i]->m_display.Format(_T("%d"), c_show64 ? i + 32 : i);	

	if(m_channel >= 0 && m_channel < NCHANNELSDISPLAYED)
		m_globalDisplay->m_display.Format(_T("%d"), c_show64 ? m_channel + 32 : m_channel);
	else
		m_globalDisplay->m_display = _T("Sum");
}

void CChannelsDialog::OnShowFFT() 
{
    if(!m_fftDlg.m_hWnd)
		m_fftDlg.Create(this);	
}
