Introduction
------------

The following Readme is for the pando SDK, which is created and distributed 
by Ultrasonix Medical Corporation. Pando is used to scan convert raw ultrasound
data into an ultrasound image by means of a fast interpolation algorithm.

File Definitions
----------------

/readme.txt			This file.

/doc/pando.chm			Reference Guide.

/bin/d				Debug binaries
/bin/r				Release binaries
/bin/./pando.dll		Core library.

/lib/d				Debug library files.
/lib/r				Release library files.
/lib/./pando.lib		Core library. Applications must link to this.

/inc/pando.h			Main interface.

/demo/console			Console based demo program

Usage
-----

- In your program, link with the library 'pando.lib'
- Include the header file 'pando.h' to use the pando class