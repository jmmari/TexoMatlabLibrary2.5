// pando demonstration program
// Ultrasonix Medical Corporation (2007)
//
// description:     converts pre-scan converted b data into an ultrasound image
//                  given a set of parameters applicable to the raw data
// program type:    console
// inputs:          command line arguments, queried information
// outputs:         image file (optional)

// header files
#include <stdio.h>
#include <string.h>
#ifdef WIN32
    #include <windows.h>
#endif
#include <pando.h>
#include "header.h"

// constants
#define DEFAULT_WIDTH       640
#define DEFAULT_HEIGHT      480
#define DEFAULT_SCALE       350
#define DEFAULT_ORIGINY     -100
#ifndef DATA_PATH
    #define DATA_PATH       "../../dat/"
#endif
#define swap(a,b)           { temp=(a);(a)=(b);(b)=temp; }  

// prototypes
bool getProbe(int probeid, Probe & probe);
void convertImage(const unsigned char * data, int size, unsigned int * cdata);
void invertImage(unsigned int * pData, int w, int h);
bool writeBitmap(char * path, unsigned char * data, int w, int h, int bitdepth);

// program entry point
int main(int argc, char * argv[])
{
    FILE * fp;
    Data hdr;
    Probe prb;
    pando sc;
    int w = DEFAULT_WIDTH, h = DEFAULT_HEIGHT, scale = DEFAULT_SCALE, originy = DEFAULT_ORIGINY, originx = w /2;
    int sz, frhdr;
    char answer;
    unsigned char * data = 0, * image = 0;

    // there must be at least one argument
    if(argc < 2)
    {
        fprintf(stderr, "usage: %s pre-scan-file [output-file]\n", argv[0]);
        return -1;
    }

    // try to open input file
    fp = fopen(argv[1], "rb");
    if(!fp)
    {
        fprintf(stderr, "could not open specified file\n");
        return -1;
    }

    // read file header
    fread(&hdr, sizeof(hdr), 1, fp);

    // ensure file type is pre-scan data
    if(hdr.type != udtBPre)
    {
        fprintf(stderr, "invalid file type\n");
        fclose(fp);
        return -1;
    }
    
    // read frame header
    fread(&frhdr, sizeof(int), 1, fp);
    
    // read pre-scan data
    sz = hdr.w * hdr.h;
    data = new unsigned char[sz];
    fread(data, sz, 1, fp);

    fclose(fp);

    // print raw data information
    printf("pre-scan data information:\n");
    printf("- scanlines: %d\n", hdr.w);
    printf("- samples per line: %d\n", hdr.h);
    printf("- line density: %d\n", hdr.ld);
    printf("- sampling frequency: %d Hz\n", hdr.sf);    
    printf("\n");

    // retreive probe information
    if(!getProbe(hdr.probe, prb))
    {
        fprintf(stderr, "could not load probe with id=%d\n", hdr.probe);
        return -1;
    }

    // print probe information
    printf("probe information:\n");
    printf("- elements: %d\n", prb.elements);
    printf("- pitch: %d\n", prb.pitch);
    printf("- radius: %d\n", prb.radius);
    printf("- angle: %d\n", prb.maxsteerangle);
    printf("\n");

    // print default output settings
    printf("default output settings:\n");
    printf("- output width: %d pixels\n", w);
    printf("- output height: %d pixels\n", h);
    printf("- scale: %d microns-per-pixel\n", scale);
    printf("- origin(x): %d pixels\n", originx);
    printf("- origin(y): %d pixels\n", originy);
    printf("\n");

    // ask user if they want to change settings
    printf("would you like to change the default output settings [y/n] ");
    scanf("%c", &answer);

    if(answer =='y' || answer == 'Y')
    {
        // obtain additional information
        printf("enter image output width: ");
        scanf("%d", &w);
        printf("enter image output height: ");
        scanf("%d", &h);
        printf("enter scaling in microns per pixel: ");
        scanf("%d", &scale);
        printf("enter originx: ");
        scanf("%d", &originx);
        printf("enter originy: ");
        scanf("%d", &originy);
    }
    
    // initialize the scan converter
    if(!sc.init(w, h, hdr.h, hdr.w, 0, hdr.h, 0, hdr.w, hdr.sf, hdr.ld, 0, 0, originx, originy, scale, scale, 
                prb.elements, prb.pitch, prb.radius, prb.maxsteerangle, prb.transmitoffset))
    {
        fprintf(stderr, "could not initialize scan converter\n");
        return -1;
    }

    // try to scan convert
    sz = w * h;
    image = new unsigned char[sz];
    if(!sc.scanConvert(data, image))
    {
        fprintf(stderr, "could not perform scan conversion\n");
        return -1;
    }

    printf("scan conversion was successful\n");

    // save the scan-converted image if output file was provided as an argument
    if(argc > 2)
    {
        if(strstr(argv[2], ".bmp") != 0)
        {            
            if(!writeBitmap(argv[2], image, w, h, 32))
            {
                fprintf(stderr, "could not write bitmap\n");
                return -1;
            }
        }
        else
        {
            fp = fopen(argv[2], "wb+");
            if(!fp)
            {
                fprintf(stderr, "could not open output file for writing\n");
                return -1;
            }

            fwrite(image, sz, 1, fp);
            fclose(fp);
        }

        printf("image storage was successful\n");
    }

    return 0;
}

// looks for probe information inside the probes definition file, given the probe id provided
bool getProbe(int probeid, Probe & probe)
{
    FILE * fp;
    char path[100];

    sprintf(path, "%sprobes.lst", DATA_PATH);
    
    fp = fopen(path, "rb");    
    if(!fp)
        return false;

    while(fread(&probe, sizeof(Probe), 1, fp))
    {
        if(probe.id == probeid)
        {
            fclose(fp);
            return true;
        }
    }

    fclose(fp);
    return false;
}

// converts 8 bit data into 32 bit RGB data
void convertImage(const unsigned char * data, int size, unsigned int * cdata)
{
    int i;
    for(i = 0; i < size; i++)
        cdata[i] = data[i] << 16 | data[i] << 8 | data[i];
}

/// inverts image data, so that the bitmap can be displayed properly
void invertImage(unsigned int * pData, int w, int h)
{
	int x, y, temp;
	unsigned int * p = (unsigned int *)pData;

	// flip the image on the X-axis
	for(y = 0; y < h / 2; y++)
		for(x = 0; x < w; x++)
			swap(p[y * w + x], p[ ((h - 1 - y) * w) + x]);
}

#ifdef WIN32

/// write a bitmap file to a specified location
bool writeBitmap(char * path, unsigned char * data, int w, int h, int bitdepth)
{    

    FILE * fp = fopen(path, "wb");
    if(!fp)
        return false;
 
    unsigned int * cdata = new unsigned int[w * h];
    // convert 8 bit data to 32 bit data
    convertImage(data, w * h, cdata);
    // since the data gets flipped when written to bitmap, pre-flip the image
    invertImage((unsigned int *)cdata, w, h);

    BITMAPINFOHEADER BMIH;
    BMIH.biSize = sizeof(BITMAPINFOHEADER);
    BMIH.biBitCount = (unsigned short)bitdepth;
    BMIH.biPlanes = 1;
    BMIH.biCompression = BI_RGB;
    BMIH.biWidth = w;
    BMIH.biHeight = h;
    BMIH.biSizeImage = ((((BMIH.biWidth * BMIH.biBitCount) + 31) & ~31) >> 3) * BMIH.biHeight;

    BITMAPFILEHEADER bmfh;
    int nBitsOffset = sizeof(BITMAPFILEHEADER) + BMIH.biSize; 
    LONG lImageSize = BMIH.biSizeImage;
    LONG lFileSize = nBitsOffset + lImageSize;
    bmfh.bfType = 'B'+('M'<<8);
    bmfh.bfOffBits = nBitsOffset;
    bmfh.bfSize = lFileSize;
    bmfh.bfReserved1 = bmfh.bfReserved2 = 0;    
    // write the bitmap file header
    fwrite(&bmfh, 1, sizeof(BITMAPFILEHEADER), fp);
    // and then the bitmap info header
    fwrite(&BMIH, 1, sizeof(BITMAPINFOHEADER), fp);    
    // finally, write the image data itself     
    fwrite(cdata, 1, lImageSize, fp);

    fclose(fp);

    return true;
}

#else

// not implemented for non-Windows systems right now
bool writeBitmap(char * path, unsigned char * data, int w, int h, int bitdepth)
{
    porta_error("this function is only available under Windows.");
    return false;
}

#endif
