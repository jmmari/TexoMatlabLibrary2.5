#ifndef __IMPERO_H__
#define __IMPERO_H__

#include "impero_def.h"

#ifdef EXPORT_IMPERO
    #define imperolinkage __declspec(dllexport)
#elif defined IMPORT_IMPERO
    #define imperolinkage __declspec(dllimport)
#else
    #define imperolinkage
#endif

/// The Impero SDK allows users to receive events when the Sonix console buttons are pressed.
class imperolinkage impero
{
    public:
        impero();
        virtual ~impero();

        bool connect(int port);
        bool isConnected() const;
        bool close();
        void setCallback(IMPERO_CALLBACK fn, void * prm);
        void setBacklight(bool status);
        void setAllLEDs(imperoLED state);
        void getTgc(char * tgcval);
};

#endif