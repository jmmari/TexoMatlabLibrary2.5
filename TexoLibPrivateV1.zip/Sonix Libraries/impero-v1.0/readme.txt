Introduction
------------

The following Readme is for the Impero SDK, which is
created and distributed by Ultrasonix Medical Corporation.

Usage
-----

The best method for learning Impero is to compile and run the demo
programs that come included with the package.

File Definitions
----------------

/readme.txt			This file.

/doc/impero.chm			Reference Guide.

/bin/d				Debug binaries
/bin/r				Release binaries
/bin/./impero.dll		Core library.

/lib/d				Debug library files.
/lib/r				Release library files.
/lib/./impero.lib		Core library. Applications must link to this.

/inc/impero.h			Main interface.
/inc/impero_def.h		List of modifiable imaging parameters.

/demo/console			Console based demo program.