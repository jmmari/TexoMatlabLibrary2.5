#include <impero.h>

#include <windows.h>
#include <stdio.h>
#include <conio.h>

void onConsole(imperoEventType type, void * data, int sz, int info, void * prm);

// program entry point
int main() // (int argc, char * argv[])
{
    impero imp;
    int ch, led = imperoLEDOff;
    bool bl = false;
    unsigned char tgc[8];

    // try and connect
    if(imp.connect(1))
    {   
        imp.setBacklight(bl);
        imp.setAllLEDs((imperoLED)led);

        imp.setCallback(onConsole, 0);        

        printf("impero demo:\n");
        printf("gathering console data, press 'X' on the keypad to exit\n");

        imp.getTgc((char *)tgc);
        printf("tgc: {%d,%d,%d,%d,%d,%d,%d,%d}\n", tgc[0], tgc[1], tgc[2], tgc[3], tgc[4], tgc[5], tgc[6], tgc[7]);
    }
    else
    {
        printf("could not connect to console\ncheck the connection, or try another serial port\n");
        return -1;
    }

    // get user input
    do
    {
        ch = _getch();
        ch = toupper(ch);

        switch(ch)
        {
            case 'B':
                imp.setBacklight(!bl); bl = !bl;
                break;
            case 'L':
                if(++led > imperoLEDAll)
                    led = imperoLEDOff;
                imp.setAllLEDs((imperoLED)led);
                break;
        }
    }
    while(ch != 'X');

    return 0;
}

// handles console events
void onConsole(imperoEventType type, void * data, int sz, int info, void * /*prm*/)
{
    unsigned char * tgc;
    unsigned int * btn;
    
    if(type == imperoEventTGC && sz == 8)
    {
        tgc = (unsigned char *)data;
        printf("tgc: {%d,%d,%d,%d,%d,%d,%d,%d}\n", tgc[0], tgc[1], tgc[2], tgc[3], tgc[4], tgc[5], tgc[6], tgc[7]);
    }
    else if(type == imperoEventDial && sz == 4)
    {
        btn = (unsigned int *)data;
        printf("dial #%d turned %d clicks\n", *btn, info);
    }
    else if(type == imperoEventPush && sz == 4)
    {
        btn = (unsigned int *)data;
        if(info)
            printf("button #%d was pressed\n", *btn);
        else
            printf("button #%d was depressed\n", *btn);
    }
}