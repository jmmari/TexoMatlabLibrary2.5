function LPFImg=Apply_Filter(RF,LowFcut,HighFcut,Fs,filterOrder)

Wn = [LowFcut HighFcut]/(Fs/2);
[B,A] = butter(filterOrder,Wn);


w=min(size(RF));
     for i=1:w
         LPFIm(:,i) = filter(B,A,double(RF(:,i)));
     end
LPFImg=LPFIm;
          
