%load a RF image. This BModeReconstruction doesn't do such a great RF-to-BMode conversion, but
%works for demo'ing MucroWrap.
BModeReconstruction
%outputs CmpImg to workspace
intImg = uint8(CmpImg); %not sure if have to do this

%load the MucroWrap dll
addpath(genpath('C:\Documents and Settings\Chandra Sehgal\My Documents\Stauffer\RF reconstruction\Stauffer\MucroWrap\MucroWrap'))
loadlibrary('MucroWrap','MucroWrap.h','mfilename','MucroWrap_mfile');
%list the available funcs, for double-checking
libfunctions('MucroWrap','-full')

%Get path to 'cv.par' settings file, which is a part of the Mucro SDK
%distribution. Assume it in the workspace's path.
p = which('cv.par');
if length(p) == 0
    disp 'ERROR: cv.par not found'; end

%check the Mucro is available, meaning license is correclty loaded and
%dongle is found
res = calllib('MucroWrap','isAvailable');
if res == 0
    disp 'ERROR: Not Available'; end

%Initialize Mucro and check that it succeeded.
res = calllib('MucroWrap','init',p);
if res == 0
    disp 'ERROR: Init failed'; end
res = calllib('MucroWrap','isInitialized');
if res == 0
    disp 'ERROR: Not Init`ed'; end

%Do the image processing
% Should this be w x h OR h x w ???
newImg = intImg;
[res, orig, newImg] = calllib('MucroWrap','apply', intImg, newImg, 480, 640, 50, 0);
if res == 0
    disp 'ERROR: apply failed'; end
colormap('gray');
imagesc(newImg);

%destroy the filter if you want
%calllib('MucroWrap','destroy');