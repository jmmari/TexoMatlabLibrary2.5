This is a simple dll wrapper for the Ultrasonix Mucro SDK, with sample code for use in Matlab.

Matlab should be setup to find:
	- the dll's in the MucroWrap/Release folder.
	- the RF-to-BMode code in Ahmed Mahmoud folder.