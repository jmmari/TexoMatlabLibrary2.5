// MucroWrap
// This is a wrapper for the Ultrasonix Mucro SDK so it can be called
//	from Matlab. 
//	I couldn't figure how to use C++ objects from Matlab via 'calllib' or mex,
//	 so am doing it this way. 
//	It instantiates a single global Mucro object within the DLL
//	 that is used by all the other calls.
//	Individual function calls are created for each member function of the 
//	 Mucro SDK. They each use the global Mucro obj instantiated during init.
//
//NOTE: I first tried using a global pointer to a mucro object that was
//	instantiated when first init'ed. But that gave weird problem when calling
//	'apply' method - the object would disappear afterwards, so am doing now
//	with static global mucro object and it seems fine.
//
//Michael Stauffer, University of Pennsylvania, 2007.
// mstauff@verizon.net
//
#include "stdafx.h"

#include <mucro.h>

#define FUNC_SPEC extern "C" __declspec(dllexport) char __stdcall


//////////////////////////////////////
//Globals
mucro g_mucroObj;

//////////////////////////////////////
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	return TRUE;
}

//////////////////////////////////////

//Create functions for each member function so we can call from matlab
//Instead of returning bool, return a char, with 1 for succes, 0 for fail
//
FUNC_SPEC init(const char * paramfile){
	
	return g_mucroObj.init(paramfile);
}

FUNC_SPEC destroy(){
	return g_mucroObj.destroy();
}

FUNC_SPEC apply(unsigned char * in, unsigned char * out, int w, int h, int param, bool useIndex){
	//From Mucro Help:
	//Adjust the processing level by setting the last two paramters. 
	//Set useIndex to 'true' if choosing a pre-configured filter and 'false' if 
	//using the generic filtering at a 0 - 100 level. 
	//Valid ranges for pre-configured filters are 0 - 20. 
	//The generic filter level is a speed parameter. 
	//Higher levels are faster and have less filtering. 
	//Lower levels are slower but have more filtering applied. 
	//
	return g_mucroObj.apply(in, out, w, h, param, useIndex);
}

FUNC_SPEC setMask(unsigned char * mask, int w, int h){
	return (char)(g_mucroObj.setMask(mask, w, h));
}
FUNC_SPEC removeMask(){
	return (char)(g_mucroObj.removeMask());
}
FUNC_SPEC isMasked(){
	return (char)(g_mucroObj.isMasked());
}

FUNC_SPEC isInitialized(){
	//Retreives the initialized status of the filter.
	return (char)(g_mucroObj.isInitialized());
}

FUNC_SPEC isAvailable(){
	//Returns the availability of the filter by checking if the 
	// dongle and license are installed properly.
	return (char)(g_mucroObj.isAvailable());
}

