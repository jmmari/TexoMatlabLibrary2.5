//
//For including from calling app.
//See .cpp file

#define FUNC_SPEC extern "C" __declspec(dllimport) char __stdcall

FUNC_SPEC init(const char * paramfile);
FUNC_SPEC destroy();
FUNC_SPEC apply(unsigned char * in, unsigned char * out, int w, int h, int param, bool useIndex);

FUNC_SPEC setMask(unsigned char * mask, int w, int h);
FUNC_SPEC removeMask();
FUNC_SPEC isMasked();

FUNC_SPEC isInitialized();
FUNC_SPEC isAvailable();


