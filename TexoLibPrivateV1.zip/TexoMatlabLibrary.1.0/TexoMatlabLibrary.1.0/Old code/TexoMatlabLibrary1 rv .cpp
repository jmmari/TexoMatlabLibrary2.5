// TexoMatlabLibrary.1.0.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#define DLLEXPORT __declspec(dllexport)
//#include "TexoTools.h"
//typedef int (*MYPROC)(LPTSTR); 
//// = new ;= 0
#include "TexoTools.h"
#include <String>

TexoTools * tx = 0;

#ifdef _MANAGED
#pragma managed(push, off)
#endif
/*TexoMatlabLibrary1::TexoMatlabLibrary1()
{

}*/
BOOL APIENTRY DllMain( HMODULE hModule,
					  DWORD  ul_reason_for_call,
					  LPVOID lpReserved
					  )
{
	/*switch( ul_reason_for_call ) {
	case DLL_PROCESS_ATTACH:
		//{TexoTools * tx = 0;}

	case DLL_THREAD_ATTACH:
	//...
	case DLL_THREAD_DETACH:
	//...
	case DLL_PROCESS_DETACH:
		{delete tx;}
	//...
	}/**/

	return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif
/*#ifdef __cplusplus
extern "C" {
#endif/**/
int DLLEXPORT runTexo(char * argv)//std::string input)//[])//int argc, EXPORTED_FUNCTION 
{
	//TexoTools * tx;
	if(!tx)
		tx = new TexoTools;
	int ret = tx->run(argv);
	tx->wait(500);
	//delete tx;
	//	return -3;
	return -8;//ret;//0;
}
//----------------------------------------------------------------------------------
DLLEXPORT char * getSettings(int full)
{
	char * error = " ! System not initialized ! ";
	char answer[4096];
	if(tx)
	{
		strcpy_s(answer, (tx->settingsToString(full)).data());
		return answer;
	}
	else
		return error;
}
//----------------------------------------------------------------------------------
int DLLEXPORT loadConfig()
{
	return tx->loadConfig();
}
//----------------------------------------------------------------------------------
int DLLEXPORT createNormalSequenceFromConfig()
{
	return tx->createNormalSequence();
}
//----------------------------------------------------------------------------------
int DLLEXPORT createNormalSequence(char * flip)
{
	return tx->createNormalSequence(flip);
}
//----------------------------------------------------------------------------------
int DLLEXPORT createFlipFlapSequenceFromConfig()
{
	return tx->createFlipFlapSequence();
}
//----------------------------------------------------------------------------------
int DLLEXPORT createFlipFlapSequence(char * flip, char * flap)
{
	return tx->createFlipFlapSequence(flip, flap);
}
//----------------------------------------------------------------------------------
int DLLEXPORT setConfigFile(const char * argv)
{
	return tx->setConfigFile(argv);
}
//----------------------------------------------------------------------------------
int DLLEXPORT initEngineFromConfig(char * settings)
{
	//if(tx)		return 4;
	if(!tx)
		tx = new TexoTools;
	return tx->initEngine(settings);/**/
	//return 48;
}
//----------------------------------------------------------------------------------
int DLLEXPORT initEngine(char *  settingsPath, int  pci, int  usm, int  hv, int  channels, int  ddr)
{
	if(!tx)
		tx = new TexoTools;
	return tx->initEngine(settingsPath, pci, usm, hv, channels, ddr);
}
//----------------------------------------------------------------------------------
int DLLEXPORT startImaging()
{
	return tx->startImaging();
}
//----------------------------------------------------------------------------------
int DLLEXPORT stopImaging()
{
	return tx->stopImaging();
}
//----------------------------------------------------------------------------------
int DLLEXPORT stopEngine()
{
	int ret = -1;
	try
	{
		ret = tx->stopEngine();
		delete tx;
		return ret;
	}catch(char * str)
	{
		return -5;
	}
}
//----------------------------------------------------------------------------------
int DLLEXPORT saveDataFromConfig()
{
	if(tx)
		return tx->saveData();
	return -1;
}
//----------------------------------------------------------------------------------
int DLLEXPORT saveData(char * fileName, int numberOfFrames)
{
	return tx->saveData(fileName, numberOfFrames);
}
/*#ifdef __cplusplus
}
#endif/**/
