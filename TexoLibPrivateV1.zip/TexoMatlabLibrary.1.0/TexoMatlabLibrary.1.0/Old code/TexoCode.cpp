#include "stdafx.h"

#include <math.h>
#include <string.h>
#include <fstream> 
#include <iostream>
#include <String>
#include <vector>
#include <sys/timeb.h>
#include <time.h>

#ifndef DATA_PATH
#define DATA_PATH   "../../dat/"
#endif


// ***********************************************************************************************
int run(int argc, char * argv[])//, char *envp[])//_TCHAR* argv[])//
{
	scannerPresent = false; // turn to true if running on the scanner !!!!!!!
	std::cout << "\n ____________________________________________________________________________ \n";
	std::cout << "\n Hello! This is the Pulse Inversion program based on Ultrasonix::Texo tools !\n";
	std::cout << "\n  - JMM - University of Oxford - Imperial College London - 11-10-2007 -\n";
	std::cout << "\n Make sure you have a configfile.txt document in command line !\n";
	
	//---------------------------------------------------------------------
	m_texo = new texo;
	storagePath.reserve(1024);
	configData.reserve(4096);
	configPath.reserve(1024);
	storagePath = "";
	configData = "";
	configPath = "";

	if (argv[1] != '\0')// && argc > 1)
	{
		for(int i=1; i<argc; i++)
			configPath.append(argv[i]);//"");//
		//configPath += "   ";
		configPath = trimString(configPath);
	}else
	{
		std::cout << "\n _________________ \n";
		std::cout << "\n No config file specified !\n";
		std::cout << "\n Trying to load default config... \n";
		configPath.append("DefaultConfigFile.txt");//configFile.txt");
	}

	// Initialize parameters:
	inputSignalConfig   = 0;
	outputSignalConfig1 = 0;
	outputSignalConfig2 = 0;

	// init electronics
	if(scannerPresent)
	{
		std::cout << "\n _________________ \n";
		if(!m_texo->init(DATA_PATH, 2, 2, 0, 0, 0))
		{std::cout << "\n Init Failed.\n";wait(shortDelay);return -1;}
		std::cout << "\n Init ok...\n";	
	}
	std::cout << "\n _________________ \n";
	if(!loadConfig()) // Here, the config file is opened ans the parameters read.
	{ 
		if(scannerPresent && m_texo->isInitialized())
		{m_texo->shutdown();}
		std::cout << "\n Config file \'" << configPath << "\' loading failed.\n _________________ \n";
		wait(longDelay);
		return -1;
	}
	std::cout << "\n Config file \'" << configPath << "\' loaded...\n";
	// Sets trigger and synch signals on the BNC output:
	if(scannerPresent)
	{
		m_texo->setSyncSignals(inputSignalConfig, outputSignalConfig1, outputSignalConfig2);//   Configures the I/O signals attached to the BnC connectors.
		//									  Parameters:
		//										[in]  input  The input signal config (0 = none, 1 = line trigger, 2 = frame trigger)  
		//										[in]  output  The output signal config (0 = none, 1 = line sync, 2 = frame sync)  
		//										[in]  output2  The 2nd output signal config (0 = none, 1 = line sync, 2 = frame sync)  

		if(!CreateSequence())//theApp.CreateSequence())
		{std::cout << "\n Sequence creation failed.\n";wait(shortDelay);return -1;}
		std::cout << "\n Sequence created...\n";

		// Perform acquisition :
		m_texo->runImage();
		std::cout << "\n RUNNING...\n";
		std::cout << "\n Time waited : " << wait(acquisitionDuration) << " milliseconds.\n";
		//::Sleep(acquisitionDuration); // was 2000

		m_texo->stopImage();
		std::cout << "\n STOPPED...\n";

		// Save data to file precised in configFile :
		saveData();

		m_texo->shutdown();
		std::cout << " _________________ \n";
		std::cout << "\n Shut down! \n";
		std::cout << " _________________ \n";
		std::cout << "\n Good By! \n";
	}else
	{
		std::cout << " _________________ \n";
		std::cout << "\n No scanner ! \n _________________ \n";
		std::cout << "\n Good By! \n";
		//std::cout << "\n ###################################################################\n";
		//std::cout << configData;
		std::cout << "\n Time waited : " << wait(longDelay) << " milliseconds.\n";
	}
	
	std::cout << " ____________________________________________________________________________ \n";
	return 0;
}
// ***********************************************************************************************
int wait(int delay)
{
	time_t ltime1;
	time_t ltime2;
	time(&ltime1);
	time(&ltime2);

	struct _timeb t1;
	struct _timeb t2;
	struct _timeb * tptr1 = &t1;
	struct _timeb * tptr2 = &t2;

	_ftime_s(tptr1);
	_ftime_s(tptr2);

	while((int)((ltime2-ltime1)*1000 + (int)(tptr2->millitm - tptr1->millitm)) <= delay)// offset is minimum and is for routine execution...
	{
		time(&ltime2);
		_ftime_s(tptr2);
	}

	return ((int)((ltime2-ltime1)*1000) + (int)(tptr2->millitm - tptr1->millitm));
}
// ***********************************************************************************************
std::string trimString(std::string input)
{
	// Remove spaces at the beginning:

	while((int)(input.end()-input.begin()) > 0 && input[0] == 32)
		input.erase(input.begin());//str1_Iter);

	while((int)(input.end()-input.begin()-1) > 0 && input[(int)(input.end()-input.begin())-1] == 32)
		input.erase(input.end()-1);

	return input;
}
// ***********************************************************************************************
bool loadConfig()
{
	bool response = false;
	int i=0;

	std::string temp;
	temp.reserve(128);
	temp = "";

	try{

		if(!getConfigString(configPath)) // call subroutine to fill configString field.
		{return 0;}
		else
		{
			// Here fill parameters from file ---------------------- TODO !!!!!!!!!!!!!!!!

			temp = getToken("InputSignalConfig");//
			inputSignalConfig = atoi(temp.data());//

			// -----------------------------------------------------------------
			temp = getToken("OutputSignalConfig1");//
			outputSignalConfig1 = atoi(temp.data());//

			// -----------------------------------------------------------------
			temp = getToken("OutputSignalConfig2");//
			outputSignalConfig2 = atoi(temp.data());//

			// -----------------------------------------------------------------
			temp = getToken("AcquisitionDuration");//
			acquisitionDuration = atoi(temp.data());//

			// -----------------------------------------------------------------
			std::string power = getToken("Power");//std::string tokenName)
			std::string powerMax = getToken("PowerMax");//std::string tokenName)
			std::string powerMin = getToken("PowerMin");//std::string tokenName)
			response = m_texo->setPower(atoi(power.data()), atoi(powerMax.data()), atoi(powerMin.data()));
			// -----------------------------------------------------------------
			temp = getToken("TGC");//std::string tokenName)
			if(scannerPresent)
				m_texo->addTGC(atof(temp.data()));    

			// -----------------------------------------------------------------
			temp = getToken("ProbeConnector");//std::string tokenName)
			if(scannerPresent)
			{response = m_texo->activateProbeConnector(atoi(temp.data()));}//c_probe);

			// -----------------------------------------------------------------
			temp = getToken("SectorialProbe");//std::string tokenName)
			setorialProbe = atoi(temp.data()); // set here if probe is linear (0) or sectorial (1).

			// -----------------------------------------------------------------
			temp = getToken("numberFramesToSave");
			numberFramesToSave = atoi(temp.data());

			// -----------------------------------------------------------------
			storagePath = getToken("dataFileName");
			storagePath = trimString(storagePath);

			// -----------------------------------------------------------------
			temp = getToken("txCenterElement");
			txPos.centerElement = atoi(temp.data());// was 0
			//temp.clear();

			// -----------------------------------------------------------------
			std::string channels = "NUMCHANNELS";
			std::string aperture = getToken("txAperture");
			if (aperture.find(channels) == std::string::npos)
			{		txPos.aperture = atoi(aperture.data());
			}else
			{		txPos.aperture = NUMCHANNELS;// was: 0;    NOT SURE !!!!!!!
			}
			// -----------------------------------------------------------------
			temp = getToken("txFocusDistance");
			txPos.focusDistance = atoi(temp.data());// was 50000;

			// -----------------------------------------------------------------
			temp = getToken("txAngle");
			txPos.angle = atoi(temp.data());//0;

			// -----------------------------------------------------------------
			temp = getToken("txCenterFrequency");
			if(atoi(temp.data()) == 0)
			{   
				if(scannerPresent)
					txPos.frequency = m_texo->getProbeCenterFreq();
			}else {
				txPos.frequency = atoi(temp.data());
			}

			// -----------------------------------------------------------------
			temp = getToken("posPulseShape");
			temp = trimString(temp);
			strcpy_s(txPos.pulseShape, temp.data());// was "+-");    
			temp = getToken("negPulseShape");
			temp = trimString(temp);
			strcpy_s(txNeg.pulseShape, temp.data());// was "-+");   
			//               1234567890123456789 
			// -----------------------------------------------------------------
			temp = getToken("txUseManualDelays");
			if(atoi(temp.data()) == 1)
			{    txPos.useManualDelays = true;}
			else {txPos.useManualDelays = false;}

			// -----------------------------------------------------------------
			std::vector <int> txDelays = getManualDelays("txManualDelays");//
			for(i=0;i<128;i++)
			{
				txPos.manualDelays[i] = txNeg.manualDelays[i] = txDelays.at(i);//[i];
			}
			//delete [] txDelays;
			// -----------------------------------------------------------------
			temp = getToken("txTableIndex");
			txPos.tableIndex = atoi(temp.data());// was -1;

			// -----------------------------------------------------------------
			temp = getToken("rxCenterElement");
			rxPos.centerElement = atoi(temp.data());// was 0;

			// -----------------------------------------------------------------
			aperture = getToken("rxAperture");
			if (aperture.find(channels) == std::string::npos)
			{		rxPos.aperture = atoi(aperture.data());
			}else	{
				rxPos.aperture = NUMCHANNELS;// was: 0;    NOT SURE !!!!!!!
			}
			//    rxPos.aperture = NUMCHANNELS;

			// -----------------------------------------------------------------
			temp = getToken("rxAngle");
			rxPos.angle = atoi(temp.data());// was 0;

			//        1234567890123456789 
			// -----------------------------------------------------------------
			temp = getToken("rxMaxApertureDepth");
			rxPos.maxApertureDepth = atoi(temp.data());// was 30000;

			// -----------------------------------------------------------------
			temp = getToken("rxAcquisitionDepth");
			rxPos.acquisitionDepth = atoi(temp.data());// was 100000; //was 20000;

			// -----------------------------------------------------------------
			temp = getToken("rxSpeedOfSound");
			rxPos.speedOfSound = atoi(temp.data());// was 1540;

			// -----------------------------------------------------------------
			// there is a problem with that field: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			temp = getToken("rxChannelMask[0]");
			rxPos.channelMask[0] = atoi(temp.data());// was 0xFFFFFFFF;//
			temp = getToken("rxChannelMask[1]");
			rxPos.channelMask[1] = atoi(temp.data());//0xFFFFFFFF;//atoi(temp.data());// was 0xFFFFFFFF;

			// -----------------------------------------------------------------
			temp = getToken("rxApplyFocus");
			if(atoi(temp.data()) == 1)
			{    rxPos.applyFocus = true;}
			else {rxPos.applyFocus = false;}

			// -----------------------------------------------------------------
			temp = getToken("rxUseManualDelays");
			if(atoi(temp.data()) == 1)
			{    rxPos.useManualDelays = true;}
			else {rxPos.useManualDelays = false;}

			// -----------------------------------------------------------------
			std::vector <int> rxDelays = getManualDelays("rxManualDelays");
			for(i=0;i<64;i++)
			{
				rxPos.manualDelays[i] = rxNeg.manualDelays[i] = rxDelays.at(i);//[i];
			}

			// -----------------------------------------------------------------
			temp = getToken("rxTableIndex");
			rxPos.tableIndex = atoi(temp.data());// was -1;

			// -----------------------------------------------------------------
			temp = getToken("rxCustomLineDuration");//rxCustomLineDuration");
			rxPos.customLineDuration = atoi(temp.data());// was 0;

			// -----------------------------------------------------------------
			temp = getToken("rxDecimation");
			rxPos.decimation = atoi(temp.data());// was 1; //WAS 1;

			// -----------------------------------------------------------------
			temp = getToken("rxLgcValue");
			rxPos.lgcValue = atoi(temp.data());// was 0;

			// -----------------------------------------------------------------
			temp = getToken("rxTgcSel");
			rxPos.tgcSel = atoi(temp.data());// was 0;

			// -----------------------------------------------------------------
			// The NEGATIVE PARAMETERS ARE SET EQUAL TO POSITIVE, EXCEPT FOR PULSE SIGN.
			txNeg.centerElement = txPos.centerElement;
			txNeg.aperture = txPos.aperture ;    
			txNeg.focusDistance = txPos.focusDistance;
			txNeg.angle = txPos.angle;
			txNeg.frequency = txPos.frequency;

			txNeg.useManualDelays = txPos.useManualDelays;
			txNeg.tableIndex = txPos.tableIndex;

			rxNeg.centerElement = rxPos.centerElement;
			rxNeg.aperture = rxPos.aperture;
			rxNeg.angle = rxPos.angle;
			rxNeg.maxApertureDepth = rxPos.maxApertureDepth;
			rxNeg.acquisitionDepth = rxPos.acquisitionDepth;
			rxNeg.speedOfSound = rxPos.speedOfSound;
			rxNeg.channelMask[0] = rxNeg.channelMask[1] = rxPos.channelMask[0];
			rxNeg.applyFocus = rxPos.applyFocus;
			rxNeg.useManualDelays = rxPos.useManualDelays;
			rxNeg.tableIndex = rxPos.tableIndex;    
			rxNeg.customLineDuration = rxPos.customLineDuration;
			rxNeg.decimation = rxPos.decimation;
			rxNeg.lgcValue = rxPos.lgcValue;
			rxNeg.tgcSel = rxPos.tgcSel;
			return true;
		}
		return true;
	}catch(char * str)
	{
		std::cout << "Caught some exception: " << str << "\n";
		wait(shortDelay);
		return false;
	}
}
// ***********************************************************************************************
bool getConfigString(std::string configFileName)
{
	using namespace std;

	configData.clear();
	configData = "";

	ifstream configFile(configFileName.data(),ios::in);

	if (configFile) // on v�rifie si l'ouverture du fichier a r�ussi
	{
		std::string line; //une string qui va contenir temporairement la ligne lue
		while (std::getline( configFile, line )) // tant qu'on a pas tout lu, on lit la ligne suivante
		{
			configData += line;//myStrings.push_back(line); // on rajoute la ligne lue dans le vector
		}
		configFile.close(); // Closes file.
		return true;
	}

	return false;
}
// ***********************************************************************************************
std::string getToken(std::string tokenName)//char * tokenName)
{
	std::string token = "";
	std::basic_string <int>::size_type refIndex = configData.find(tokenName);
	std::basic_string <int>::size_type startIndex = configData.find("=", refIndex);
	std::basic_string <int>::size_type endIndex = configData.find(";", startIndex);
	token += configData.substr(startIndex + 1, endIndex - startIndex - 1);

	return token;
}
// ***********************************************************************************************
std::vector <int> getManualDelays(std::string tokenName)
{
	using namespace std;
	std::vector <int> delays;
	int index = 0;

	delays.reserve(128);
	std::string token;
	token.reserve(32);
	token = "";
	std::string rest = "   ";

	std::basic_string <int>::size_type refIndex = configData.find(tokenName);
	std::basic_string <int>::size_type startIndex = configData.find("=", refIndex);
	std::basic_string <int>::size_type endIndex = configData.find(";", startIndex);
	token += configData.substr(startIndex + 1, endIndex - startIndex - 1);

	refIndex = 1;
	startIndex = 1;
	endIndex = 1;
	token += ",";
	int tokenLength = (int)(token.end()-token.begin());//(int)token.length();
	while(endIndex != tokenLength-1)//> 0)//token.length()-
	{
		endIndex = token.find(",", refIndex);
		rest = token.substr(startIndex, endIndex - startIndex);
		delays.push_back(atoi((rest).data()));
		startIndex = refIndex = endIndex + 1;
		index++;
	}
	//index -= 1;

	return delays;
}
// ***********************************************************************************************
bool CreateSequence()
{
	if(!m_texo->beginSequence())
	{return false;}

	int i, lineSize, numberElements;
	//double pi = 3.1415926535897932364248;
	numberElements = m_texo->getProbeNumElements();

	if(setorialProbe) // ----------------------- Sectorial Probe -----
	{
		// Here I assumed that sectorial p^robe fire from their center:	

		// add 5 to the virtual element, to make symettrical time delays
		// we should do this because the aperture values must be even for now

		txNeg.centerElement = rxNeg.centerElement = txPos.centerElement = rxPos.centerElement = (numberElements/2 * 10) + 5;
		// But the size of the probe is probably wrong..... How do we know?
		// Probably, all Ultrasonix elements have the same size = 10 �m.

		for(i = 0; i < numberElements; i++) // is that number of lines fine ???
		{
			// the angle is in 1/1000 of degrees.
			txNeg.angle = txPos.angle = rxNeg.angle = rxPos.angle = (int)(-45 + (float)i*90/(float)numberElements)*1000;//-pi/4 + i*pi/2/numberElements;

			//rxPos.channelMask[0] = 1 << (i % NUMCHANNELS);
			//rxNeg.channelMask[0] = 1 << (i % NUMCHANNELS);
			lineSize = m_texo->addLine(rfData, txPos, rxPos);
			if(lineSize == -1)
				return false;
			lineSize = m_texo->addLine(rfData, txNeg, rxNeg);
			if(lineSize == -1)
				return false;
		}
	}
	else // ------------------------------------- LINEAR Probe -----
	{
		for(i = 0; i < numberElements; i++)
		{
			// add 5 to the virtual element, to make symettrical time delays
			// we should do this because the aperture values must be even for now

			txPos.centerElement = (i * 10) + 5;
			rxPos.centerElement = (i * 10) + 5;
			txNeg.centerElement = (i * 10) + 5;
			rxNeg.centerElement = (i * 10) + 5;
			//rxPos.channelMask[0] = 1 << (i % NUMCHANNELS);
			//rxNeg.channelMask[0] = 1 << (i % NUMCHANNELS);
			lineSize = m_texo->addLine(rfData, txPos, rxPos);
			if(lineSize == -1)
			{
				//AfxMessageBox(_T("Problemduring slinr addition."), MB_ICONERROR, 0);
				return false;
			}
			lineSize = m_texo->addLine(rfData, txNeg, rxNeg);
			if(lineSize == -1)
			{
				//AfxMessageBox(_T("Problem during line addition."), MB_ICONERROR, 0);
				return false;
			}
		}
	}
	// tell program to finish sequence
	if(m_texo->endSequence() == -1)
	{ 
		//AfxMessageBox(_T("Problem during sequence end."), MB_ICONERROR, 0);
		return false;
	}    
	return true;
}
// ***********************************************************************************************
bool saveData() // was : AnalyzeData(double * elementData)
{
	int numFrames, frameSize;//i, j, , numSamples, lineSize
	//unsigned char * begin;
	//signed short * data;
	//double avg, avgs[MAXELEMENTS];

	int numElements;

	numElements = m_texo->getProbeNumElements();

	//char path[100];
	//int numFrames, frameSize;
	FILE * fp;

	numFrames = m_texo->getCollectedFrameCount();
	frameSize = m_texo->getFrameSize();


	if(numFrames < 1)
	{
		fprintf(stderr, "No frames have been acquired\n");
		wait(shortDelay);
		return false;
	}
	// Is that necessary ??? :
	// begin = m_texo->getCineStart();
	// begin += 4;
	// ------------------------------ Checks if numberFramesToSave is available -------
	if(numberFramesToSave >= numFrames)
		numberFramesToSave = numFrames;
	//printf("Enter a filename: ");
	//scanf("%s", path);

	fopen_s(&fp, storagePath.data(), "wb+");//fp = fopen_s(storagePath.data(), "wb+");
	if(!fp)
	{
		fprintf(stderr, "Could not store data to specified path\n");
		wait(shortDelay);
		return false;
	}
	//int taille = sizeof(frameSize);
	fwrite(&frameSize , sizeof(frameSize), 1, fp);
	fwrite(&numElements , sizeof(numElements), 1, fp);
	fwrite(m_texo->getCineStart(), frameSize, numberFramesToSave, fp);

	fclose(fp);

	fprintf(stdout, "Successfully stored data\n");

	return true;
}


