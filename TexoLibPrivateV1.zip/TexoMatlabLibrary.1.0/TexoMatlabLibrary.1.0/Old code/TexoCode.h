#ifndef __JMM
#define __JMM
// From old files :
#if !defined(AFX_STDAFX_H__DA75F23B_EF7F_4A3E_BD30_A58A14B98B2C__INCLUDED_)
#define AFX_STDAFX_H__DA75F23B_EF7F_4A3E_BD30_A58A14B98B2C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include "texo.h"
#include "texo_def.h"

#pragma warning(push, 3)
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#pragma warning(pop)

#define NUMCHANNELS     32
#define MAXELEMENTS     128

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_STDAFX_H__DA75F23B_EF7F_4A3E_BD30_A58A14B98B2C__INCLUDED_)
//------------------------------------------------------------------------------------------
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
#if !defined(AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_)
#define AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <stdio.h>
#include <tchar.h>
// TODO: reference additional headers your program requires here

/*#ifndef __AFXWIN_H__
#error include 'stdafx.h' before including this file for PCH
#endif*/

//#include "resource.h"
#include <string.h>
#include <fstream> 

bool CreateSequence();    
bool saveData();
bool loadConfig();
int wait(int delay);
bool getConfigString(std::string configFileName);//ifstream configFile);

std::string getToken(std::string tokenName);//getToken(char * tokenName);
std::vector <int> getManualDelays(std::string tokenName);
std::string trimString(std::string input);

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_ELTEST_H__15737600_AB04_42A3_B7E6_1FD5302275B5__INCLUDED_)
#endif
