//#include "StdAfx.h"


#include "stdafx.h"
#include "TexoTools.h"
#include "texo.h"
#include "texo_def.h"
#include <math.h>
#include <string.h>
#include <fstream> 
#include <iostream>
#include <String>
#include <vector>
#include <sys/timeb.h>
#include <time.h>

#include "D:\SonixProgramming\TexoMatlabLibrary.1.0\CImg-1.2.5\CImg.h"
using namespace cimg_library;



#ifndef DATA_PATH
#define DATA_PATH   "../../dat/"
#endif

// ***********************************************************************************************
TexoTools::TexoTools()
{
	shortDelay = 500; 
	longDelay = 3000;
	acquisitionDuration = 1000;
	scannerPresent = true; // turn to true if running on the scanner !!!!!!!
	sectorialProbe = 1;// assume default sectorial probe.
	probeConnector = 0;

	//m_texo = 0;//new texo;
	//m_texo = new texo;
	/*storagePath = new std::string; // path string for the data to store.
	configData = new std::string; // string loading the parameters.
	configPath = new std::string;/**/

	storagePath.reserve(1024);
	configData.reserve(4096);
	configPath.reserve(1024);

	storagePath = "";
	configData = "";
	configPath = "";
}
TexoTools::~TexoTools(void)
{
	//delete m_texo;//
}
// ***********************************************************************************************
int TexoTools::initEngine(char *  settingsPath, 
						  int  pci,  
						  int  usm,  
						  int  hv,  
						  int  channels,  
						  int  ddr)
{
	try{
		if(scannerPresent)// && !(m_texo.isInitialized()))
			return m_texo.init(settingsPath, pci, usm, hv, channels, ddr);
	}catch(char * str)
	{
		return -2;
	}
	return -2;
}
// ***********************************************************************************************
int TexoTools::initEngine(char * settingsPath)
{
	try
	{
		if(scannerPresent)//&& !(m_texo.isInitialized()) && !m_texo.isImaging())
		{
			//char* settings = "D:/Sonix Programming/TexoMatlabLibrary.1.0/TexoMatlabLibrary.1.0/release/dat/";
			m_texo.init(settingsPath, 2, 2, 0, 0, 0);
			//wait(200)
			//if(m_texo.init(DATA_PATH, 2, 2, 0, 0, 0))DATA_PATH
			//	return 0;
			//else
				return 0;//(int)m_texo;//-54;
		}

	}catch(char * str)
	{
		return -2;
	}
	return -2;
}

// ***********************************************************************************************
int TexoTools rv::startImaging()
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			//m_texo.setSyncSignals(inputSignalConfig, outputSignalConfig1, outputSignalConfig2);//   Configures the I/O signals attached to the BnC connectors.
		
			m_texo.runImage();
			wait(acquisitionDuration);
			//m_texo.stopImage();//
			return 0;		
		}
	}catch(char * str)
	{
		return -3;
	}
	return -3;
}
int TexoTools rv::stopImaging()
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			//m_texo.setSyncSignals(inputSignalConfig, outputSignalConfig1, outputSignalConfig2);//   Configures the I/O signals attached to the BnC connectors.
		
			//m_texo.runImage();//
			//wait(acquisitionDuration);//
			m_texo.stopImage();
			return 0;		
		}
	}catch(char * str)
	{
		return -3;
	}
	return -3;
}

// ***********************************************************************************************
int TexoTools::stopEngine()
{
	//m_texo.~texo
	//return m_texo.shutdown();
	try{
		if(scannerPresent)// && (m_texo.isInitialized()))
			if (m_texo.shutdown())
			return 0;
			else return -5;
	}catch(char * str)
	{
		return -5;
	}
	return -5;/**/
}

// ***********************************************************************************************
int TexoTools::run(const char * argv)//, char *envp[])//_TCHAR* argv[])//}
{
	//---------------------------------------------------------------------
	int ret = -1;
	/*int argc = 2;

	if (argv[1] != '\0')// && argc > 1)
	{
	//for(int i=1; i<argc; i++)
	configPath.append(argv);//"");//[i]
	//configPath += "   ";
	configPath = trimString(configPath);
	}else
	{
	configPath.append("DefaultConfigFile.txt");//configFile.txt");
	}*/
	try
	{
		setConfigFile(argv);
		// Initialize parameters:
		inputSignalConfig   = 0;
		outputSignalConfig1 = 0;
		outputSignalConfig2 = 0;

		//return -4;
		// init electronics
		if(scannerPresent)
		{
			if(!m_texo.init(DATA_PATH, 2, 2, 0, 0, 0))
			{return -2;}
		}
		if((ret = loadConfig()) != 0)// Here, the config file is opened ans the parameters read.
		{ 
			if(scannerPresent && m_texo.isInitialized())
			{m_texo.shutdown();}
			wait(shortDelay);
			return ret;
		}
		// Sets trigger and synch signals on the BNC output:
		if(scannerPresent)
		{
			m_texo.setSyncSignals(inputSignalConfig, outputSignalConfig1, outputSignalConfig2);//   Configures the I/O signals attached to the BnC connectors.
			//									  Parameters:
			//										[in]  input  The input signal config (0 = none, 1 = line trigger, 2 = frame trigger)  
			//										[in]  output  The output signal config (0 = none, 1 = line sync, 2 = frame sync)  
			//										[in]  output2  The 2nd output signal config (0 = none, 1 = line sync, 2 = frame sync)  

			if((ret=createFlipFlapSequence()) != 0)
			{return ret;}

			// Perform acquisition :
			try
			{
				m_texo.runImage();
				//::Sleep(acquisitionDuration); // was 2000
				wait(acquisitionDuration);
				m_texo.stopImage();
			}catch(char * str)
			{
				return -3;
			}

			// Save data to file precised in configFile :
			if((ret=saveData()) != 0)
			{return ret;}

			if(!m_texo.shutdown())
			{return -5;}
		}//else	{}
		//wait(longDelay);
	}catch(char * str)
	{
		return -8;
	}
	return 0;/**/
}
// ***********************************************************************************************
int TexoTools::wait(int delay)
{
	time_t ltime1;
	time_t ltime2;
	time(&ltime1);
	time(&ltime2);

	struct _timeb t1;
	struct _timeb t2;
	struct _timeb * tptr1 = &t1;
	struct _timeb * tptr2 = &t2;

	_ftime_s(tptr1);
	_ftime_s(tptr2);

	while((int)((ltime2-ltime1)*1000 + (int)(tptr2->millitm - tptr1->millitm)) <= delay)// offset is minimum and is for routine execution...
	{
		time(&ltime2);
		_ftime_s(tptr2);
	}

	return ((int)((ltime2-ltime1)*1000) + (int)(tptr2->millitm - tptr1->millitm));
}
// ***********************************************************************************************
std::string TexoTools::trimString(std::string input)
{
	// Remove spaces at the beginning:

	while((int)(input.end()-input.begin()) > 0 && input[0] == 32)
		input.erase(input.begin());//str1_Iter);

	while((int)(input.end()-input.begin()-1) > 0 && input[(int)(input.end()-input.begin())-1] == 32)
		input.erase(input.end()-1);

	return input;
}
// ***********************************************************************************************
int TexoTools::setConfigFile(const char * argv)
{
	configPath = "";
	int ret = 0;
	try
	{
		configPath.append(argv);
		configPath = trimString(configPath);
		if(configPath.length() == 0)
			configPath.append("DefaultConfigFile.txt");//configFile.txt");

		// Loads the specified configFile:
		if((ret = loadConfig()) != 0)
			return ret;
	}catch(char * str)
	{
		return -4;
	}
	return 0;
}
// ***********************************************************************************************
bool TexoTools::getConfigString(std::string configFileName)
{
	using namespace std;

	configData.clear();
	configData = "";

	ifstream configFile(configFileName.data(),ios::in);

	if (configFile) // on v�rifie si l'ouverture du fichier a r�ussi
	{
		std::string line; //une string qui va contenir temporairement la ligne lue
		while (std::getline(configFile, line)) // tant qu'on a pas tout lu, on lit la ligne suivante
		{
			configData += line;//myStrings.push_back(line); // on rajoute la ligne lue dans le vector
		}
		configFile.close(); // Closes file.
		return true;
	}

	return false;
}
// ***********************************************************************************************
int TexoTools::loadConfig()
{
	int response = -1;
	int i=0;
	std::string temp;
	//std::string emptyString = "";
	temp.reserve(128);
	temp = "";
	if(!getConfigString(configPath)) // call subroutine to fill configString field from the 'configFile'.
		return -6;
	//if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
	{
		try{

			/*if(!getConfigString(configPath)) // call subroutine to fill configString field from the 'configFile'.
			{return 0;}
			else*/
			{
				// Here fill parameters from file ---------------------- TODO !!!!!!!!!!!!!!!!

				temp = getToken("InputSignalConfig");//
				if(temp == "")
					temp = "0";
				inputSignalConfig = atoi(temp.data());//

				// -----------------------------------------------------------------
				temp = getToken("OutputSignalConfig1");//
				if(temp == "")
					temp = "0";
				outputSignalConfig1 = atoi(temp.data());//

				// -----------------------------------------------------------------
				temp = getToken("OutputSignalConfig2");//
				if(temp == "")
					temp = "0";
				outputSignalConfig2 = atoi(temp.data());//

				// -----------------------------------------------------------------
				temp = getToken("AcquisitionDuration");//
				if(temp == "")
					temp = "1000";
				acquisitionDuration = atoi(temp.data());//

				// -----------------------------------------------------------------
				std::string power = getToken("Power");//std::string tokenName)
				if(power == "")
					temp = "1";
				std::string powerMax = getToken("PowerMax");//std::string tokenName)
				if(powerMax == "")
					temp = "1";
				std::string powerMin = getToken("PowerMin");//std::string tokenName)
				if(powerMin == "")
					temp = "1";
				if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
				{response = m_texo.setPower(atoi(power.data()), atoi(powerMax.data()), atoi(powerMin.data()));}
				// -----------------------------------------------------------------
				temp = getToken("TGC");//std::string tokenName)
				if(temp == "")
					temp = "1";
				if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
					m_texo.addTGC(atof(temp.data()));    

				// -----------------------------------------------------------------
				temp = getToken("ProbeConnector");//std::string tokenName)
				if(temp == "")
					return -6;
				probeConnector = atoi(temp.data());
				if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
				{response = m_texo.activateProbeConnector(probeConnector);}//c_probe);

				// -----------------------------------------------------------------
				temp = getToken("sectorialProbe");//std::string tokenName)
				if(temp == "")
					temp = "0";
				sectorialProbe = atoi(temp.data()); // set here if probe is linear (0) or sectorial (1).

				// -----------------------------------------------------------------
				temp = getToken("numberFramesToSave");
				if(temp == "")
					temp = "1";
				numberFramesToSave = atoi(temp.data());

				// -----------------------------------------------------------------
				storagePath = getToken("dataFileName");
				if(temp == "")
					temp = "currentRfFrame.bin";
				storagePath = trimString(storagePath);

				// -----------------------------------------------------------------
				temp = getToken("txCenterElement");
				if(temp == "")
					temp = "0";
				txPos.centerElement = atoi(temp.data());// was 0
				//temp.clear();

				// -----------------------------------------------------------------
				std::string channels = "NUMCHANNELS";
				std::string aperture = getToken("txAperture");
				if(aperture == "")
					aperture = "NUMCHANNELS";
				if (aperture.find(channels) == std::string::npos)
				{		txPos.aperture = atoi(aperture.data());
				}else
				{		txPos.aperture = NUMCHANNELS;// was: 0;    NOT SURE !!!!!!!
				}
				// -----------------------------------------------------------------
				temp = getToken("txFocusDistance");
				if(temp == "")
					temp = "50000";
				txPos.focusDistance = atoi(temp.data());// was 50000;

				// -----------------------------------------------------------------
				temp = getToken("txAngle");
				if(temp == "")
					temp = "0";
				txPos.angle = atoi(temp.data());//0;

				// -----------------------------------------------------------------
				temp = getToken("txCenterFrequency");
				if(atoi(temp.data()) == 0)
				{if(scannerPresent)
					txPos.frequency = m_texo.getProbeCenterFreq();
				}else 
				{txPos.frequency = atoi(temp.data());}

				// -----------------------------------------------------------------
				temp = getToken("posPulseShape");
				if(temp == "")
					temp = "+-";
				temp = trimString(temp);
				strcpy_s(txPos.pulseShape, temp.data());// was "+-");    
				temp = getToken("negPulseShape");
				if(temp == "")
					temp = "-+";
				temp = trimString(temp);
				strcpy_s(txNeg.pulseShape, temp.data());// was "-+");   
				// -----------------------------------------------------------------
				temp = getToken("txUseManualDelays");
				if(temp == "")
					temp = "0";
				if(atoi(temp.data()) == 1)
					txPos.useManualDelays = true;
				else{txPos.useManualDelays = false;}

				// -----------------------------------------------------------------
				std::vector <int> txDelays = getManualDelays("txManualDelays");//
				if(!txDelays.empty())
				{
					//std::basic_string <int>::size_type len = txDelays.size();
					int len = (int)txDelays.size();
					//return len;
					for(i=0;i<len;i++)
					{txPos.manualDelays[i] = txNeg.manualDelays[i] = txDelays.at(i);}
				}else
				{txPos.useManualDelays = false;}

				// -----------------------------------------------------------------
				temp = getToken("txTableIndex");
				if(temp == "")
					temp = "-1";
				txPos.tableIndex = atoi(temp.data());// was -1;

				// -----------------------------------------------------------------
				temp = getToken("rxCenterElement");
				if(temp == "")
					temp = "0";
				rxPos.centerElement = atoi(temp.data());// was 0;

				// -----------------------------------------------------------------
				aperture = getToken("rxAperture");
				if(aperture == "")
					aperture = "NUMCHANNELS";
				if (aperture.find(channels) == std::string::npos)
				{		rxPos.aperture = atoi(aperture.data());
				}else	{
					rxPos.aperture = NUMCHANNELS;// was: 0;    NOT SURE !!!!!!!
				}
				//    rxPos.aperture = NUMCHANNELS;

				// -----------------------------------------------------------------
				temp = getToken("rxAngle");
				if(temp == "")
					temp = "0";
				rxPos.angle = atoi(temp.data());// was 0;

				// -----------------------------------------------------------------
				temp = getToken("rxMaxApertureDepth");
				if(temp == "")
					temp = "50000";
				rxPos.maxApertureDepth = atoi(temp.data());// was 30000;

				// -----------------------------------------------------------------
				temp = getToken("rxAcquisitionDepth");
				if(temp == "")
					temp = "100000";
				rxPos.acquisitionDepth = atoi(temp.data());// was 100000; //was 20000;

				// -----------------------------------------------------------------
				temp = getToken("rxSpeedOfSound");
				if(temp == "")
					temp = "1540";
				rxPos.speedOfSound = atoi(temp.data());// was 1540;

				// -----------------------------------------------------------------
				temp = getToken("rxChannelMask[0]");
				if(temp == "")
					temp = "4294967295";
				rxPos.channelMask[0] = atoi(temp.data());// was 0xFFFFFFFF;//
				temp = getToken("rxChannelMask[1]");
				if(temp == "")
					temp = "4294967295";
				rxPos.channelMask[1] = atoi(temp.data());//0xFFFFFFFF;//atoi(temp.data());// was 0xFFFFFFFF;

				// -----------------------------------------------------------------
				temp = getToken("rxApplyFocus");
				if(temp == "")
					temp = "1";
				if(atoi(temp.data()) == 1)
				{    rxPos.applyFocus = true;}
				else {rxPos.applyFocus = false;}

				// -----------------------------------------------------------------
				temp = getToken("rxUseManualDelays");
				if(temp == "")
					temp = "0";
				if(atoi(temp.data()) == 1)
				{    rxPos.useManualDelays = true;}
				else {rxPos.useManualDelays = false;}

				// -----------------------------------------------------------------
				std::vector <int> rxDelays = getManualDelays("rxManualDelays");
				if(!rxDelays.empty())
				{
					int len = (int)rxDelays.size();
					//return len;
					for(i=0;i<len;i++)
					{rxPos.manualDelays[i] = rxNeg.manualDelays[i] = rxDelays.at(i);}
				}else
				{rxPos.useManualDelays = false;}
				// -----------------------------------------------------------------
				temp = getToken("rxTableIndex");
				if(temp == "")
					temp = "-1";
				rxPos.tableIndex = atoi(temp.data());// was -1;

				// -----------------------------------------------------------------
				temp = getToken("rxCustomLineDuration");//rxCustomLineDuration");
				if(temp == "")
					temp = "0";
				rxPos.customLineDuration = atoi(temp.data());// was 0;

				// -----------------------------------------------------------------
				temp = getToken("rxDecimation");
				if(temp == "")
					temp = "1";
				rxPos.decimation = atoi(temp.data());// was 1; //WAS 1;

				// -----------------------------------------------------------------
				temp = getToken("rxLgcValue");
				if(temp == "")
					temp = "0";
				rxPos.lgcValue = atoi(temp.data());// was 0;

				// -----------------------------------------------------------------
				temp = getToken("rxTgcSel");
				if(temp == "")
					temp = "0";
				rxPos.tgcSel = atoi(temp.data());// was 0;

				// -----------------------------------------------------------------
				// The NEGATIVE PARAMETERS ARE SET EQUAL TO POSITIVE, EXCEPT FOR PULSE SIGN.
				txNeg.centerElement = txPos.centerElement;
				txNeg.aperture = txPos.aperture ;    
				txNeg.focusDistance = txPos.focusDistance;
				txNeg.angle = txPos.angle;
				txNeg.frequency = txPos.frequency;

				txNeg.useManualDelays = txPos.useManualDelays;
				txNeg.tableIndex = txPos.tableIndex;

				rxNeg.centerElement = rxPos.centerElement;
				rxNeg.aperture = rxPos.aperture;
				rxNeg.angle = rxPos.angle;
				rxNeg.maxApertureDepth = rxPos.maxApertureDepth;
				rxNeg.acquisitionDepth = rxPos.acquisitionDepth;
				rxNeg.speedOfSound = rxPos.speedOfSound;
				rxNeg.channelMask[0] = rxNeg.channelMask[1] = rxPos.channelMask[0];
				rxNeg.applyFocus = rxPos.applyFocus;
				rxNeg.useManualDelays = rxPos.useManualDelays;
				rxNeg.tableIndex = rxPos.tableIndex;    
				rxNeg.customLineDuration = rxPos.customLineDuration;
				rxNeg.decimation = rxPos.decimation;
				rxNeg.lgcValue = rxPos.lgcValue;
				rxNeg.tgcSel = rxPos.tgcSel;
				return 0;
			}
			//return 0;
		}catch(char * str)
		{
			//std::cout << "Caught some exception: " << str << "\n";
			wait(shortDelay);
			return -16;
		}
	}
	return -18;
}
// ***********************************************************************************************
std::string TexoTools::getToken(std::string tokenName)//char * tokenName)
{
	std::string token = "";
	try
	{
		std::basic_string <int>::size_type refIndex = configData.find(tokenName);
		std::basic_string <int>::size_type startIndex = configData.find("=", refIndex);
		std::basic_string <int>::size_type endIndex = configData.find(";", startIndex);
		if(refIndex != std::string::npos && startIndex != std::string::npos && endIndex != std::string::npos)
			token += configData.substr(startIndex + 1, endIndex - startIndex - 1);
	}catch(char * str)
	{return token;}
	return token;
}
// ***********************************************************************************************
std::vector <int> TexoTools::getManualDelays(std::string tokenName)
{
	using namespace std;
	std::vector <int> delays(0);
	std::vector <int> emptyDelays(0);
	int index = 0;

	delays.reserve(128);
	std::string token;
	token.reserve(32);
	token = "";
	std::string rest = "   ";
	try
	{
		std::basic_string <int>::size_type refIndex = configData.find(tokenName);
		std::basic_string <int>::size_type startIndex = configData.find("=", refIndex);
		std::basic_string <int>::size_type endIndex = configData.find(";", startIndex);
		token += configData.substr(startIndex + 1, endIndex - startIndex - 1);

		refIndex = 1;
		startIndex = 1;
		endIndex = 1;
		token += ",";
		int tokenLength = (int)(token.end()-token.begin());//(int)token.length();
		while(endIndex != tokenLength-1)//> 0)//token.length()-
		{
			endIndex = token.find(",", refIndex);
			rest = token.substr(startIndex, endIndex - startIndex);
			delays.push_back(atoi((rest).data()));
			startIndex = refIndex = endIndex + 1;
			index++;
		}
		//index -= 1;
	}catch(char * str)
	{return emptyDelays;}

	return delays;
}
// ***********************************************************************************************
int TexoTools::createFlipFlapSequence()
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			if(!m_texo.beginSequence())
			{return -71;}

			int i, lineSize, numberElements;
			//double pi = 3.1415926535897932364248;
			numberElements = m_texo.getProbeNumElements();

			if(sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txNeg.centerElement = rxNeg.centerElement = txPos.centerElement = rxPos.centerElement = (numberElements/2 * 10) + 5;
				for(i = 0; i < numberElements; i++) // is that number of lines fine ???
				{
					txNeg.angle = txPos.angle = rxNeg.angle = rxPos.angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);//-pi/4 + i*pi/2/numberElements;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -72;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
					if(lineSize == -1)
						return -72;
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i = 0; i < numberElements; i++)
				{
					txPos.centerElement = (i * 10) + 5;
					rxPos.centerElement = (i * 10) + 5;
					txNeg.centerElement = (i * 10) + 5;
					rxNeg.centerElement = (i * 10) + 5;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -73;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
					if(lineSize == -1)
						return -73;
				}
			}
			// tell program to finish sequence
			if(m_texo.endSequence() == -1)
				return -74;
			return 0;
		}
		return -7;
	}catch(char * str)
	{return -7;}
}
// ***********************************************************************************************
int TexoTools::createFlipFlapSequence(char * flip, char * flap)
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			strcpy_s(txPos.pulseShape, flip);// was "+-");    
			strcpy_s(txNeg.pulseShape, flap);// was "-+");   

			if(!m_texo.beginSequence())
			{return -71;}

			int i, lineSize, numberElements;
			//double pi = 3.1415926535897932364248;
			numberElements = m_texo.getProbeNumElements();

			if(sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txNeg.centerElement = rxNeg.centerElement = txPos.centerElement = rxPos.centerElement = (numberElements/2 * 10) + 5;
				for(i = 0; i < numberElements; i++) // is that number of lines fine ???
				{
					txNeg.angle = txPos.angle = rxNeg.angle = rxPos.angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);//-pi/4 + i*pi/2/numberElements;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -72)
						return -1;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
					if(lineSize == -72)
						return -1;
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i = 0; i < numberElements; i++)
				{
					txPos.centerElement = (i * 10) + 5;
					rxPos.centerElement = (i * 10) + 5;
					txNeg.centerElement = (i * 10) + 5;
					rxNeg.centerElement = (i * 10) + 5;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -73;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
					if(lineSize == -1)
						return -73;
				}
			}
			// tell program to finish sequence
			if(m_texo.endSequence() == -1)
				return -74;
			return 0;
		}
		return -7;
	}catch(char * str)
	{return -7;}
}
// ***********************************************************************************************
int TexoTools::createNormalSequence()
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			if(!m_texo.beginSequence())
			{return -71;}

			int i, lineSize, numberElements;
			//double pi = 3.1415926535897932364248;
			numberElements = m_texo.getProbeNumElements();

			if(sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txNeg.centerElement = rxNeg.centerElement = txPos.centerElement = rxPos.centerElement = (numberElements/2 * 10) + 5;
				for(i = 0; i < numberElements; i++) // is that number of lines fine ???
				{
					txNeg.angle = txPos.angle = rxNeg.angle = rxPos.angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);//-pi/4 + i*pi/2/numberElements;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -72;
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i = 0; i < numberElements; i++)
				{
					txPos.centerElement = (i * 10) + 5;
					rxPos.centerElement = (i * 10) + 5;
					txNeg.centerElement = (i * 10) + 5;
					rxNeg.centerElement = (i * 10) + 5;
					//rxPos.channelMask[0] = 1 << (i % NUMCHANNELS);
					//rxNeg.channelMask[0] = 1 << (i % NUMCHANNELS);
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -73;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
				}
			}
			if(m_texo.endSequence() == -1)
				return -74;
			return 0;
		}
		return -7;
	}catch(char * str)
	{return -7;}
}
// ***********************************************************************************************
int TexoTools::createNormalSequence(char * flip)
{
	try
	{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			strcpy_s(txPos.pulseShape, flip);// was "+-");  

			if(!m_texo.beginSequence())
			{return -71;}

			int i, lineSize, numberElements;
			//double pi = 3.1415926535897932364248;
			numberElements = m_texo.getProbeNumElements();

			if(sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txNeg.centerElement = rxNeg.centerElement = txPos.centerElement = rxPos.centerElement = (numberElements/2 * 10) + 5;
				for(i = 0; i < numberElements; i++) // is that number of lines fine ???
				{
					txNeg.angle = txPos.angle = rxNeg.angle = rxPos.angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);//-pi/4 + i*pi/2/numberElements;
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -72;
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i = 0; i < numberElements; i++)
				{
					txPos.centerElement = (i * 10) + 5;
					rxPos.centerElement = (i * 10) + 5;
					txNeg.centerElement = (i * 10) + 5;
					rxNeg.centerElement = (i * 10) + 5;
					//rxPos.channelMask[0] = 1 << (i % NUMCHANNELS);
					//rxNeg.channelMask[0] = 1 << (i % NUMCHANNELS);
					lineSize = m_texo.addLine(rfData, txPos, rxPos);
					if(lineSize == -1)
						return -73;
					lineSize = m_texo.addLine(rfData, txNeg, rxNeg);
				}
			}
			if(m_texo.endSequence() == -1)
				return -74;
			return 0;
		}
		return -7;
	}catch(char * str)
	{return -7;}
}
// ***********************************************************************************************
int TexoTools::saveData() // was : AnalyzeData(double * elementData)
{
	int numFrames, frameSize;
	int numElements;

	try{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			numElements = m_texo.getProbeNumElements();

			FILE * fp;

			numFrames = m_texo.getCollectedFrameCount();
			frameSize = m_texo.getFrameSize();

			if(numFrames < 1)
			{return -91;}
			// Is that necessary ??? :
			// begin = m_texo.getCineStart();
			// begin += 4;
			// ------------------------------ Checks if numberFramesToSave is available -------
			if(numberFramesToSave >= numFrames)
				numberFramesToSave = numFrames;
			//printf("Enter a filename: ");
			//scanf("%s", path);

			fopen_s(&fp, storagePath.data(), "wb+");//fp = fopen_s(storagePath.data(), "wb+");
			if(!fp)
			{return -92;}
			fwrite(&frameSize , sizeof(frameSize), 1, fp);
			fwrite(&numElements , sizeof(numElements), 1, fp);
			fwrite(m_texo.getCineStart(), frameSize, numberFramesToSave, fp);

			fclose(fp);

			return 0;
		}
		return -9;
	}catch(char * str)
	{return -9;}
}
// ***********************************************************************************************
int TexoTools::saveData(char * fileName, int numberOfFrames) // was : AnalyzeData(double * elementData)
{
	int numFrames, frameSize;//i, j, , numSamples, lineSize
	int numElements;
	try{
		if(scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			FILE * fp;

			numElements = m_texo.getProbeNumElements();
			numFrames = m_texo.getCollectedFrameCount();
			frameSize = m_texo.getFrameSize();


			if(numFrames < 1)
			{return -91;}
			// Is that necessary ??? :
			// begin = m_texo.getCineStart();
			// begin += 4;
			// ------------------------------ Checks if numberFramesToSave is available -------
			if(numberOfFrames >= numFrames)
				numberOfFrames = numFrames;

			fopen_s(&fp, fileName, "wb+");//fp = fopen_s(storagePath.data(), "wb+");
			if(!fp)
			{return -92;}

			fwrite(&frameSize , sizeof(frameSize), 1, fp);
			fwrite(&numElements , sizeof(numElements), 1, fp);
			fwrite(m_texo.getCineStart(), frameSize, numberOfFrames, fp);

			fclose(fp);

			return 0;
		}
		return -9;
	}catch(char * str)
	{return -9;}
}
// ***********************************************************************************************

std::string TexoTools::settingsToString(int full)
{
	std::string config;
	//config.
	config.reserve(4096);
	config = "";//Config : \n";//33.//"      aaaaaaaaaaaaaaaa\nbbbbbbb";//
	//return config;//Data;

	if(full)
	{
		config.append("shortDelay = ").append(num2string(shortDelay)).append(";\n");
		config.append("longDelay = ").append(num2string(longDelay)).append(";\n");
		config.append("AcquisitionDuration = ").append(num2string(acquisitionDuration)).append(";\n");
		config.append("ScannerPresent = ").append(num2string(scannerPresent)).append(";\n");
		config.append("SectorialProbe = ").append(num2string(sectorialProbe)).append(";\n");

		config.append("txPos.pulseShape = ").append((txPos.pulseShape)).append(";\n");
		config.append("txPos.frequency = ").append(num2string(txPos.frequency)).append(";\n");
		config.append("txPos.focusDistance = ").append(num2string(txPos.focusDistance)).append(";\n");
		config.append("txPos.angle = ").append(num2string(txPos.angle)).append(";\n");
		config.append("txPos.aperture = ").append(num2string(txPos.aperture)).append(";\n");
		config.append("txPos.tableIndex = ").append(num2string(txPos.tableIndex)).append(";\n");
		config.append("txPos.useManualDelays = ").append(num2string(txPos.useManualDelays)).append(";\n");

		config.append("rxPos.acquisitionDepth = ").append(num2string(rxPos.acquisitionDepth)).append(";\n");
		config.append("rxPos.angle = ").append(num2string(rxPos.angle)).append(";\n");
		config.append("rxPos.aperture = ").append(num2string(rxPos.aperture)).append(";\n");
		config.append("rxPos.applyFocus = ").append(num2string(rxPos.applyFocus)).append(";\n");
		config.append("rxPos.centerElement = ").append(num2string(rxPos.centerElement)).append(";\n");
		config.append("rxPos.decimation = ").append(num2string(rxPos.decimation)).append(";\n");
		config.append("rxPos.maxApertureDepth = ").append(num2string(rxPos.maxApertureDepth)).append(";\n");
		config.append("rxPos.speedOfSound = ").append(num2string(rxPos.speedOfSound)).append(";\n");
		config.append("rxPos.useManualDelays = ").append(num2string(rxPos.useManualDelays)).append(";\n");

		config.append("txNeg.pulseShape = ").append((txNeg.pulseShape)).append(";\n");
		config.append("txNeg.frequency = ").append(num2string(txNeg.frequency)).append(";\n");
		config.append("txNeg.focusDistance = ").append(num2string(txNeg.focusDistance)).append(";\n");
		config.append("txNeg.angle = ").append(num2string(txNeg.angle)).append(";\n");
		config.append("txNeg.aperture = ").append(num2string(txNeg.aperture)).append(";\n");
		config.append("txNeg.tableIndex = ").append(num2string(txNeg.tableIndex)).append(";\n");
		config.append("txNeg.useManualDelays = ").append(num2string(txNeg.useManualDelays)).append(";\n");

		config.append("rxNeg.acquisitionDepth = ").append(num2string(rxNeg.acquisitionDepth)).append(";\n");
		config.append("rxNeg.angle = ").append(num2string(rxNeg.angle)).append(";\n");
		config.append("rxNeg.aperture = ").append(num2string(rxNeg.aperture)).append(";\n");
		config.append("rxNeg.applyFocus = ").append(num2string(rxNeg.applyFocus)).append(";\n");
		config.append("rxNeg.centerElement = ").append(num2string(rxNeg.centerElement)).append(";\n");
		config.append("rxNeg.decimation = ").append(num2string(rxNeg.decimation)).append(";\n");
		config.append("rxNeg.maxApertureDepth = ").append(num2string(rxNeg.maxApertureDepth)).append(";\n");
		config.append("rxNeg.speedOfSound = ").append(num2string(rxNeg.speedOfSound)).append(";\n");
		config.append("rxNeg.useManualDelays = ").append(num2string(rxNeg.useManualDelays)).append(";\n");

		config.append("Storage path = ").append(storagePath).append(";\n");
		config.append("Config Path = ").append(configPath).append(";\n");
	}
	else
	{
		char buffer[128] = "";
		config.append("AcquisitionDuration = ").append(num2string(acquisitionDuration)).append(";\n");
		config.append("ScannerPresent = ").append(num2string(scannerPresent)).append(";\n");
		config.append("SectorialProbe = ").append(num2string(sectorialProbe)).append(";\n");
		m_texo.getProbeName(probeConnector, buffer, 128);//num2string(setorialProbe))
		config.append("Probe Name = ").append(buffer).append(";\n");


		config.append("txPos.pulseShape = ").append((txPos.pulseShape)).append(";\n");
		config.append("txPos.frequency = ").append(num2string(txPos.frequency)).append(";\n");
		config.append("txPos.focusDistance = ").append(num2string(txPos.focusDistance)).append(";\n");

		config.append("rxPos.acquisitionDepth = ").append(num2string(rxPos.acquisitionDepth)).append(";\n");
		config.append("rxPos.angle = ").append(num2string(rxPos.angle)).append(";\n");
		config.append("rxPos.applyFocus = ").append(num2string(rxPos.applyFocus)).append(";\n");
		config.append("rxPos.decimation = ").append(num2string(rxPos.decimation)).append(";\n");

		config.append("txNeg.pulseShape = ").append((txNeg.pulseShape)).append(";\n");
		config.append("txNeg.frequency = ").append(num2string(txNeg.frequency)).append(";\n");
		config.append("txNeg.focusDistance = ").append(num2string(txNeg.focusDistance)).append(";\n");

		config.append("rxNeg.acquisitionDepth = ").append(num2string(rxNeg.acquisitionDepth)).append(";\n");
		config.append("rxNeg.angle = ").append(num2string(rxNeg.angle)).append(";\n");
		config.append("rxNeg.applyFocus = ").append(num2string(rxNeg.applyFocus)).append(";\n");
		config.append("rxNeg.decimation = ").append(num2string(rxNeg.decimation)).append(";\n");

		config.append("Storage path = ").append(storagePath).append(";\n");
		config.append("Config Path = ").append(configPath).append(";\n");
	}
	return config;/**/
}
// ***********************************************************************************************
std::string TexoTools::num2string(int num)
{
	std::string str;
	char buffer[128];
	_itoa_s(num, buffer, 128, 10);
	str.append(buffer, strlen(buffer));
	return str;
}
