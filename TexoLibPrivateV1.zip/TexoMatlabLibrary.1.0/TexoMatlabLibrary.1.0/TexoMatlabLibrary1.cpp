//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//----------------------------------------------------------//


// Include the necessary header files:
#include "stdafx.h"
#include "TexoTools.h"

// Create a pointer to the TexoTools object for functions:
TexoTools * tx;
// (it will be assigned in the startEngine function)

//--------------------------------------------------------------------------------------
// HEADER
// Needed to create the library
//--------------------------------------------------------------------------------------

#define DLLEXPORT __declspec(dllexport)

#ifdef _MANAGED
#pragma managed(push, off)
#endif

BOOL APIENTRY DllMain( HMODULE hModule,
					  DWORD  ul_reason_for_call,
					  LPVOID lpReserved
					  )
{
	switch( ul_reason_for_call ) 
	{
	case DLL_PROCESS_ATTACH:
		//{TexoTools * tx = 0;}
		break;
	case DLL_THREAD_ATTACH:
		//...
		break;
	case DLL_THREAD_DETACH:
		//...
		break;
	case DLL_PROCESS_DETACH:
		{
			//int rep = tx->tlSequencer->message(89);
			tx->tlUtil->wait(1000);
			if(tx)
			{
				//rep = tx->tlSequencer->message(208);
				//tx->tlUtil->wait(3000);
				delete tx;
				break;	
			}
		}
		//...
	}/**/
	return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif

#ifdef __cplusplus
extern "C" {
#endif

//--------------------------------------------------------------------------------------
// USER FUNCTIONS (TEXOTOOLS)
//--------------------------------------------------------------------------------------

int DLLEXPORT loadConfigData(const char * configFilePathName)
{	return tx->loadConfigData(configFilePathName);}

int DLLEXPORT takeScan()
{	return tx->takeScan();}

int DLLEXPORT takeScanForDuration(int duration)
{	return tx->takeScan(duration);}

int DLLEXPORT saveData(char * fileName, int maxNumberOfFramesToSave)
{	return tx->saveData(fileName, maxNumberOfFramesToSave);}

int DLLEXPORT returnScannerSettings(bool allSettingsRequested)
{		return tx->returnScannerSettings(allSettingsRequested);}

//--------------------------------------------------------------------------------------
// SCANNER FUNCTIONS (SONIX) -- GENERAL
//--------------------------------------------------------------------------------------

int DLLEXPORT startEngine(char * settingsPath, int freq)
{
	try
	{
		if (!tx)					// If the pointer hasn't been assigned
		{
			tx = new TexoTools;		// Assign the pointer
		}
		return tx->tlSonix->startEngine(settingsPath, freq);

	}catch(char * )
	{
		return -110;	// EC: The TexoTools object could not be created
	}
}

int DLLEXPORT setPower(int power, int maxPositive, int maxNegative)
{	return tx->tlSonix->setPower(power, maxPositive, maxNegative);}

int DLLEXPORT startImaging()
{	return tx->tlSonix->startImaging();}

int DLLEXPORT stopImaging()
{	return tx->tlSonix->stopImaging();}

int DLLEXPORT stopEngine()
{	return tx->tlSonix->stopEngine();}

//--------------------------------------------------------------------------------------
// SCANNER FUNCTIONS (SONIX) -- VARIABLES
//--------------------------------------------------------------------------------------

int DLLEXPORT setFrequency(int freq)
{	return tx->tlSonix->setFrequency(freq);}

int DLLEXPORT setFocusDistance(int focus)
{	return tx->tlSonix->setFocusDistance(focus);}

int DLLEXPORT setAcquisitionDepth(int depth)
{	return tx->tlSonix->setAcquisitionDepth(depth);}

int DLLEXPORT setAngle(int angle)
{	return tx->tlSonix->setAngle(angle);}

int DLLEXPORT setCenterElement(int centerElement)
{	return tx->tlSonix->setCenterElement(centerElement);}

int DLLEXPORT setTxCenterElement(int centerElement)
{	return tx->tlSonix->setTxCenterElement(centerElement);}

int DLLEXPORT setRxCenterElement(int centerElement)
{	return tx->tlSonix->setRxCenterElement(centerElement);}

int DLLEXPORT setPulseShape(char *pulseShape)
{	return tx->tlSonix->setPulseShape(pulseShape);}

//--------------------------------------------------------------------------------------
// CREATE SEQUENCE FUNCTIONS (SEQUENCER) -- DEFINED SEQUENCES
//--------------------------------------------------------------------------------------

int DLLEXPORT createStandardSequence()
{	return tx->tlSequencer->createStandardSequence();}

int DLLEXPORT createStandardSequenceWithShape(char *pulseShape)
{	return tx->tlSequencer->createStandardSequence(pulseShape);}

int DLLEXPORT createAlternatingSequence()
{	return tx->tlSequencer->createAlternatingSequence();}

int DLLEXPORT createAlternatingSequenceWithShape(char *pulseShapeA, char *pulseShapeB)
{	return tx->tlSequencer->createAlternatingSequence(pulseShapeA, pulseShapeB);}

int DLLEXPORT createInvertingSequence()
{	return tx->tlSequencer->createInvertingSequence();}

int DLLEXPORT createInvertingSequenceWithShape(char *pulseShape)
{	return tx->tlSequencer->createInvertingSequence(pulseShape);}

int DLLEXPORT createDopplerSequence(char *pulseShape, int lineNumber, int repeat)
{	return tx->tlSequencer->createDopplerSequence(pulseShape, lineNumber, repeat);}

int DLLEXPORT createMDopplerSequence(char *pulseShape, int repeatCenter)
{	return tx->tlSequencer->createMDopplerSequence(pulseShape, repeatCenter);}

int DLLEXPORT createHighSpeedSequence(char *pulseShape, int numberLines, int depth, int txFrequency, int focusDistance)
{	return tx->tlSequencer->createHighSpeedSequence(pulseShape, numberLines, depth, txFrequency, focusDistance);}

//--------------------------------------------------------------------------------------
// CREATE SEQUENCE FUNCTIONS (SEQUENCER) -- CUSTOM SEQUENCES
//--------------------------------------------------------------------------------------

int DLLEXPORT beginSequence()
{	return tx->tlSequencer->beginSequence();}

int DLLEXPORT addLine()
{	return tx->tlSequencer->addLine();}

int DLLEXPORT endSequence()
{	return tx->tlSequencer->endSequence();}

//--------------------------------------------------------------------------------------
// FOOTER
// Needed to create the library
//--------------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif
