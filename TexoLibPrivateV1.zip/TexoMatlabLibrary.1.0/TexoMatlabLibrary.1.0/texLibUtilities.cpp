//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibUtilities: Utility functions used in the library	//
// but hidden from the Matlab user							//
//----------------------------------------------------------//

#include "stdafx.h"
#include "texo.h"
#include "texo_def.h"

#include "texLibUtilities.h"
#include "texLibVariables.h"

// To handle the wait function:
#include <sys/timeb.h>
#include <time.h>


texLibUtilities::texLibUtilities(void)
{
}

texLibUtilities::~texLibUtilities(void)
{
	tlv = NULL;
	m_texo = NULL;
	txParams = NULL;
	rxParams = NULL;
}

// --------------------------------------------------------------------------------------------------------------------
std::string texLibUtilities::trimString(std::string input)
{
	while((int)(input.end()-input.begin()) > 0 && input[0] == 32)
		input.erase(input.begin());

	while((int)(input.end()-input.begin()-1) > 0 && input[(int)(input.end()-input.begin())-1] == 32)
		input.erase(input.end()-1);

	return input;
}

// --------------------------------------------------------------------------------------------------------------------
std::string texLibUtilities::reverse(std::string text)
{
	std::string txet;
	int len;
	int j;

	txet.append(text);

	len = (int)text.length() - 1;

	for (j=0; j<=len; j++)
		txet[j] = text[len-j];

	return txet;
}
// --------------------------------------------------------------------------------------------------------------------
std::string texLibUtilities::num2string(int num)
{
	std::string str;
	char buffer[128];
	_itoa_s(num, buffer, 128, 10);
	str.append(buffer, strlen(buffer));
	return str;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibUtilities::wait(int delay)
{
	time_t ltime1;
	time_t ltime2;
	time(&ltime1);
	time(&ltime2);

	struct _timeb t1;
	struct _timeb t2;
	struct _timeb * tptr1 = &t1;
	struct _timeb * tptr2 = &t2;

	_ftime_s(tptr1);
	_ftime_s(tptr2);

	while((int)((ltime2-ltime1)*1000 + (int)(tptr2->millitm - tptr1->millitm)) <= delay)// offset is minimum and is for routine execution...
	{
		time(&ltime2);
		_ftime_s(tptr2);
	}

	return ((int)((ltime2-ltime1)*1000) + (int)(tptr2->millitm - tptr1->millitm));
}

// --------------------------------------------------------------------------------------------------------------------
std::string texLibUtilities::getToken(std::string tokenName)
{
	std::string token = "";
	try
	{
		std::basic_string <int>::size_type refIndex = tlv->configData.find(tokenName);
		std::basic_string <int>::size_type startIndex = tlv->configData.find("=", refIndex);
		std::basic_string <int>::size_type endIndex = tlv->configData.find(";", startIndex);
		if(refIndex != std::string::npos && startIndex != std::string::npos && endIndex != std::string::npos)
			token += tlv->configData.substr(startIndex + 1, endIndex - startIndex - 1);

	}catch(char * )
	{
		return token;
	}
	return token;
}

// --------------------------------------------------------------------------------------------------------------------
std::vector <int> texLibUtilities::getManualDelays(std::string tokenName)
{
	using namespace std;
	std::vector <int> delays(0);
	std::vector <int> emptyDelays(0);
	int index = 0;

	delays.reserve(128);
	std::string token;
	token.reserve(32);
	token = "";
	std::string rest = "   ";
	try
	{
		std::basic_string <int>::size_type refIndex = tlv->configData.find(tokenName);
		std::basic_string <int>::size_type startIndex = tlv->configData.find("=", refIndex);
		std::basic_string <int>::size_type endIndex = tlv->configData.find(";", startIndex);
		token += tlv->configData.substr(startIndex + 1, endIndex - startIndex - 1);
					// Could replace the above four lines with a call to getToken(tokenName)
					// but there's not much point since we need all the indices set up anyway

		refIndex = 1;
		startIndex = 1;
		endIndex = 1;
		token += ",";
		int tokenLength = (int)(token.end()-token.begin());
		while(endIndex != tokenLength-1)
		{
			endIndex = token.find(",", refIndex);
			rest = token.substr(startIndex, endIndex - startIndex);
			delays.push_back(atoi((rest).data()));
			startIndex = refIndex = endIndex + 1;
			index++;
		}

	}catch(char * )
	{
		return emptyDelays;
	}

	return delays;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibUtilities::message(char * varName, double num)
{
	engine *matlabEngine;

	mxArray *data_m1;
	data_m1 = mxCreateDoubleMatrix(1,1,mxREAL);
	memcpy((char *)mxGetPr(data_m1),(char *)&num,sizeof(double));

	matlabEngine = engOpen(NULL);
	engPutVariable(matlabEngine, varName, data_m1);
	mxDestroyArray(data_m1);
	engClose(matlabEngine);

	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibUtilities::getParameterValue(std::string token, int defaultValue)
{
	std::string value;
	value.reserve(128);
	value = "";
	
	try {
		value = getToken(token);
		if (value == "")
			return defaultValue;
		else
			return atoi(value.data());

	}catch(char *)
	{
		return defaultValue;
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibUtilities::getParameterValue(std::string token, unsigned long defaultValue)
{
	std::string value;
	value.reserve(128);
	value = "";
	
	try {
		value = getToken(token);
		if (value == "")
			return (int)defaultValue;
		else
			return atoi(value.data());

	}catch(char *)
	{
		return (int)defaultValue;
	}
}

// --------------------------------------------------------------------------------------------------------------------
std::string texLibUtilities::getParameterValue(std::string token, char * defaultValue)
{
	std::string value;
	value.reserve(128);
	value = "";
	
	try {
		value = getToken(token);
		if (value == "")
			return defaultValue;
		else
			return trimString(value);

	}catch(char *)
	{
		return defaultValue;
	}
}

// --------------------------------------------------------------------------------------------------------------------
bool texLibUtilities::getParameterValue(std::string token, bool defaultValue)
{
	std::string value;
	value.reserve(128);
	value = "";
	
	try {
		value = getToken(token);
		if (value == "")
			return defaultValue;
		if (value == "1")
			return true;
		else
			return false;

	}catch(char *)
	{
		return defaultValue;
	}
}


