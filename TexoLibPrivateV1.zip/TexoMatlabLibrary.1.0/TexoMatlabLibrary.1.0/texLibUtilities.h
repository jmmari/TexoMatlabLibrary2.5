//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibUtilities: Utility functions used in the library	//
// but hidden from the Matlab user							//
//----------------------------------------------------------//

#pragma once

#include <vector>

#include "texLibVariables.h"
#include "texo.h"
#include "texo_def.h"

class texLibUtilities
{
public:

	// SETS UP THE ULTRASONIX DEFINED OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texo * m_texo;						// Allows us to call the functions provided by UltraSonix
	texoTransmitParams * txParams;		// Transmission profile
	texoReceiveParams * rxParams;		// Reception profile

	// SETS UP OUR OWN OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texLibVariables * tlv;				// Contains the parameters associated with the sequence and scan

	// CONSTRUCTOR/DESTRUCTOR
	// --------------------------------------------------------------------------------------------------------
	texLibUtilities(void);
	~texLibUtilities(void);

	// TEXOTOOLS FUNCTIONS -- PUBLIC
	// --------------------------------------------------------------------------------------------------------
	std::string trimString(std::string input);
	// removes any spaces from the begin of a string and returns a string without those spaces
	std::string reverse(std::string text);
	// reverses the input string, returning a string with the same characters but backwards
	std::string num2string(int num);
	// converts the input num to a string and returns it
	int wait(int delay);
	// pauses for the specified delay (in milliseconds)
	int message(char * varName, double num);
	// creates a variable in the Matlab environment called varName with value num
	std::string getToken(std::string tokenName);
	// reads tlv->configData to get find the value of the parameter tokenName
	std::vector <int> getManualDelays(std::string tokenName);
	// finds the transmit or receive delays (depending on tokenName) and converts them to integers
	int getParameterValue(std::string token, int defaultValue);
	int getParameterValue(std::string token, unsigned long defaultValue);
	std::string getParameterValue(std::string token, char * defaultValue);
	bool getParameterValue(std::string token, bool defaultValue);
	// find the value of the parameter token, and return it in the appropriate data format
};
