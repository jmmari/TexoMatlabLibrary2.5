#pragma once

class essai
{
public:
	essai(void);
public:
	~essai(void);
};
