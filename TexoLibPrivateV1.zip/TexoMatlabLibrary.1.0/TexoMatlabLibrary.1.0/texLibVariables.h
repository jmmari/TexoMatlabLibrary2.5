//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibVariables: A class containing all of the variables	//
// which the library needs to access to carry out the scan	//
//----------------------------------------------------------//

#pragma once

#include "texo.h"
#include "texo_def.h"

class texLibVariables
{
public:

	// INTERNAL LIBRARY VARIABLES
	// --------------------------------------------------------------------------------------------------------
	bool scannerPresent;			// true if the scanner is present
	bool readyToScan;				// true if the scanner is ready to scan
	bool creatingCustomSequence;	// true if a custom sequence definition has been started
	bool videoOn;					// true if the video feed is enabled
	
	std::string configPath; 		// path string for the config file with the parameters
	std::string configData; 		// string that stores the parameters

	// VARIBALES CONTAINING VALUES OF PARAMETERS IN THE SCANNER
	// --------------------------------------------------------------------------------------------------------
	int probeConnector;				// the port that the probe is connected to
	int sectorialProbe; 			// 1 if probe is sectorial, 0 otherwise
	int samplingFreq;				// the frequency that was used to initialise the scanner
	int power;						// the overall power
	int maxPositivePower;			// the max power allowed on a positive transmit
	int maxNegativePower;			// the max power allowed on a negative transmit
	float TGC;						// the time gain compensation curve in use

	// VARIABLES DESCRIBING THE DATA THAT HAS BEEN IMAGED
	// --------------------------------------------------------------------------------------------------------
	int imagingMode;				// the image type
	int subMode;					// the specific imaging mode
	int totalLineNumber;			// the number of lines in each frame
	int numberDopplerLines;			// the number of Doppler lines in each frame
	int highSpeedLineNumber;		// the number of lines in the high speed sequence

	int centerElement[2048];		// an array containing the center element of each line
	int angle[2048];				// an array containing the steering angle of each line
	std::string pulseShape[2048];	// an array containing the pulse shape of each line

	// VARIABLES DEFINING WHAT PARAMETERS THE SCAN SHOULD HAVE
	// --------------------------------------------------------------------------------------------------------
	std::string pulseShapeA;		// shape of the first pulse for alternating sequences (also used for pulse shape of non-alternating sequences)
	std::string pulseShapeB;		// shape of the second pulse for alternating sequences
	std::string storagePath; 		// target path string for the data saved by the library
	int numberFramesToSave; 		// number of frames saved in the results file
	int scanDuration; 				// time to wait between starting and stopping the image
	int inputSignalConfig;			// allow programming output delivery of sync signals
	int outputSignalConfig1;		// allow programming output delivery of sync signals
	int outputSignalConfig2;		// allow programming output delivery of sync signals

};

