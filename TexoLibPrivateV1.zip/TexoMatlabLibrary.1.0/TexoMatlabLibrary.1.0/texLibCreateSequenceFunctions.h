//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibCreateSequenceFunctions: Functions to create the	//
// various scan sequences which are required by the user	//
//----------------------------------------------------------//

#pragma once

#include "texLibUtilities.h"
#include "texLibVariables.h"
#include "texo.h"
#include "texo_def.h"

#define NUMCHANNELS		32

class texLibCreateSequenceFunctions
{
public:

	// SETS UP THE ULTRASONIX DEFINED OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texo * m_texo;						// Allows us to call the functions provided by UltraSonix
	texoTransmitParams * txParams;		// Transmission profile
	texoReceiveParams * rxParams;		// Reception profile

	// SETS UP OUR OWN OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texLibUtilities * tlUtil;			// Contains utility functions needed by the other objects
	texLibVariables * tlv;				// Contains the parameters associated with the sequence and scan

	// CONSTRUCTOR/DESTRUCTOR
	// --------------------------------------------------------------------------------------------------------
	texLibCreateSequenceFunctions();
	~texLibCreateSequenceFunctions();

	// SEQUENCER FUNCTIONS -- PUBLIC -- DEFINED SEQUENCES
	// --------------------------------------------------------------------------------------------------------
	int createStandardSequence();
	int createStandardSequence(char *pulseShape);
		// create a standard imaging sequence
	int createAlternatingSequence();
	int createAlternatingSequence(char *pulseShapeA, char *pulseShapeB);
		// create an alternating sequence, where every line has two pulse shapes transmitted
	int createInvertingSequence();
	int createInvertingSequence(char *pulseShape);
		// create an inverting sequence, where every line has the pulse and its inverse transmitted
	int createHighSpeedSequence(char *pulseShape, int numberLines, int depth, int txFrequency, int focusDistance);
		// creates a sequence with customisable parameters
	int createDopplerSequence(char *pulseShape, int lineNumber, int repeat);
		// creates a Doppler sequence, where the entire image is repeated several times
	int createMDopplerSequence(char *pulseShape, int repeatCenter);
		// creates an M-mode Doppler sequence, a B-mode image with the center line repeated many times

	// SEQUENCER FUNCTIONS -- PUBLIC -- DEFINED SEQUENCES
	// --------------------------------------------------------------------------------------------------------
	int beginSequence();
		// begins a new sequence definition
	int addLine();
		// adds a line to the sequence definition
	int endSequence();
		// ends the sequence definition

private:

	// SEQUENCER FUNCTIONS -- PRIVATE
	// --------------------------------------------------------------------------------------------------------
	std::string inversePulse(std::string pulse);
		// Takes a pulse shape and returns the inverted shape
	std::vector <int> getSequenceValues(std::string sequence, int number);
		// Decodes the input string inot a vecotr of integers
};
