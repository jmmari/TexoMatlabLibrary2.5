//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibScannerFunctions: Functions to call the UltraSonix	//
// provided functions which directly control the scanner	//
//----------------------------------------------------------//

#pragma once

#include "texLibUtilities.h"
#include "texLibVariables.h"
#include "texo.h"
#include "texo_def.h"

class texLibScannerFunctions
{
public:

	// SETS UP THE ULTRASONIX DEFINED OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texo * m_texo;						// Allows us to call the functions provided by UltraSonix
	texoTransmitParams * txParams;		// Transmission profile
	texoReceiveParams * rxParams;		// Reception profile

	// SETS UP OUR OWN OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texLibUtilities * tlUtil;			// Contains utility functions needed by the other objects
	texLibVariables * tlv;				// Contains the parameters associated with the sequence and scan

	// CONSTRUCTOR/DESTRUCTOR
	// --------------------------------------------------------------------------------------------------------
	texLibScannerFunctions(void);
	~texLibScannerFunctions(void);

	// SCANNER FUNCTIONS -- GENERAL
	// --------------------------------------------------------------------------------------------------------
	int startEngine(char * settingsPath, int freq);
		// starts the scanner's electronics
	int setPower(int power, int maxPositive, int maxNegative);
		// sends these power values to the scanner
	int startImaging();
		// begins an image
	int stopImaging();
		// stops the image
	int stopEngine();
		// turns off the scanner's electronics

	// SCANNER FUNCTIONS -- UPDATING VARIABLES
	// --------------------------------------------------------------------------------------------------------
	int setFrequency(int newFreq);
		// changes txParams->frequency
	int setFocusDistance(int newFocus);
		// changes txParams->focusDistance
	int setAcquisitionDepth(int newDepth);
		// changes rxParams->acquisitionDepth
	int setAngle(int newAngle);
		// changes txParams->angle
	int setCenterElement(int newCenterElement);
		// changes txParams->centerElement and rxParams->centerElement
	int setTxCenterElement(int newCenterElement);
		// changes txParams->centerElement
	int setRxCenterElement(int newCenterElement);
		// changes rxParams->centerElement
	int setPulseShape(char *newPulseShape);
		// changes txParams->pulseShape
};
