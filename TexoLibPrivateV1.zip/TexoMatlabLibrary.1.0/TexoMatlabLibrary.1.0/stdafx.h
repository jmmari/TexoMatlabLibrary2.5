//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//----------------------------------------------------------//

//--------------------------------------------------------------------------------------
// CREATED BY THE COMPILER
// These commands prepare the library for use
//--------------------------------------------------------------------------------------

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//
#define _CRT_SECURE_NO_DEPRECATE 1

#define _CRT_NONSTDC_NO_DEPRECATE 1


#pragma once

// Modify the following defines if you have to target a platform prior to the ones specified below.
// Refer to MSDN for the latest info on corresponding values for different platforms.
#ifndef WINVER				// Allow use of features specific to Windows XP or later.
#define WINVER 0x0501		// Change this to the appropriate value to target other versions of Windows.
#endif

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#ifndef _WIN32_WINDOWS		// Allow use of features specific to Windows 98 or later.
#define _WIN32_WINDOWS 0x0410 // Change this to the appropriate value to target Windows Me or later.
#endif

#ifndef _WIN32_IE			// Allow use of features specific to IE 6.0 or later.
#define _WIN32_IE 0x0600	// Change this to the appropriate value to target other versions of IE.
#endif

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <String>
#include "engine.h"
#include "mucro.h"
//#define EXPORT_FCNS
#define DLLEXPORT __declspec(dllexport)

// TODO: reference additional headers your program requires here


//--------------------------------------------------------------------------------------
// TEXO LIBRARY FUNCTION DECLARATIONS
// Note, these have to be defined as C functions, hence the top and bottom lines
//--------------------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

// TexoTools functions
	int DLLEXPORT loadConfigData(const char * configFilePathName);
	int DLLEXPORT takeScan();
	int DLLEXPORT takeScanForDuration(int duration);
	int DLLEXPORT saveData(char * fileName, int maxNumberOfFramesToSave);
	int DLLEXPORT returnScannerSettings(bool allSettingsRequested);

// Scanner functions (general)
	int DLLEXPORT startEngine(char * settingsPath, int freq);
	int DLLEXPORT setPower(int power, int maxPositive, int maxNegative);
	int DLLEXPORT startImaging();
	int DLLEXPORT stopImaging();
	int DLLEXPORT stopEngine();

// Scanner functions (set variables)
	int DLLEXPORT setFrequency(int freq);
	int DLLEXPORT setFocusDistance(int focus);
	int DLLEXPORT setAcquisitionDepth(int depth);
	int DLLEXPORT setAngle(int angle);
	int DLLEXPORT setCenterElement(int centerElement);
	int DLLEXPORT setTxCenterElement(int centerElement);
	int DLLEXPORT setRxCenterElement(int centerElement);
	int DLLEXPORT setPulseShape(char *pulseShape);

// Sequencer functions (definied sequences)
	int DLLEXPORT createStandardSequence();
	int DLLEXPORT createStandardSequenceWithShape(char *pulseShape);
	int DLLEXPORT createAlternatingSequence();
	int DLLEXPORT createAlternatingSequenceWithShape(char *pulseShapeA, char *pulseShapeB);
	int DLLEXPORT createInvertingSequence();
	int DLLEXPORT createInvertingSequenceWithShape(char *pulseShape);
	int DLLEXPORT createDopplerSequence(char *pulseShape, int lineNumber, int repeat);
	int DLLEXPORT createMDopplerSequence(char *pulseShape, int repeatCenter);
	int DLLEXPORT createHighSpeedSequence(char *pulseShape, int numberLines, int depth, int txFrequency, int focusDistance);

// Sequencer functions (custom sequences)
	int DLLEXPORT beginSequence();
	int DLLEXPORT addLine();
	int DLLEXPORT endSequence();

#ifdef __cplusplus
}
#endif


