//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibScannerFunctions: Functions to call the UltraSonix	//
// provided functions which directly control the scanner	//
//----------------------------------------------------------//

#include "stdafx.h"

#include "texLibScannerFunctions.h"
#include "texLibUtilities.h"
#include "texLibVariables.h"

#include "texo.h"
#include "texo_def.h"

texLibScannerFunctions::texLibScannerFunctions(void)
{
}

texLibScannerFunctions::~texLibScannerFunctions(void)
{
	tlv = NULL;
	tlUtil = NULL;
	m_texo = NULL;
	txParams = NULL;
	rxParams = NULL;
}

// --------------------------------------------------------------------------------------------------------------------
// THE GENERAL FUNCTIONS
// --------------------------------------------------------------------------------------------------------------------

int texLibScannerFunctions::startEngine(char * settingsPath, int freq)
{
	tlv->readyToScan = false;

	try
	{
		if((tlv->scannerPresent) && !(m_texo->isInitialized()))
		{
			if (freq == 40)
			{
				tlv->samplingFreq = 40000000;
				if (!m_texo->init(settingsPath, 2,2,0,0,1))
					return -312;	// EC: call to init failed
			}
			if (freq == 20)
			{
				tlv->samplingFreq = 20000000;
				if (!m_texo->init(settingsPath, 2,2,0,0,0))
					return -312;	// EC: call to init failed
			}
			if ((freq!=20) && (freq!=40))
			{
				tlv->samplingFreq = 20000000;
				if (m_texo->init(settingsPath, 2,2,0,0,0))
					return -313;	// EC: invalid frequency requested by user - 20MHz used as default
				else
					return -312;	// EC: call to init failed
			}
			return 0;		// This point can only be reached if init is called successfully
		}
		else
			return -311;	// EC: scanner is not present or is already initialised

	}catch(char *)
	{
		return -310;		// EC: some problem in startEngine(char*,int)
	}
	
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setPower(int power, int maxPositive, int maxNegative)
{
	try
	{
		if((tlv->scannerPresent) && m_texo->isInitialized() && !m_texo->isImaging())
		{
			if (power<0 || power>15 || maxPositive<0 || maxNegative>15 || maxPositive<0 || maxNegative>15)
				return -322;	// EC: power values are outside required range (0-15)
			else
			{
				if (m_texo->setPower(power, maxPositive, maxNegative))
				{
					tlv->power = power;
					tlv->maxPositivePower = maxPositive;
					tlv->maxNegativePower = maxNegative;
					return 0;
				}
				else
					return -323;	// EC: call to setPower failed
			}
		}
		else
			return -321;

	}catch(char * )
	{
		return -320;		// EC: some problem with setPower(int,int,int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::startImaging()
{
	try
	{
		if(tlv->readyToScan && tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->readyToScan = false;
			if (m_texo->runImage())
				return 0;
			else
				return -332;	// EC: call to runImage failed
		}
		else
			return -331;		// EC: scanner is not present or initialised or is already imaging
	}catch(char * )
	{
		return -330;			// EC: some problem in startImaging()
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::stopImaging()
{
	try
	{
		if(tlv->scannerPresent && m_texo->isImaging())
		{
			if (m_texo->stopImage())
			{
				tlv->readyToScan = true;
				return 0;
			}
			else
				return -342;	// EC: call to stopImage failed
		}
		else
			return -341;		// EC: scanner is not present or is not imaging
	}catch(char * )
	{
		return -340;			// EC: some problem in stopImaging()
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::stopEngine()
{
	try{
		if((tlv->scannerPresent) && (m_texo->isInitialized()))
			if (m_texo->shutdown())
			{
				tlv->readyToScan = false;
				return 0;
			}
			else
				return -352;	// EC: call to shutdown failed
		else
			return -351;		// EC: scanner is not present or is not initialised
	}catch(char * )
	{
		return -350;	// EC: some error in stopEngine()
	}
}

// --------------------------------------------------------------------------------------------------------------------
// THE VARIALBE-SETTING FUNCTIONS
// --------------------------------------------------------------------------------------------------------------------

int texLibScannerFunctions::setFrequency(int newFreq)
{
	try
	{
		txParams->frequency = newFreq;
		return 0;

	}catch(char *)
	{
		return -361;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setFocusDistance(int newFocus)
{
	try
	{
		txParams->focusDistance = newFocus;
		return 0;

	}catch(char *)
	{
		return -362;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setAcquisitionDepth(int newDepth)
{
	try
	{
		rxParams->acquisitionDepth = newDepth;
		return 0;

	}catch(char *)
	{
		return -363;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setAngle(int newAngle)
{
	try
	{
		txParams->angle = newAngle;
		return 0;

	}catch(char *)
	{
		return -364;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setCenterElement(int newCenterElement)
{
	try
	{
		txParams->centerElement = newCenterElement;
		rxParams->centerElement = newCenterElement;
		return 0;

	}catch(char *)
	{
		return -365;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setTxCenterElement(int newCenterElement)
{
	try
	{
		txParams->centerElement = newCenterElement;
		return 0;

	}catch(char *)
	{
		return -366;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setRxCenterElement(int newCenterElement)
{
	try
	{
		rxParams->centerElement = newCenterElement;
		return 0;

	}catch(char *)
	{
		return -367;		// EC: some problem in setFrequency(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int texLibScannerFunctions::setPulseShape(char *newPulseShape)
{
	try
	{
		tlv->pulseShapeA = "";
		tlv->pulseShapeA.append(newPulseShape);
		strcpy_s(txParams->pulseShape, tlv->pulseShapeA.data());

		return 0;

	}catch(char *)
	{
		return -368;		// EC: some problem in setFrequency(char*)
	}
}

