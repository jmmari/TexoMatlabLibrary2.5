#include "StdAfx.h"
#include "essai.h"

essai::essai(void)
{
}

essai::~essai(void)
{
}
