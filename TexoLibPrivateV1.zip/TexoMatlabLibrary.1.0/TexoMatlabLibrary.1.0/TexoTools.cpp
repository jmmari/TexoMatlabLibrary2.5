//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// TexoTools: Contains basic functions which will be called	//
// by the user for every scan and creates the other objects	//
//----------------------------------------------------------//

// --------------------------------------------------------------------------------------------------------------------
// INCLUDES:
// --------------------------------------------------------------------------------------------------------------------
#include <string.h>
#include <fstream>
#include "engine.h"

#include "stdafx.h"
#include "texo.h"
#include "texo_def.h"

#include "TexoTools.h"
#include "texLibCreateSequenceFunctions.h"
#include "texLibScannerFunctions.h"
#include "texLibUtilities.h"
#include "texLibVariables.h"


// --------------------------------------------------------------------------------------------------------------------
// CONSTRUCTOR / DESTRUCTOR
// --------------------------------------------------------------------------------------------------------------------

TexoTools::TexoTools()
{
	tlv = new texLibVariables();
	tlUtil = new texLibUtilities();
	tlSequencer = new texLibCreateSequenceFunctions();
	tlSonix = new texLibScannerFunctions();

	tlv->scannerPresent = true;

	// Pass the addresses of the other objects to pointers in the sequencer object:
	tlSequencer->tlv = tlv;
	tlSequencer->tlUtil = tlUtil;
	tlSequencer->m_texo = &m_texo;
	tlSequencer->txParams = &txParams;
	tlSequencer->rxParams = &rxParams;

	// Pass the addresses of the other objects to pointers in the scanner functions object:
	tlSonix->tlv = tlv;
	tlSonix->tlUtil = tlUtil;
	tlSonix->m_texo = &m_texo;
	tlSonix->txParams = &txParams;
	tlSonix->rxParams = &rxParams;

	// Pass the addresses of the other objects to pointers in the utility functions object:
	tlUtil->tlv = tlv;
	tlUtil->m_texo = &m_texo;
	tlUtil->txParams = &txParams;
	tlUtil->rxParams = &rxParams;
}
TexoTools::~TexoTools(void)
{
	tlv = NULL;
	tlUtil = NULL;
	tlSequencer = NULL;
	tlSonix = NULL;
}


// --------------------------------------------------------------------------------------------------------------------
// THE PUBLIC FUNCTIONS
// --------------------------------------------------------------------------------------------------------------------

int TexoTools::loadConfigData(const char * configFilePathName)
{
	std::string tempString;
	int i;		// counter
	int ret;	// will be returned to Matlab

	try
	{
		ret = readConfigFile(configFilePathName);
		if (ret != 0)
			return ret;

		// ---------------------------------------------------------------------
		// Find the values of the Texo Library variables

		tlv->inputSignalConfig = tlUtil->getParameterValue("InputSignalConfig", 0);
		tlv->outputSignalConfig1 = tlUtil->getParameterValue("OutputSignalConfig1", 0);
		tlv->outputSignalConfig2 = tlUtil->getParameterValue("OutputSignalConfig2", 0);

		tlv->scanDuration = tlUtil->getParameterValue("scanDuration", 1000);
		tlv->power = tlUtil->getParameterValue("power", 1);
		tlv->maxPositivePower = tlUtil->getParameterValue("maxPositivePower", 1);
		tlv->maxNegativePower = tlUtil->getParameterValue("maxNegativePower", 1);
		tlv->TGC = (float)tlUtil->getParameterValue("TGC", 1);

		tlv->probeConnector = tlUtil->getParameterValue("probeConnector", 1);
		tlv->sectorialProbe = tlUtil->getParameterValue("sectorialProbe", 0);
		tlv->numberFramesToSave = tlUtil->getParameterValue("numberFramesToSave", 1);
		tlv->storagePath = tlUtil->getParameterValue("dataFileName", "currentRfFrame.bin");

		tlv->imagingMode = 0;
		tlv->subMode = 0;
		tlv->numberDopplerLines = 0;
		tlv->highSpeedLineNumber = 0;
		tlv->totalLineNumber = 0;

		tlv->pulseShapeA = tlUtil->getParameterValue("pulseShapeA", "+-");
		tlv->pulseShapeB = tlUtil->getParameterValue("pulseShapeB", "-+");

		ret = settingsToScanner();		// Loads the appropriate settings to the scanner

		// ---------------------------------------------------------------------
		// Find the values of the transmit parameters

		txParams.centerElement = tlUtil->getParameterValue("txCenterElement", 0);
		txParams.focusDistance = tlUtil->getParameterValue("txFocusDistance", 50000);
		txParams.angle = tlUtil->getParameterValue("txAngle", 0);
		txParams.tableIndex = tlUtil->getParameterValue("txTableIndex", -1);
		txParams.speedOfSound = tlUtil->getParameterValue("txSpeedOfSound", 1540);

		txParams.frequency = tlUtil->getParameterValue("txCenterFrequency", 0);
		if (txParams.frequency == 0 && tlv->scannerPresent)
			txParams.frequency = m_texo.getProbeCenterFreq();

		std::string channels = "NUMCHANNELS";
		tempString = tlUtil->getParameterValue("txAperture", "NUMCHANNELS");
		if (tempString.find(channels) == std::string::npos)
			txParams.aperture = atoi(tempString.data());
		else
			txParams.aperture = NUMCHANNELS;

		txParams.useManualDelays = tlUtil->getParameterValue("txUseManualDelays", false);

		if (txParams.useManualDelays)
		{
			std::vector <int> txDelays = tlUtil->getManualDelays("txManualDelays");
			if(!txDelays.empty())
				{
					int len = (int)txDelays.size();
					for (i=0; i<len; i++)
						txParams.manualDelays[i] = txDelays.at(i);
				}
			else
				txParams.useManualDelays = false;
		}

		txParams.useDeadElements = tlUtil->getParameterValue("txUseDeadElements", false);

		// ---------------------------------------------------------------------
		// Find the values of the receive parameters

		rxParams.centerElement = tlUtil->getParameterValue("rxCenterElement", 0);
		rxParams.angle = tlUtil->getParameterValue("rxAngle", 0);
		rxParams.maxApertureDepth = tlUtil->getParameterValue("rxMaxApertureDepth", 50000);
		rxParams.acquisitionDepth = tlUtil->getParameterValue("rxAcquisitionDepth", 100000);
		rxParams.speedOfSound = tlUtil->getParameterValue("rxSpeedOfSound", 1540);
		rxParams.channelMask[0] = tlUtil->getParameterValue("rxChannelMask[0]", 4294967295);
		rxParams.channelMask[1] = tlUtil->getParameterValue("rxChannelMask[1]", 4294967295);
		rxParams.applyFocus = tlUtil->getParameterValue("rxApplyFocus", true);
		rxParams.tableIndex = tlUtil->getParameterValue("rxTableIndex", -1);
		rxParams.customLineDuration = tlUtil->getParameterValue("rxCustomLineDuration", 0);
		rxParams.decimation = tlUtil->getParameterValue("rxDecimation", 1);
		rxParams.lgcValue = tlUtil->getParameterValue("rxLgcValue", 0);
		rxParams.tgcSel = tlUtil->getParameterValue("rxTgcSel", 0);

		tempString = tlUtil->getParameterValue("rxAperture", "NUMCHANNELS");
		if (tempString.find(channels) == std::string::npos)
			rxParams.aperture = atoi(tempString.data());
		else
			rxParams.aperture = NUMCHANNELS;

		rxParams.useManualDelays = tlUtil->getParameterValue("rxUseManualDelays", false);

		if (rxParams.useManualDelays)
		{
			std::vector <int> rxDelays = tlUtil->getManualDelays("rxManualDelays");
			if(!rxDelays.empty())
			{
				int len = (int)rxDelays.size();
				for (i=0; i<len; i++)
					rxParams.manualDelays[i] = rxDelays.at(i);
			}
			else
				rxParams.useManualDelays = false;
		}

		return ret;		// EC: will be zero if settingsToScanner worked, or have that function's error code if not

	}catch(char * )
	{
		return -210;	// EC: some problem with loadConfigData(char*)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int TexoTools::takeScan(int duration)
{
	try
	{
		tlv->scanDuration = duration;	// Updates the scan time variable

		if(tlv->scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			tlv->readyToScan = false;
			if (!m_texo.runImage())
				return -232;			// EC: call to runImage failed
			tlUtil->wait(duration);		// So the scan lasts for the correct time interval
			if (!m_texo.stopImage())
				return -233;			// EC: call to stopImage failed
			tlv->readyToScan = true;
			return 0;
		}
		else
			return -231;	// EC: scanner is not present or initialised or is already imaging
	}catch(char * )
	{
		return -230;		// EC: some problem with takeScan(int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int TexoTools::takeScan()
{
	int ret;

	try
	{
		if (tlv->scanDuration > 0)
		{
			ret = takeScan(tlv->scanDuration);
			if (ret != 0)
				ret -= 10;	// Because error codes for this function being 24
			return ret;
		}
		else
			return -244;	// EC: the scan duration has not been preset

	}catch(char * )
	{
		return -240;		// EC: some problem with takeScan()
	}
}

// --------------------------------------------------------------------------------------------------------------------
int TexoTools::saveData(char * fileName, int maxNumberOfFramesToSave)
{
	int i,j;			// Counters
	int numberOfFrames;	// How many frames the scanner has
	int frameSize;		// The size of each frame
	int tempInt;		// Stores the value of the current parameter
	double tempDouble;	// Stores the value of the current parameter
	char tempChar;		// Stores the value of the current parameter
	int headerSize = 0;	// Counter which tracks size of the data header
	FILE * fp;			// A pointer to the save file

	std::string tempString, Stringtemp;

	try
	{
		if(tlv->scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			numberOfFrames = m_texo.getCollectedFrameCount();
			if(numberOfFrames < 1)
				return -252;		// EC: the scanner has no frames to save

			if(numberOfFrames >= maxNumberOfFramesToSave)
				numberOfFrames = maxNumberOfFramesToSave;	// Ensures no more than the frame limit are saved

			fopen_s(&fp, fileName, "wb+");
			if(!fp)
				return -253;		// EC: the save file will not open

			// Save the frame size to the file header
			frameSize = m_texo.getFrameSize();
			fwrite(&frameSize, sizeof(frameSize), 1, fp);
			headerSize += sizeof(frameSize);

			// Save the number of frames to the file header
			fwrite(&numberOfFrames, sizeof(numberOfFrames), 1, fp);
			headerSize += sizeof(numberOfFrames);

			// Save the total number of lines to the file header
			tempInt = tlv->totalLineNumber;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the number of doppler lines to the file header
			if (tlv->imagingMode==3)		// If we're in Doppler mode
			{
				tempInt = tlv->numberDopplerLines;
				fwrite(&tempInt, sizeof(tempInt), 1, fp);
				headerSize += sizeof(tempInt);
			}
			else						// If we're not in Doppler mode
			{
				tempInt = 0;
				fwrite(&tempInt, sizeof(tempInt), 1, fp);
				headerSize += sizeof(tempInt);
			}

			// Save the frame rate to the file header
			tempDouble = m_texo.getFrameRate();
			fwrite(&tempDouble, sizeof(tempDouble), 1, fp);
			headerSize += sizeof(tempDouble);

			// Save the number of probe elements to the file header
			tempInt = m_texo.getProbeNumElements();
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save whether a sectorial probe was used to the file header
			tempInt = tlv->sectorialProbe;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the imaging mode to the file header
			tempInt = tlv->imagingMode;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the imaging submode to the file header
			tempInt = tlv->subMode;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

				// scanningMode 1 = basic RF mode
				//					1.1 = basic RF mode
				//					1.2 = high speed
				// scanningMode 2 = multi-pulse modes
				//					2.1 = inverting sequence
				//					2.2 = alternating sequence
				// scanningMode 3 = doppler modes
				//					3.1 = B-mode + Doppler repeat of center
				//					3.2 = doppler
				// scanningMode 4 = custom sequence

			// Save the sampling frequency to the file header
			tempInt = tlv->samplingFreq;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the transmit frequency to the file header
			tempInt = txParams.frequency;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the transmit focus to the file header
			tempInt = txParams.focusDistance;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Save the receive depth to the file header
			tempInt = rxParams.acquisitionDepth;
			fwrite(&tempInt, sizeof(tempInt), 1, fp);
			headerSize += sizeof(tempInt);

			// Bring the header up to 1024 byte standard size:
			if (headerSize > 1024)
				return -254;		// EC: The header has exceded the 1024 byte size limit

			tempInt = 0;
			while (headerSize <1024)
			{
				fwrite(&tempInt, sizeof(tempInt), 1, fp);
				headerSize += sizeof(tempInt);
			}

			// Write the actual frames:
			fwrite(m_texo.getCineStart(), frameSize, numberOfFrames, fp);

			// Write the sequence of center elements
			for (i=1; i<=tlv->totalLineNumber; i++)
			{
				tempInt = tlv->centerElement[i-1];
				fwrite(&tempInt, sizeof(tempInt), 1, fp);
			}

			// Write the sequence of angles
			for (i=1; i<=tlv->totalLineNumber; i++)
			{
				tempInt = tlv->angle[i-1];
				fwrite(&tempInt, sizeof(tempInt), 1, fp);
			}

			// Write the pulse shape
			for (i=1; i<=tlv->totalLineNumber; i++)
			{
				j = 0;
				do
				{
					tempChar = tlv->pulseShape[i-1][j];
					fwrite(&tempChar, sizeof(tempChar), 1, fp);
					j++;
				} while (tempChar != ';');
			}

			// Close the file
			if (fclose(fp) != 0)	// fclose returns 0 if successful
				return -255;		// EC: The save file could not be closed

			return 0;
		}
		else
			return -251;	// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -250;		// EC: some problem with saveData(char*, int)
	}
}

// --------------------------------------------------------------------------------------------------------------------
int TexoTools::returnScannerSettings(bool allSettingsRequested)
{
	engine *matlabEngine;

	int ret;			// Returns from function calls
	int numSettings;	// Number of settings to be returned
	double data_f[42];	// Data for the full report
	double data_p[9];	// Data for the partial report
 
	try
	{
		matlabEngine = engOpen(NULL);

		if (matlabEngine == NULL)
		   return -261;      // EC: the Matlab engine did not open

		if (allSettingsRequested)
		{
			numSettings = 42;

			data_f[0] = (double)tlv->samplingFreq;
			data_f[1] = (double)tlv->power;
			data_f[2] = (double)tlv->maxPositivePower;
			data_f[3] = (double)tlv->maxNegativePower;
			data_f[4] = (double)tlv->TGC;
			data_f[5] = (double)tlv->inputSignalConfig;
			data_f[6] = (double)tlv->outputSignalConfig1;
			data_f[7] = (double)tlv->outputSignalConfig2;
			data_f[8] = (double)tlv->scannerPresent;
			data_f[9] = (double)tlv->readyToScan;
			data_f[10] = (double)tlv->sectorialProbe;
			data_f[11] = (double)tlv->probeConnector;
			data_f[12] = (double)tlv->numberFramesToSave;
			data_f[13] = (double)tlv->scanDuration;
			data_f[14] = (double)tlv->imagingMode;
			data_f[15] = (double)tlv->subMode;
			data_f[16] = (double)tlv->numberDopplerLines;
			data_f[17] = (double)tlv->highSpeedLineNumber;
			data_f[18] = (double)tlv->totalLineNumber;
			
			data_f[19] = (double)txParams.centerElement;
			data_f[20] = (double)txParams.aperture;
			data_f[21] = (double)txParams.focusDistance;
			data_f[22] = (double)txParams.angle;
			data_f[23] = (double)txParams.frequency;
			data_f[24] = (double)txParams.speedOfSound;
			data_f[25] = (double)txParams.useManualDelays;
			data_f[26] = (double)txParams.tableIndex;
			data_f[27] = (double)txParams.useDeadElements;

			data_f[28] = (double)rxParams.centerElement;
			data_f[29] = (double)rxParams.aperture;
			data_f[30] = (double)rxParams.angle;
			data_f[31] = (double)rxParams.maxApertureDepth;
			data_f[32] = (double)rxParams.acquisitionDepth;
			data_f[33] = (double)rxParams.channelMask[0];
			data_f[34] = (double)rxParams.channelMask[1];
			data_f[35] = (double)rxParams.applyFocus;
			data_f[36] = (double)rxParams.useManualDelays;
			data_f[37] = (double)rxParams.customLineDuration;
			data_f[38] = (double)rxParams.lgcValue;
			data_f[39] = (double)rxParams.tgcSel;
			data_f[40] = (double)rxParams.tableIndex;
			data_f[41] = (double)rxParams.decimation;
		}
		else
		{
			numSettings = 9;

			data_p[0] = (double)tlv->scanDuration;
			data_p[1] = (double)tlv->scannerPresent;
			data_p[2] = (double)tlv->sectorialProbe;
			
			data_p[3] = (double)txParams.focusDistance;
			data_p[4] = (double)txParams.frequency;

			data_p[5] = (double)rxParams.acquisitionDepth;
			data_p[6] = (double)rxParams.angle;
			data_p[7] = (double)rxParams.applyFocus;
			data_p[8] = (double)rxParams.decimation;
		}

		mxArray *data_m1;
		data_m1 = mxCreateDoubleMatrix(1,numSettings,mxREAL);

		if(allSettingsRequested)
			memcpy((char *)mxGetPr(data_m1),(char *)data_f,numSettings*sizeof(double));
		else
			memcpy((char *)mxGetPr(data_m1),(char *)data_p,numSettings*sizeof(double));

		ret = engPutVariable(matlabEngine, "TML_ScannerSettings", data_m1);
		if (ret == 1)
			return -262;		// EC: the settings could not be put into the Matlab environment

		mxDestroyArray(data_m1);
		ret = engClose(matlabEngine);
		if (ret == 1)
			return -263;		// EC: the Matlab engine could not be closed
		
		return 0;
		
	}catch(char * )
	{
		return -260;			// EC: some problem with returnScannerSetting(bool)
	}
}


// --------------------------------------------------------------------------------------------------------------------
// THE PRIVATE FUNCTIONS
// --------------------------------------------------------------------------------------------------------------------

int TexoTools::readConfigFile(const char * configFilePathName)
{
	tlv->configPath = "";
	bool err1 = false;		// Becomes true if no config file is specified
	bool err2 = false;		// Becomes true if the config file cannot load
	try
	{
		// Loads the correct path into configPath
		//-------------------------------------------------------------------------
		tlv->configPath.append(configFilePathName);
		tlv->configPath = tlUtil->trimString(tlv->configPath);
		if(tlv->configPath.length() == 0)
		{
			tlv->configPath.append("DefaultConfigFile.txt");		// Ensure that this config file is sent with library!
			tlv->configPath = tlUtil->trimString(tlv->configPath);
			err1 = true;
		}
		
		// Gets the data from the config file and stores it in configData
		//-------------------------------------------------------------------------
		using namespace std;	// So the program can stream data from the config file
		
		tlv->configData.clear();	// Start with a blank string
		
		ifstream configFile(tlv->configPath.data(),ios::in);	// Opens the stream from the file
		
		if (configFile) 						// Checks that the file opened successfully
		{
			std::string line;					// Will temporarily hold each line of config information
			while (std::getline(configFile, line))
				tlv->configData += line;			// Copies the current line of config information to configData
			configFile.close(); 			// Closes file.
		} 
		else
			err2 = true;
	
	}catch(char * )
	{
		return -223;		// EC: some problem with readConfigFile(char*)
	}
	
	if (err2 == true)		// If the file wouldn't open
	{
		if (err1 == false)	// If the user specified a file
			return -221;	// EC: the specified config file failed to open
		else
			return -222;	// EC: default config file failed to open
    }
    else			// If there was no problem
        return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int TexoTools::settingsToScanner()
{
	bool r1, r2, r3;	// True or false depending on the success of the three function calls
	try
	{
		if(tlv->scannerPresent && m_texo.isInitialized() && !m_texo.isImaging())
		{
			r1 = m_texo.setPower(tlv->power, tlv->maxPositivePower, tlv->maxNegativePower);
			r2 = m_texo.addTGC(tlv->TGC);
			r3 = m_texo.activateProbeConnector(tlv->probeConnector);
		}
		else
			return -211;	// EC: scanner is not present or initialised or is already imaging 

	}catch(char * )
	{
		return -219;		// EC: some problem with settingsToScanner()
	}

	if (r1 == false && r2 == true && r3 == true)
		return -212;		// EC: power not set
	if (r1 == true && r2 == false && r3 == true)
		return -213;		// EC: TGC not added
	if (r1 == true && r2 == true && r3 == false)
		return -214;		// EC: probe connector not activated

	if (r1 == false && r2 == false && r3 == true)
		return -215;		// EC: power not set and TGC not added
	if (r1 == false && r2 == true && r3 == false)
		return -216;		// EC: power not set and probe connector not activated
	if (r1 == true && r2 == false && r3 == false)
		return -217;		// EC: TGC not added and probe connector not activated

	if (r1 == false && r2 == false && r3 == false)
		return -218;		// EC: power not set, TGC not added and probe connector not activated

	return 0;	// This point can only be reached if r1,r2,r3 are all true, ie. if there were no errors
}

