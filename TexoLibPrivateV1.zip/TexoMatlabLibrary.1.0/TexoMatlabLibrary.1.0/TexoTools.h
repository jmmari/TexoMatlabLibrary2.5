//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// TexoTools: Contains basic functions which will be called	//
// by the user for every scan and creates the other objects	//
//----------------------------------------------------------//

#if !defined(AFX_STDAFX_H__DA75F23B_EF7F_4A3E_BD30_A58A14B98B2C__INCLUDED_)
#define AFX_STDAFX_H__DA75F23B_EF7F_4A3E_BD30_A58A14B98B2C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#endif 

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

// --------------------------------------------------------------------------------------------------------------------
// INCLUDES
// --------------------------------------------------------------------------------------------------------------------
#include "texLibUtilities.h"
#include "texLibCreateSequenceFunctions.h"
#include "texLibScannerFunctions.h"
#include "texLibVariables.h"

#include "engine.h"
#include <fstream> 

#include "texo.h"
#include "texo_def.h"

class TexoTools
{
public:

	// SETS UP THE ULTRASONIX DEFINED OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texo m_texo;					// Allows us to call the functions provided by UltraSonix
	texoTransmitParams txParams;	// Transmission profile
	texoReceiveParams rxParams;		// Reception profile

	// SETS UP OUR OWN OBJECTS
	// --------------------------------------------------------------------------------------------------------
	texLibUtilities * tlUtil;						// Contains utility functions needed by the other objects
	texLibCreateSequenceFunctions * tlSequencer;	// Contains functions to create ultrasound sequences
	texLibScannerFunctions * tlSonix;				// Contains functions which only call the functions provided by UltraSonix
	texLibVariables * tlv;							// Contains the parameters associated with the sequence and scan

	// CONSTRUCTOR/DESTRUCTOR
	// --------------------------------------------------------------------------------------------------------
	TexoTools(void);
	~TexoTools(void);

	// TEXOTOOLS FUNCTIONS -- PUBLIC
	// --------------------------------------------------------------------------------------------------------
	int loadConfigData(const char * configFilePathName);
		// Opens the specified config file and sets the sequence/scan parmeters accordingly
	int takeScan();
		// Takes a scan of duration defined in the config file
	int takeScan(int duration);
		// Takes a scan of duration ms
	int saveData(char * fileName, int maxNumberOfFramesToSave);
		// Saves a header containing the scan variables and a number of frames up to the specified limit to fileName
	int returnScannerSettings(bool allSettingsRequested);
		// Copies the scanner settings to variables in Matlab,
		// passing either a full or partial list depending on the input allSettingsRequested

private:

	// TEXOTOOLS FUNCTIONS -- PRIVATE
	// --------------------------------------------------------------------------------------------------------
	int readConfigFile(const char * configFilePathName);
		// Copies configFileName to tlv.configFile, reads the specified config file
			// and copies the data to configData
		// Needed for loadConfigData
	int settingsToScanner();
		// Sets the scanner with approriate power, TGC and probe connector values
		// Needed for loadConfigData
};
