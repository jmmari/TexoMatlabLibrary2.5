//----------------------------------------------------------//
// TEXOTOOLS MATLAB LIBRARY, IMPERIAL COLLEGE LONDON		//
// (c) J.M. MARI, 2007. UPDATED R. CRIDDLE 2009				//
//															//
// texLibCreateSequenceFunctions: Functions to create the	//
// various scan sequences which are required by the user	//
//----------------------------------------------------------//

#include "stdafx.h"

#include "texLibCreateSequenceFunctions.h"
#include "texLibUtilities.h"
#include "texLibVariables.h"

#include "texo.h"
#include "texo_def.h"

#include <vector>

texLibCreateSequenceFunctions::texLibCreateSequenceFunctions()
{
}

texLibCreateSequenceFunctions::~texLibCreateSequenceFunctions()
{
	tlv = NULL;
	tlUtil = NULL;
	m_texo = NULL;
	txParams = NULL;
	rxParams = NULL;
}

// --------------------------------------------------------------------------------------------------------------------
// PUBLIC FUNCTIONS -- DEFINED SEQUENCES
// --------------------------------------------------------------------------------------------------------------------

int texLibCreateSequenceFunctions::createStandardSequence()
{
	int i;				// To be used as a counter
	int numberElements;	// The number of elements on the probe
	int lineSize;		// Tracks whether the addLine call is successful

	try
	{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->imagingMode = 1;
			tlv->subMode = 1;

			if(!m_texo->beginSequence())
				return -412;	// EC: call to beginSequence failed

			tlv->totalLineNumber = 0;

			numberElements = m_texo->getProbeNumElements();

			strcpy_s(txParams->pulseShape, tlv->pulseShapeA.data());

			if(tlv->sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txParams->aperture = 2*NUMCHANNELS;
				rxParams->aperture = NUMCHANNELS;

				txParams->centerElement = rxParams->centerElement = (numberElements/2 * 10) + 5;

				for(i=0; i<numberElements; i++)
				{
					txParams->angle = rxParams->angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);

					// Record the line parameters:
					tlv->centerElement[i] = txParams->centerElement;
					tlv->angle[i] = txParams->angle;
					tlv->pulseShape[i] = "";
					tlv->pulseShape[i].append(txParams->pulseShape).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					tlv->totalLineNumber ++;
					// *txParams because txParams is a pointer so needs to be dereferenced
					if(lineSize == -1)
						return -413;		// EC: call to addLine failed in sectorial mode
				}
				tlv->totalLineNumber = i;
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i=0; i<numberElements; i++)
				{
					txParams->centerElement = rxParams->centerElement = (i * 10) + 5;
					//rxParams.channelMask[0] = 1 << (i % NUMCHANNELS);

					// Record the line parameters:
					tlv->centerElement[i] = txParams->centerElement;
					tlv->angle[i] = txParams->angle;
					tlv->pulseShape[i] = "";
					tlv->pulseShape[i].append(txParams->pulseShape).append(";");

					// Create the line::
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -414;		// EC: call to addLine failed in linear mode
				}
				tlv->totalLineNumber = i;
			}
			if(m_texo->endSequence() == -1)
				return -415;				// EC: call to endSequence failed

			tlv->readyToScan = true;
		}
		else
			return -411;	// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -410;		// EC: some problem with createStandardSequence()
	}	
	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createStandardSequence(char *pulseShape)
{
	int ret;

	tlv->pulseShapeA = "";
	tlv->pulseShapeA.append(pulseShape);

	ret = createStandardSequence();
	if (ret != 0)
		ret -= 10;			// Because error codes for this function begin 42

	return ret;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createAlternatingSequence()
{
	int i, l;			// To be used as a counter
	int numberElements;	// The number of elements on the probe
	int lineSize;		// Tracks whether the addLine call is successful

	try
	{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->imagingMode = 2;
			tlv->subMode = 2;
			if(!m_texo->beginSequence())
				return -432;	// EC: call to beginSequence failed

			l = tlv->totalLineNumber = 0;

			numberElements = m_texo->getProbeNumElements();

			if(tlv->sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txParams->centerElement = rxParams->centerElement = (10*numberElements/2) + 5;

				for(i=0; i<numberElements; i++)
				{
					txParams->angle = rxParams->angle = (int)((-45+((float)i*90)/(float)numberElements)*1000);

					// Record the line parameters for the first pulse:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// First pulse:
					strcpy_s(txParams->pulseShape, tlv->pulseShapeA.data());
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -433;	// EC: call to addLine failed in sectorial mode, pulse A
					tlv->totalLineNumber ++;	// The number of lines so far
					l = tlv->totalLineNumber;	// The current line number

					// Record the line parameters for the second pulse:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeB).append(";");

					// Second pulse:
					strcpy_s(txParams->pulseShape, tlv->pulseShapeB.data());
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -434;	// EC: call to addLine failed in sectorial mode, pulse B
					tlv->totalLineNumber ++;	// The number of lines so far
					l = tlv->totalLineNumber;	// The current line number
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i=0; i<numberElements; i++)
				{
					txParams->centerElement = rxParams->centerElement = (i*10) + 5;

					// Record the line parameters, first pulse:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// First pulse:
					strcpy_s(txParams->pulseShape, tlv->pulseShapeA.data());
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -435;	// EC: call to addLine failed in linear mode, pulse A
					tlv->totalLineNumber ++;	// The number of lines so far
					l = tlv->totalLineNumber;	// The current line number

					// Record the line parameters, second pulse:
					l = (2 * i) + 1;	// l is the line number
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeB).append(";");

					// Second pulse:
					strcpy_s(txParams->pulseShape, tlv->pulseShapeB.data());
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -436;	// EC: call to addLine failed in linear mode, pulse B
					tlv->totalLineNumber ++;	// The number of lines so far
					l = tlv->totalLineNumber;	// The current line number
				}
			}
			if(m_texo->endSequence() == -1)
				return -437;				// EC: call to endSequence failed

			tlv->readyToScan = true;
		}
		else
			return -431;	// EC: scanner is not present or initialised or is already imaging
		
	}catch(char * )
	{
		return -430;		// EC: some problem in createInvertingSequence()
	}

	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createAlternatingSequence(char *pulseShapeA, char *pulseShapeB)
{
	int ret;

	tlv->pulseShapeA = tlv->pulseShapeB = "";
	tlv->pulseShapeA.append(pulseShapeA);
	tlv->pulseShapeB.append(pulseShapeB);

	ret = createAlternatingSequence();
	if (ret != 0)
		ret -= 10;				// Because error codes for this function begin 44

	return ret;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createInvertingSequence()
{
	int ret;

	tlv->pulseShapeB = inversePulse(tlv->pulseShapeA);
	
	ret = createAlternatingSequence();
	tlv->subMode = 1;

	if (ret != 0)
		ret -= 20;				// Because error codes for this function begin 45

	return ret;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createInvertingSequence(char *pulseShape)
{
	int ret;

	tlv->pulseShapeA = "";
	tlv->pulseShapeA.append(pulseShape);
	tlv->pulseShapeB = inversePulse(tlv->pulseShapeA);
	
	ret = createAlternatingSequence();
	tlv->subMode = 1;

	if (ret != 0)
		ret -= 30;				// Because error codes for this function begin 46

	return ret;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createHighSpeedSequence(char *pulseShape, int numberLines, int depth, int txFrequency, int focusDistance)
{
	int i, l;			// To be used as counters
	int numberElements;	// The number of elements on the probe
	int lineSize;		// For error checking

	int deltaAngle = 1406;
	int angleMax;
	int xDep;

	try
	{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->imagingMode = 1;
			tlv->subMode = 2;

			numberElements = m_texo->getProbeNumElements();

			if(numberLines > numberElements)	// If more lines have been requested than the scanner's elements
				numberLines = numberElements;
			if(numberLines == 0)				// If no lines have been requested
				numberLines = 10;

			// Set up the parameters:
			tlv->highSpeedLineNumber = numberLines;
			tlv->pulseShapeA = "";
			tlv->pulseShapeA.append(pulseShape);

			txParams->focusDistance = focusDistance;
			txParams->frequency = txFrequency;
			rxParams->acquisitionDepth = depth;

			strcpy_s(txParams->pulseShape, pulseShape);

			if(!m_texo->beginSequence())
				return -472;	// EC: call to beginSequence failed
			tlv->totalLineNumber = 0;

			if(tlv->sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				angleMax = deltaAngle * tlv->highSpeedLineNumber;
				txParams->centerElement = rxParams->centerElement = (10*numberElements/2) + 5;
				for(i=0; i<tlv->highSpeedLineNumber; i++)
				{
					txParams->angle = rxParams->angle = (int)((-angleMax/2 + ((float)i*angleMax)/(float)numberElements));
					
					l = tlv->totalLineNumber;

					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(pulseShape).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -473;	// EC: call to addLine failed in sectorial mode
					tlv->totalLineNumber ++;
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				xDep = (int)((numberElements/2-tlv->highSpeedLineNumber/2)*10);
				txParams->angle = rxParams->angle = 0;
				for(i=0; i<tlv->highSpeedLineNumber; i++)
				{
					txParams->centerElement = rxParams->centerElement = xDep + (10*i) + 5;
					//rxPos.channelMask[0] = 1 << ((xDep/10 + i) % NUMCHANNELS);
				
					l = tlv->totalLineNumber;
					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(pulseShape).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					if(lineSize == -1)
						return -474;	// EC: call to addLine failed in linear mode
					tlv->totalLineNumber ++;
				}
			}
			if(m_texo->endSequence() == -1)
				return -475;				// EC: call to endSequence failed
			tlv->readyToScan = true;
		}
		else
			return -471;	// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -470;		// EC: some problem in createHighSpeedSequence(char*,int,int,int,int)
	}	

	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createDopplerSequence(char *pulseShape, int lineNumber, int repeat)
{
	int i, j, l;		// To be used as counters
	int numberElements;	// The number of elements on the probe
	int lineSize;		// For error checking

	try
	{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->imagingMode = 3;
			tlv->subMode = 2;
			tlv->numberDopplerLines = 0;

			if(!m_texo->beginSequence())
				return -482;	// EC: call to beginSequence failed

			tlv->totalLineNumber = 0;	// Incremented as lines are added

			numberElements = m_texo->getProbeNumElements();

			tlv->pulseShapeA = "";
			tlv->pulseShapeA.append(pulseShape);
			strcpy_s(txParams->pulseShape, tlv->pulseShapeA.data());

			if(tlv->sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				txParams->centerElement = rxParams->centerElement = (numberElements/2 * 10) + 5;

				for(i=0; i<lineNumber; i++)
				{
					txParams->angle = rxParams->angle = (int)((-45 + ((float)i*90)/(float)numberElements)*1000);

					for(j=0; j<repeat; j++)
					{
						l = tlv->totalLineNumber;

						// Record the line parameters:
						tlv->centerElement[l] = txParams->centerElement;
						tlv->angle[l] = txParams->angle;
						tlv->pulseShape[l] = "";
						tlv->pulseShape[l].append(txParams->pulseShape).append(";");

						// Create the line:
						lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
						tlv->totalLineNumber ++;

						if(lineSize == -1)
							return -483;		// EC: call to addLine failed in sectorial mode
					}
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i=0; i<numberElements; i++)
				{
					txParams->centerElement = rxParams->centerElement = (i * 10) + 5;
					//rxParams.channelMask[0] = 1 << (i % NUMCHANNELS);

					for(j=0; j<repeat; j++)
					{
						l = tlv->totalLineNumber;

						// Record the line parameters:
						tlv->centerElement[l] = txParams->centerElement;
						tlv->angle[l] = txParams->angle;
						tlv->pulseShape[l] = "";
						tlv->pulseShape[l].append(txParams->pulseShape).append(";");

						// Create the line:
						lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
						tlv->totalLineNumber ++;

						if(lineSize == -1)
							return -484;		// EC: call to addLine failed in linear mode
					}
				}
			}
			if(m_texo->endSequence() == -1)
				return -485;				// EC: call to endSequence failed
			tlv->readyToScan = true;
		}
		else
			return -481;	// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -480;		// EC: some problem with createStandardSequence()
	}	

	return 0;	
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::createMDopplerSequence(char *pulseShape, int repeatCenter)
{
	int i, l;			// To be used as a counter
	int numberElements;	// The number of elements on the probe
	int scanLineNumber;	// Number of lines in the B-mode image
	int lineSize;		// For error checking

	try
	{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->numberDopplerLines = 0;
			tlv->imagingMode = 3;
			tlv->subMode = 1;

			if(!m_texo->beginSequence())
				return -492;	// EC: call to beginSequence failed

			tlv->totalLineNumber = 0;

			tlv->pulseShapeA = "";
			tlv->pulseShapeA.append(pulseShape);
			strcpy_s(txParams->pulseShape, pulseShape);
			numberElements = m_texo->getProbeNumElements();

			if(tlv->sectorialProbe) // ----------------------- Sectorial Probe -----
			{
				scanLineNumber = 256;
				txParams->aperture = 2*NUMCHANNELS;
				rxParams->aperture = NUMCHANNELS;
				txParams->centerElement = rxParams->centerElement = (numberElements/2 * 10) + 5;

				for(i = 0; i<scanLineNumber; i++)		// Take a B-mode image
				{
					txParams->angle = rxParams->angle = (int)((-45 + ((float)(i-1)*90)/(float)(scanLineNumber-1))*1000);//-pi/4 + i*pi/2/numberElements;
					l = tlv->totalLineNumber;

					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					tlv->totalLineNumber ++;

					if(lineSize == -1)
						return -493;		// EC: call to addLine failed in sectorial mode, B mode image
				}

				txParams->angle = rxParams->angle = 0;
				for (i=0; i<repeatCenter; i++)			// Repeat the center line (angle = 0)
				{
					l = tlv->totalLineNumber;

					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					tlv->totalLineNumber ++;
					tlv->numberDopplerLines ++;

					if(lineSize == -1)
						return -494;		// EC: call to addLine failed in sectorial mode, repeating center
				}
			}
			else // ------------------------------------- LINEAR Probe -----
			{
				for(i=0; i<numberElements; i++)		// Take a B-mode image
				{
					l = tlv->totalLineNumber;
					txParams->centerElement = rxParams->centerElement = (i * 10) + 5;
					//rxParams->channelMask[0] = 1 << (i % NUMCHANNELS);
					//rxParams->channelMask[0] = 1 << (i % NUMCHANNELS);

					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					tlv->totalLineNumber ++;

					if(lineSize == -1)
						return -495;		// EC: call to addLine failed in linear mode, B mode image
				}

				txParams->centerElement = rxParams->centerElement = ((numberElements/2) * 10) + 5;
				for(i=0; i<repeatCenter; i++)		// Repeat the center line
				{
					l = tlv->totalLineNumber;

					// Record the line parameters:
					tlv->centerElement[l] = txParams->centerElement;
					tlv->angle[l] = txParams->angle;
					tlv->pulseShape[l] = "";
					tlv->pulseShape[l].append(tlv->pulseShapeA).append(";");

					// Create the line:
					lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
					tlv->totalLineNumber ++;
					tlv->numberDopplerLines ++;

					if(lineSize == -1)
						return -496;		// EC: call to addLine failed in linear mode, repeating center
				}
			}
			if(m_texo->endSequence() == -1)
				return -497;				// EC: call to endSequence failed

			tlv->readyToScan = true;
		}
		else
			return -491;	// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -490;		// EC: some problem with createMDopplerSequence(char*,int)
	}	
	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
// PUBLIC FUNCTIONS -- CUSTOM SEQUENCES
// --------------------------------------------------------------------------------------------------------------------

int texLibCreateSequenceFunctions::beginSequence()
{
	try{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging())
		{
			tlv->readyToScan = false;
			tlv->creatingCustomSequence = true;
			tlv->imagingMode = 4;
			tlv->subMode = 1;

			tlv->totalLineNumber = 0;

			if(!m_texo->beginSequence())
				return -512;	// EC: call to beginSequence failed
		}
		else
			return -511;		// EC: scanner is not present or initialised or is already imaging

	}catch(char * )
	{
		return -510;			// EC: some problem in beginSequence()
	}
	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::addLine()
{
	int l;			// The current line
	int lineSize;	// For error checking

	try{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging() && tlv->creatingCustomSequence)
		{
			l = tlv->totalLineNumber;	// The number of lines added so far

			// Record the line parameters:
			tlv->centerElement[l] = txParams->centerElement;
			tlv->angle[l] = txParams->angle;
			tlv->pulseShape[l] = "";
			tlv->pulseShape[l].append(txParams->pulseShape).append(";");

			// Create the line:
			lineSize = m_texo->addLine(rfData, *txParams, *rxParams);
			tlv->totalLineNumber ++;

			if(lineSize == -1)
				return -522;	// EC: call to addLine failed in sectorial mode
		}
		else
			return -521;		// EC: scanner is not present or initialised or is already imaging or sequence hasn't begun

	}catch(char * )
	{
		return -520;			// EC: some problem in addLine()
	}
	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
int texLibCreateSequenceFunctions::endSequence()
{
	try{
		if(tlv->scannerPresent && m_texo->isInitialized() && !m_texo->isImaging() && tlv->creatingCustomSequence)
		{
			if(m_texo->endSequence() == -1)
				return -532;				// EC: call to endSequence failed
			else 
			{
				tlv->readyToScan = true;
				tlv->creatingCustomSequence = false;
			}
		}
		else
			return -531;		// EC: scanner is not present or initialised or is already imaging or sequence hasn't begun

	}catch(char * )
	{
		return -530;			// EC: some problem in endSequence()
	}
	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
// PRIVATE FUNCTIONS
// --------------------------------------------------------------------------------------------------------------------

std::string texLibCreateSequenceFunctions::inversePulse(std::string pulse)
{
	std::string eslup;	// The inverted shape
	int len;			// The length of the pulse
	int i;				// Counter

	eslup.append(pulse);

	len = (int)pulse.length() - 1;

	for (i=0; i<=len; i++)
	{
		switch (pulse[i])
		{
		case '+':
			eslup[i] = '-';
			break;

		case '-':
			eslup[i] = '+';
			break;

		case '0':
			eslup[i] = '0';
			break;

		default:
			eslup[i] = '0';
			break;
		}
	}

	return eslup;
}

// --------------------------------------------------------------------------------------------------------------------
std::vector <int> texLibCreateSequenceFunctions::getSequenceValues(std::string sequence, int number)
{
	using namespace std;
	std::vector <int> delays(0);
	std::vector <int> emptyDelays(0);
	int index = 0;

	delays.reserve(128);
	std::string rest = "   ";
	try
	{
		std::basic_string <int>::size_type refIndex  = 1;
		std::basic_string <int>::size_type startIndex = 1;
		std::basic_string <int>::size_type endIndex = 1;

		for (int index = 0; index<number; index++)
		{
			endIndex = sequence.find(";", refIndex);
			rest = sequence.substr(startIndex, endIndex - startIndex);
			delays.push_back(atoi((rest).data()));
			startIndex = refIndex = endIndex + 1;
		}

	}catch(char * )
	{
		return emptyDelays;
	}

	return delays;
}

