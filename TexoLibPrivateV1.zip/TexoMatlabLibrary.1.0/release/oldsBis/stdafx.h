
int runTexo(char *);//[]); 
//run(char * argv[]);

