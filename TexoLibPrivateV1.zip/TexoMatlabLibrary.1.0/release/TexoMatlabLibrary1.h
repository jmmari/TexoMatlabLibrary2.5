// This file lists the functions available in the TexoMatlab library:

int libraryTest();

// USER FUNCTIONS (TEXOTOOLS)

int loadConfigData(const char * configFilePathName);
int takeScan();
int takeScan(int duration);
int saveData(char * fileName, int maxNumberOfFramesToSave);
int returnScannerSettings(bool allSettingsRequested);


// SCANNER FUNCTIONS (SONIX)

int startEngine(char * settingsFileName, int freq);
int startEngine(char * settingsFileName);
int setPower(int power, int powerMin, int powerMax);
int startImaging();
int stopImaging();
int stopEngine();


// CREATE SEQUENCE FUNCTIONS (SEQUENCER)

int createStandardSequence();
