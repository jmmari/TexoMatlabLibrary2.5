function [saveFolder, configFolder, libraryFolder, settingsFolder] = openPaths()

% THIS MUST BE CHANGED WHENEVER THE LIBRARY IS INSTALLED / MOVED:
% The root directory where all TexoTools files are stored:
rootPath = 'D:\SonixProgramming\Richard\TexoLibPublic';

% DO NOT CHANGE THE REST, THEY ARE RELATIVE TO THE ROOT SO AUTOMATICALLY UPDATE 
% The folders used in the script:
saveFolder = [rootPath, '\SavedImages\'];
configFolder = [rootPath, '\ConfigFiles\'];
libraryFolder = [rootPath, '\TexoMatlabLibrary.1.0\release\'];
settingsFolder = [rootPath, '\TexoMatlabLibrary.1.0\dat\'];

% Folder containing the Matlab functions which call the library:
addpath([rootPath, '\MatlabTexoFunctions\']);

