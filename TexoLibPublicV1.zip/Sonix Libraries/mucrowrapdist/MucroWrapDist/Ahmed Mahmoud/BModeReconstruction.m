% WVU Ultrasonic Laboratory
% B-Mode Image Reconstruction from RF Raw Data after beamforming

% By Ahmed Mahmoud
% 03-July 2007

%%%%%%%% System Parameters
 Fs = 40e6;      % sampling frequency
 Ts = 1/Fs;      % period
 c  = 1540;      % speed of sound m/s
 L  = 516;         % number of samples
 D  = L*c/(Fs*2);        % Depth in meter
 T  = D/(c/2);           % total time
 t  = 0:Ts:T; t = t(1:L);


    % RF signals are aquired using Sonix RP system in the research Mode *.rf

%STAUFFER added prompt for filename
filename = input('Filname with or without extension: ','s');
RF = readRFfile(filename);
    %STAUFFER modified function returns array instead of writing to a .mat
    %file.
%load([filename '.mat']);
%readRFfile('Faom'); % function to read the *.rf file and save frames
%load Faom.mat

    % % %%%%%%%%% FIR Filter parameter %%%%%%%%%%%%%
 filterOrder = 20;    % Butterworth filter order
 FFTLength = 1024;   % Length of FFT calculation
 LowFcut  = 6*1e6; % Low  cutt-off frequency of the band-limited white noise
 HighFcut = 19*1e6; % High cutt-off frequency of the band-limited white noise

 LPFImg=RF;
 LPFImg=Apply_Filter(RF(:,:,1),LowFcut,HighFcut,Fs,filterOrder); % call filter function
    
% %%%%%%%%%%%%%%% Envelope detection (Hilbert Transform) %%%%%
  EnvImg  = abs(Hilbert(LPFImg));
  
 %%%%%%% Image resizing
 width=480;
 height=640;
 newImg = imageResize(EnvImg,480,640,1);
      
 %%%%%%%%%%%%%%%%Do logarithmic compression
%CmpImg  = sign(EnvImg).*log( 0.1 + abs(EnvImg));
Img=(newImg)/max(max(newImg));
CmpImg = sign(Img).*exp(1/(3.5-1)*log( 1 + abs(newImg)));

      
imagesc(CmpImg)
colormap gray(128)



% %%%%%% Sector Image
% figure;
% SCimg = linear2Sector(CmpImg,30,90) ; 
% interpSCimg = interpSCimg(SCimg);
% imagesc(interpSCimg)
% colormap gray(128)


