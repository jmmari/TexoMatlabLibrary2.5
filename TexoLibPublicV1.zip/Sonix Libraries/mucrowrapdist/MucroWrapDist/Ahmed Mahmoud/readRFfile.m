function [RF, width, height, numFrames] = readRFfile(filename)
%
%readRFfile Read an RF file as a matrix and store it in a .mat file
%
%   RF = readRFfile(FILENAME)
%   FILENAME : name of the file to be read without the .rf extension
%   RF : output double-type RF matrix with dimensions (RFsamples * LineNumber * Frames)
%           See comment below as to why type double.
%   width, height: as read from file header. I'm assuming these are # scan
%   lines and length thereof. STAUFFER.
%
% Hani Eskandari July 2006
%
% M Stauffer - modifications July 2007 - added other outputs, and see below

disp('readRFFile: STAUFFER edited...');

[path,namewithoutext,ext,ver] = fileparts(filename);
if isempty(ext)
    filename = strcat(filename,'.rf');
end
fid = fopen(strcat(filename),'r');
if fid == -1
    error('readFRfile: error opening file.');
end

disp('readFRfile: Reading .rf file...');

try %Try block for file reading and processing

    %File Header
    %Read
    %
    [tag1,count] = fread(fid,19,'int32');
        %STAUFFER - sonix RP 3.x now has file header with 19 long int,
        %instead of the old 7
    frames = tag1(2);
    numFrames = frames;
    w = tag1(3); %STAUFFER - as best I can tell, w is # scan lines
    width = w;
    h = tag1(4); % and h is scan line length
    height = h;
    disp(sprintf('readRFfile: w: %d h: %d numFrames: %d',w,h,numFrames));

    % Read the raw data
    RF = zeros(h,w,frames,'double');
        %STAUFFER - make type double. This is what the 'readDMPfileRF.m'
        %from Ultrasonix does, used in their MATLAB gui sample
        %'GraphicUnit_export.m'. If use type int16, it complains cuz funcs
        %like fft don't work on int type.
    tag(frames)=0;

    for frame_count = 1:frames

        %Each frame has 4 byte header for frame number
        [tag(frame_count),count] = fread(fid,1,'int32'); %STAUFFER changed to 'int32' from 'int' to be safe
        %the acutal data...
        [v,count] = fread(fid,w*h,'int16'); %STAUFFER changed to 'int16' from 'short' just to be safe

        RF(:,:,frame_count) = int16(reshape(v,h,w));
        %disp([frame_count tag(frame_count)]); testing
        disp(['readRFfile: Min/Max: ' num2str(min(min(RF))) ' ' num2str(max(max(RF)))])
    end

    %STAUFFER - removing this, and will just use returned array
    %save(strcat(namewithoutext,'.mat'),'RF');
catch
    fclose(fid);
    error('UPenn:readRFfile',['Error processing file.' lasterr]);
end
disp('readFRfile: Done reading file.');
fclose(fid);

