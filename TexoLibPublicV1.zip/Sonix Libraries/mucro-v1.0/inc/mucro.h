#ifndef __MUCRO_H__
#define __MUCRO_H__

#ifdef EXPORT_MUCRO
    #define mucrolinkage __declspec(dllexport)
#elif defined IMPORT_MUCRO
    #define mucrolinkage __declspec(dllimport)
#else
    #define mucrolinkage
#endif

////////////////////////////////////////////////////////////////////////////////
/// Mucro processes B scan ultrasound images, by running a intense filtering
/// algorithms including edge enhancement and smoothing for better border and 
/// structure definition and resolution. 
////////////////////////////////////////////////////////////////////////////////
class mucrolinkage mucro
{
public:
	mucro();
	virtual ~mucro();

	bool init(const char * paramfile);
	bool destroy();
	bool apply(unsigned char * in, unsigned char * out, int w, int h, int param, bool useIndex);
	
    bool setMask(unsigned char * mask, int w, int h);
	bool removeMask();
    bool isMasked();
	
    bool isInitialized();
	static bool isAvailable();
};

#endif