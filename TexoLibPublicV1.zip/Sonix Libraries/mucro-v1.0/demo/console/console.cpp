// mucro demonstration program
// Ultrasonix Medical Corporation (2007)
//
// description:     filters B scan ultrasound data using a special enhancement filter
// program type:    console
// inputs:          command line arguments, queried information
// outputs:         image file (optional)

// header files
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <mucro.h>
#include "header.h"

// constants
#ifndef DATA_PATH
    #define DATA_PATH       "../../dat/"
#endif
#define swap(a,b)           { temp=(a);(a)=(b);(b)=temp; }  

// prototypes
void convertImage(const unsigned char * data, int size, unsigned int * cdata);
void invertImage(unsigned int * pData, int w, int h);
bool writeBitmap(char * path, unsigned char * data, int w, int h, int ss);

// program entry point
int main(int argc, char * argv[])
{
    FILE * fp;
    Data hdr;    
    mucro filter;    
    int sz, frhdr, temp;
    unsigned char * data = 0, * fdata = 0;
    int level = 50;
    char path[80];

    // there must be at least two arguments
    if(argc < 3)
    {
        fprintf(stderr, "usage: %s input-file filter-level [output-file]\n", argv[0]);
        return -1;
    }

    // initialize the filter
    sprintf(path, "%scv.par", DATA_PATH);
    if(!filter.init(path))
    {
        fprintf(stderr, "could not initialize filter\n");
        return -1;
    }

    // try to open input file
    fp = fopen(argv[1], "rb");
    if(!fp)
    {
        fprintf(stderr, "could not open specified file\n");
        return -1;
    }

    // read file header
    fread(&hdr, sizeof(hdr), 1, fp);

    // ensure file type is 8 bit data
    if(hdr.type != udtBPre && hdr.type != udtBPost)
    {
        fprintf(stderr, "invalid file type\n");
        fclose(fp);
        return -1;
    }
    
    // read frame header
    if(hdr.type == udtBPre)
        fread(&frhdr, sizeof(int), 1, fp);
    
    // read data
    sz = hdr.w * hdr.h;
    data = new unsigned char[sz];
    fread(data, sz, 1, fp);

    fclose(fp);

    // print data information
    printf("image information:\n");
    printf("- width: %d\n", hdr.w);
    printf("- height: %d\n", hdr.h);
    printf("\n");

    level = atoi(argv[2]);
    if(level < 0 || level > 100)
    {
        fprintf(stderr, "invalid level specified (%d)", level);
        return -1;
    }

    // try to filter    
    fdata = new unsigned char[sz];
    if(!filter.apply(data, fdata, hdr.w, hdr.h, level, false))
    {
        fprintf(stderr, "could not perform filtering\n");        
        return -1;
    }

    printf("filtering was successful\n");

    // save the scan-converted image if output file was provided as an argument
    if(argc > 3)
    {
        if(strstr(argv[3], ".bmp") != 0)
        {
            if(hdr.type == udtBPre)
                swap(hdr.w, hdr.h);

            if(!writeBitmap(argv[3], fdata, hdr.w, hdr.h, hdr.ss))
            {
                fprintf(stderr, "could not write bitmap\n");
                return -1;
            }
        }
        else
        {
            fp = fopen(argv[3], "wb+");
            if(!fp)
            {
                fprintf(stderr, "could not open output file for writing\n");
                return -1;
            }

            fwrite(fdata, sz, 1, fp);
            fclose(fp);
        }

        printf("image storage was successful\n");
    }

    delete [] data;
    delete [] fdata;

    while(!kbhit());

    return 0;
}

// converts 8 bit data into 32 bit RGB data
void convertImage(const unsigned char * data, int size, unsigned int * cdata)
{
    int i;
    for(i = 0; i < size; i++)
        cdata[i] = data[i] << 16 | data[i] << 8 | data[i];
}

/// inverts image data, so that the bitmap can be displayed properly
void invertImage(unsigned int * pData, int w, int h)
{
	int x, y, temp;
	unsigned int * p = (unsigned int *)pData;

	// flip the image on the X-axis
	for(y = 0; y < h / 2; y++)
		for(x = 0; x < w; x++)
			swap(p[y * w + x], p[ ((h - 1 - y) * w) + x]);
}

/// write a bitmap file to a specified location
bool writeBitmap(char * path, unsigned char * data, int w, int h, int ss)
{    

    FILE * fp = fopen(path, "wb");
    if(!fp)
        return false;
 
    unsigned int * cdata;

    if(ss == 32)
        cdata = (unsigned int *)data;
    else
        cdata = new unsigned int[w * h];

    // convert 8 bit data to 32 bit data
    convertImage(data, w * h, cdata);
    // since the data gets flipped when written to bitmap, pre-flip the image
    invertImage((unsigned int *)cdata, w, h);

    BITMAPINFOHEADER BMIH;
    BMIH.biSize = sizeof(BITMAPINFOHEADER);
    BMIH.biBitCount = (unsigned short)32;
    BMIH.biPlanes = 1;
    BMIH.biCompression = BI_RGB;
    BMIH.biWidth = w;
    BMIH.biHeight = h;
    BMIH.biSizeImage = ((((BMIH.biWidth * BMIH.biBitCount) + 31) & ~31) >> 3) * BMIH.biHeight;

    BITMAPFILEHEADER bmfh;
    int nBitsOffset = sizeof(BITMAPFILEHEADER) + BMIH.biSize; 
    LONG lImageSize = BMIH.biSizeImage;
    LONG lFileSize = nBitsOffset + lImageSize;
    bmfh.bfType = 'B'+('M'<<8);
    bmfh.bfOffBits = nBitsOffset;
    bmfh.bfSize = lFileSize;
    bmfh.bfReserved1 = bmfh.bfReserved2 = 0;    
    // write the bitmap file header
    fwrite(&bmfh, 1, sizeof(BITMAPFILEHEADER), fp);
    // and then the bitmap info header
    fwrite(&BMIH, 1, sizeof(BITMAPINFOHEADER), fp);    
    // finally, write the image data itself     
    fwrite(cdata, 1, lImageSize, fp);

    fclose(fp);

    if(ss == 32)
        delete [] cdata;

    return true;
}