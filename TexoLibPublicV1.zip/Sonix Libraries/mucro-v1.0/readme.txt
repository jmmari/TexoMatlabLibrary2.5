Introduction
------------

The following Readme is for the mucro SDK, which is created and distributed
by Ultrasonix Medical Corporation. Mucro is used to filter pre-scan converted
or scan converted B scan ultrasound data.

File Definitions
----------------

/readme.txt			This file.

/bin/mucro.dll			Core image processing module.
/bin/cvie.dll			Supporting image processing module.
/bin/cvltk.dll			Supporting image processing module.
/bin/cvmipconv.dll		Supporting image processing module.
/bin/cvrestore.dll		Supporting image processing module.
/bin/libmmd.dll			Supporting image processing module.

/lib/mucro.lib			Library file for linking.

/dat/cv.par			Parameters file.

/inc/mucro.h			Core programming interface.

/reg/cvliccon.exe		Program to install license.
/reg/CVLicense.def		Supporting file for the license installation program.
/reg/dongle-driver.zip		Contains the dongle driver installation program.

Usage
-----

- In your program, link with the library 'mucro.lib'
- Include the header file 'mucro.h' to use the mucro class


Licensing
---------
- Purchase a dongle from Ultrasonix, or use the dongle provided on your RP 
  machine (plugs into the parallel port)
- Send the serial number on the dongle to rpsupport@ultrasonix.com, and you 
  will receive a 16 character license
- Run sentinel.exe to install the driver for the dongle
- Run the program �cvliccon� from a DOS prompt entering the license as the 
  parameter, ie. �C:\mru\reg\cvliccon abcdefghijklmnop�. Ensure the CVLicense.def
  file is in the same directory.
- Check the license status to ensure it was applied
- The SDK will only work on a licensed system with a valid dongle