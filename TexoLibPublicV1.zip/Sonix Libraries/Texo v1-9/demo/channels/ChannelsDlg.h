#if !defined(AFX_USDATAPROCESSINGDLG_H__F4138023_3C83_11D4_9745_0050BAD1E4E7__INCLUDED_)
#define AFX_USDATAPROCESSINGDLG_H__F4138023_3C83_11D4_9745_0050BAD1E4E7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif

#include "DataGraphic.h"
#include "SignalDlg.h"
#include <texo.h>
#include <texo_def.h>
#include <time.h>

// curves selection
#define		CURVESELECTION_32HFORIGINAL				0
#define		CURVESELECTION_32HFDELAYED				1
#define		CURVESELECTION_32HFBOTH					2

class CChannelsDialog : public CDialog
{
public:

	CChannelsDialog(texo *tex, CWnd* pParent = NULL);//(CScanner *, CProbeCollection *, CWnd* pParent = NULL);
	
	int DoModal();
	void InitSliders();
	bool LoadProbes();
	bool SelectProbe(int probeID, int connector);
	bool sequenceSingleChannel();
	bool createSequence();
	bool Run();
	bool Stop();

	bool UpdateAllChannels();
	CDataGraphic * CreateDataGraphicWindow(int frameID, int index);
	bool Save(CString sPath);
	void ReadUSProcessingDataInGraphic(int offset1, int offset2, CDataGraphic * dg, CStatic * minmax, int numSamples);	
	void LoadSequences();

	static void CALLBACK InvokeUpdateTimer(UINT uID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2);
    
    static bool newImageCallback(void *, unsigned char *, int);	

	//{{AFX_DATA(CChannelsDialog)	
	enum { IDD = IDD_USPROCESSING };
	
	CComboBox	c_dataSelection;
	CComboBox	c_seqList;
	CComboBox	c_probeslist;
	CSliderCtrl	m_slideramplitude;
	CSliderCtrl	m_slideroffset;
	CSliderCtrl	m_sliderzoom;
	int		c_line;	
	int		m_channel;	
	int     c_focusdistance;
	BOOL	c_filter;	
	BOOL	c_zoomall;	
    BOOL    c_show64;
    int 	c_angle;
	int     c_txfreq;
	CString	c_excitation;
	int		c_power;
	int		c_gain;
    int     c_depth;
    int     c_saveDelay;
	int		c_txApt;
	CString	c_path;    
	int		c_rfDecimation;	
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CChannelsDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

protected:
	
	//{{AFX_MSG(CChannelsDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeProbe();
	afx_msg void OnRun();
	afx_msg void OnStop();
	afx_msg void OnClose();
	afx_msg HRESULT OnSignalSelect(WPARAM wParam, LPARAM lParam);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnUpdateView();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnApply();
	afx_msg void OnSave();
	afx_msg void On64Channels();
	afx_msg void OnShowFFT();	
	afx_msg void OnExcel();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	texo * m_texo;
    static unsigned char * m_data;
	bool m_running;	

	CDataGraphic *m_channelDisplay[32];
	CDataGraphic *m_globalDisplay;
	CStatic	*m_channelText[32];
	CStatic	*m_globalText;

	int m_numSamples;
	int	m_curveselection;
	int	m_offset;
	int m_zoom;	
	int m_amplitude;

	UINT m_timerID;
	DWORD m_lastcalltime;    

    CFFTDlg m_fftDlg;
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_USDATAPROCESSINGDLG_H__F4138023_3C83_11D4_9745_0050BAD1E4E7__INCLUDED_)
