#include "stdafx.h"
#include "Channels.h"
#include "MainDlg.h"
#include "ChannelsDlg.h"
#include "SignalDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef DATA_PATH
   #define DATA_PATH   "../../dat/"
#endif

extern CString strformat(char *);
extern CChannelsApp theApp;

CMainDlg::CMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainDlg)	
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainDlg)
	DDX_Control(pDX, IDC_LOG, m_log);	
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	//{{AFX_MSG_MAP(CMainDlg)	
	ON_BN_CLICKED(IDC_DATATEST, OnChannelTest)	
	ON_BN_CLICKED(IDC_INITHW, OnInitHW)	
	ON_BN_CLICKED(IDC_READPROBES, OnReadProbes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CMainDlg::DoModal()
{ 
	return CDialog::DoModal();

}

BOOL CMainDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	m_texo = new texo();

	UpdateData(FALSE);

	return TRUE;
	
}

void CMainDlg::OnClose()
{
	if(m_texo)
	{
		if(m_texo->isImaging())
			m_texo->stopImage();

		m_texo->shutdown();
	}

	CDialog::OnClose();
}

void CMainDlg::OnChannelTest() 
{
	if(!m_texo->isInitialized())
		return;

	CChannelsDialog dlog(m_texo);
	dlog.DoModal();
}

void CMainDlg::OnInitHW() 
{
	UpdateData();

	theApp.AddText(&m_log, "Initializing Electronics...");

	// init electronics
    if(!m_texo->init(DATA_PATH, 2, 2, 0, 0, 0))
        theApp.AddText(&m_log, "Error initializing electronics\r\n");

    else
    {
		theApp.AddText(&m_log, "Passed\r\n");
				
		GetDlgItem(IDC_DATATEST)->EnableWindow(TRUE);        
        GetDlgItem(IDC_READPROBES)->EnableWindow(TRUE);
    }	
}

void CMainDlg::OnReadProbes() 
{
    CString msg;
    int i;

    theApp.AddText(&m_log, "\r\nProbe Codes:\r\n");

    char name[80];
	CString prbName = _T("");

    for(i = 0; i < 3; i++)
    {
        if(m_texo->getProbeName(i, name, 80))    
		{
			prbName = strformat(name);
			msg.Format(_T("Connector %d: %s\r\n"), i+1, prbName);
		}

        else
			msg.Format(_T("Connector %d: N/A \r\n"), i+1);

		theApp.AddText(&m_log, msg);
    }

}
