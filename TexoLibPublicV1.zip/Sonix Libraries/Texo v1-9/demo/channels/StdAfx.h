#if !defined(AFX_STDAFX_H__B66C1BC9_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
#define AFX_STDAFX_H__B66C1BC9_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include <afxwin.h>         // MFC core and standard components
#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <afxdisp.h>
#include <afxpriv.h>

//#include <shlwapi.h>
//#pragma comment(lib, "shlwapi.lib")

#define EXCLUDE_GDIPLUS

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_STDAFX_H__B66C1BC9_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
