#if !defined(AFX_HWTEST_H__B66C1BC5_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
#define AFX_HWTEST_H__B66C1BC5_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define WM_CHANNEL_SELECT	WM_USER+1

#include "resource.h"

class CChannelsApp : public CWinApp
{
public:
	CChannelsApp();

    static bool AddText(CEdit * e, CString s);

	//{{AFX_VIRTUAL(CChannelsApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CChannelsApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_HWTEST_H__B66C1BC5_E63C_11D3_B89C_0050BAA88BAD__INCLUDED_)
