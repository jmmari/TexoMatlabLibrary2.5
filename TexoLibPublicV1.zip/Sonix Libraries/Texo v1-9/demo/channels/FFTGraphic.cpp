#include "stdafx.h"
#include "Channels.h"
#include "FFTGraphic.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define FFTSIZE		1024

/////////////////////////////////////////////////////////////////////////////
// CFFTGraphic
// 
// 03.14.00 LP created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// sets the initial values.
//////////////////////////////////////////////////////////////////////////
CFFTGraphic::CFFTGraphic()
{
	m_zoom = 100;
	m_amplitude = 100;
	m_offset = 0;
		
	m_wantcopy = false;
	m_bColor = false;
	
	m_avgcoef = 8;
	m_fftdata = new double[(FFTSIZE*2)+1];
	m_fftpreviousdata = new double[(FFTSIZE*2)+1];
	m_calibrationdata = new double[(FFTSIZE*2)+1];
	for (int i=0; i<(FFTSIZE*2)+1; i++)
		m_fftpreviousdata[i] = m_calibrationdata[i] = 0;
}

CFFTGraphic::~CFFTGraphic()
{
	m_data.RemoveAll();
	if(m_fftdata)
		delete [] m_fftdata;
	if(m_fftpreviousdata)
		delete [] m_fftpreviousdata;
	if(m_calibrationdata)
		delete [] m_calibrationdata;
}

BEGIN_MESSAGE_MAP(CFFTGraphic, CWnd)
	//{{AFX_MSG_MAP(CFFTGraphic)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDM_COPYBITMAP, OnCopybitmap)
	ON_COMMAND(IDM_CHANGECOLOR, OnChangecolor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OnPaint
// 
// 03.14.00 LP created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// draws the graphic.
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::OnPaint() 
{
	CPaintDC	dc(this);
	CPen		redpen(PS_SOLID, 1, RGB(0xff, 0x00, 0x00));
	CPen		bluepen(PS_SOLID, 1, RGB(0x00, 0x00, 0xff));
	CPen		blackpen(PS_SOLID, 1, RGB(0,0,0));
	int i;
	
	// retrieve the window size
	CRect		r;
	GetClientRect(&r);

	// create an offscreen bitmap to draw the graphic
	CDC			offscreendc;
	CBitmap		bm;
	offscreendc.CreateCompatibleDC(&dc);
	bm.CreateCompatibleBitmap(&dc, r.Width(), r.Height());
	offscreendc.SelectObject(&bm);

	// fill the dc with a soft yellow pattern
	CBrush		softyellowbrush(RGB(0xfb, 0xfb, 0xd3));
	offscreendc.FillRect(r, &softyellowbrush);

	// draw curve m_data
	if(!m_bColor)
		offscreendc.SelectObject(&redpen);
	else
		offscreendc.SelectObject(&bluepen);

	int	x, y;
	x = (m_zoom*0)/100+m_offset;
	y = r.bottom-(((int)(m_fftdata[0]-m_calibrationdata[0]))*m_amplitude)/100;
	offscreendc.MoveTo(x, y);
	for(i = 1; i < FFTSIZE; i++)
	{
		x = (m_zoom*i)/100+m_offset;
		if(x > r.right)
			break;

		y = r.bottom-25-(((int)(m_fftdata[i]-m_calibrationdata[i]))*m_amplitude)/100;
		offscreendc.LineTo(x,y);
	}
	
	// draw the tic marks
	offscreendc.SelectObject(&blackpen);
	DrawTickMarks(&offscreendc, r);

	// draw the text
	DrawText(&offscreendc, r);
	
	// copy the offscreen dc to the screen
	dc.BitBlt(0, 0, r.Width(), r.Height(), &offscreendc, 0, 0, SRCCOPY);

	if(m_wantcopy)
	{
		m_wantcopy = false;
		HBITMAP hBitmap = (HBITMAP)bm.Detach();
		OpenClipboard();
		EmptyClipboard();
		SetClipboardData(CF_BITMAP, hBitmap);
		CloseClipboard();
	}
}

/////////////////////////////////////////////////////////////////////////////
// DrawTickMarks
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::DrawTickMarks(CDC *dc, CRect r)
{	
	double j, div = (double)FFTSIZE / 40.0;
	int x, y;
	
	for(j = 0; j <= FFTSIZE+1; j+=div)
	{	
		x = (int)((m_zoom*j)/100.0+m_offset);
		if(x > r.right)
			break;

		dc->MoveTo(x, r.bottom-15);
		dc->LineTo(x, r.bottom-25);
	}

	for(y = r.bottom-25; y >= 0; y-=20)
	{
		dc->MoveTo(r.left + 20, y);
		dc->LineTo(r.left + 25, y);
	}
}

/////////////////////////////////////////////////////////////////////////////
// DrawText
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::DrawText(CDC *dc, CRect r)
{
	CFont f;
	f.CreatePointFont(80, _T("Arial Narrow"));
	dc->SelectObject(&f);
	dc->SetBkMode(TRANSPARENT);

	// draw the frequency text
	int x, y, tic = 0, btext = 100;
	double j, div = (double)FFTSIZE / 40.0;
	CString s;
	CSize sz;
	
	for(j = 0; j <= FFTSIZE+1; j+=div)
	{	
		x = (int)((m_zoom*j)/100+m_offset);
		if(x > r.right)
			break;
		
		if(btext > 30)
		{
			s.Format(_T("%d"), tic);
			sz = dc->GetTextExtent(s);
			dc->TextOut(x- (sz.cx/2), r.bottom-15, s);
			btext=0;
		}

		if(j < FFTSIZE / 2)
			tic++;
		else
			tic--;
		
		btext += (int)(((m_zoom*j)/100) - ((m_zoom*(j-div))/100));
	}

	for(y = r.bottom-25; y >= 0; y-=20)
	{
		x = ((r.bottom-25-y)*100)/m_amplitude;

		s.Format(_T("%d"), x);
		sz = dc->GetTextExtent(s);
		dc->TextOut(0, y - (sz.cy / 2), s);
	}
}

/////////////////////////////////////////////////////////////////////////////
// OnContextMenu
// 
// 11.16.01 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// handles the right mouse button to display the context menu
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::OnContextMenu(CWnd* pWnd, CPoint point) 
{
    UNUSED_ALWAYS(pWnd);

	if(m_data.GetSize() == 0)
		return;

	DWORD res = 1; //0
	CMenu menu;
		
	if (menu.LoadMenu(IDR_CONTEXTMENU))
	{
		CMenu* pPopup = menu.GetSubMenu(res);
		ASSERT(pPopup != NULL);

		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
			point.x, point.y, this);
	}
}

/////////////////////////////////////////////////////////////////////////////
// OnCopybitmap
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::OnCopybitmap() 
{
	m_wantcopy = true;
	RedrawWindow();
}

/////////////////////////////////////////////////////////////////////////////
// OnChangecolor
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::OnChangecolor() 
{
	m_bColor = !m_bColor;	
}

/////////////////////////////////////////////////////////////////////////////
// Process
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::Process(CDWordArray *dwa)
{
	int v, i;
	m_data.RemoveAll();
	m_data.Append(*dwa);
	int dsize = m_data.GetSize(), size = FFTSIZE;
	
	for(i = 0; i < size; i++)
	{
        if(i < dsize)
		    v = m_data[i];
        else
            v = 0;

		if (v & 0x8000000) v |= 0xffffffff80000000;
		m_fftdata[(i*2)+1] = v;
		m_fftdata[(i*2)+2] = 0;
	}
	
	/*
	for(i = 0; i < size; i++)
	{
		m_fftdata[(i*2)+1] = 200*sin((2*3.14159*i)/(40.0/5.0));
		m_fftdata[(i*2)+2] = 0;
	}
	*/

	FFT(m_fftdata, FFTSIZE, 1);
	Modulus(m_fftdata, m_fftpreviousdata, FFTSIZE);

	RedrawWindow();	
}

/////////////////////////////////////////////////////////////////////////////
// FFT
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::FFT(double *data, int nn, int isign)
{
	#define		SWAP(a,b)	tempr=(a);(a)=(b);(b)=tempr
	
	int		n, mmax, m, j, istep, i;
	double	wtemp, wr, wpr, wpi, wi, theta;
	double	tempr, tempi;

	n = nn << 1;
	j = 1;

	// bit reversal section of the routine
	for (i=1; i<n; i+=2)
	{
		if (j > i)
		{
			SWAP(data[j], data[i]);
			SWAP(data[j+1], data[i+1]);
		}
		m = n >> 1;
		while ((m >= 2) && (j > m))
		{
			j -= m;
			m >>= 1;
		}
		j += m;
	}

	// Danielson-Lanczos section of the routine
	// Outer loop executed log2(nn) times
	mmax = 2;
	while (n > mmax)
	{
		istep = 2*mmax;
		theta = 6.28318530717959/(isign*mmax);
		wtemp = sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi = sin(theta);
		wr = 1.0;
		wi = 0.0;
		// the 2 nested inner loops
		for (m=1; m<mmax; m+=2)
		{
			for (i=m; i<=n; i+=istep)
			{
				// Danielson Lanczos formula
				j = i+mmax;
				tempr = wr*data[j]-wi*data[j+1];
				tempi = wr*data[j+1]+wi*data[j];
				data[j] = data[i] - tempr;
				data[j+1] = data[i+1] - tempi;
				data[i] += tempr;
				data[i+1] += tempi;
			}
			wr = (wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax = istep;
	}
}

/////////////////////////////////////////////////////////////////////////////
// Modulus
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::Modulus(double *data, double *previousdata, int nn)
{
	int i;
	double val;
	for(i = 0; i < nn; i ++)
	{
		val = sqrt( (data[(i*2)+1]*data[(i*2)+1]) + (data[(i*2)+2]*data[(i*2)+2]) );
		val /= 200;
		// show the data in dB
		val = 50*log(1+val);
		data[i] = (val+m_avgcoef*previousdata[i])/(1+m_avgcoef);
		previousdata[i] = data[i];
	}
}

/////////////////////////////////////////////////////////////////////////////
// Calibrate
// 
// 05.23.2003 KD created
//
// class                  : CFFTGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// saves data in calibration data
//////////////////////////////////////////////////////////////////////////
void CFFTGraphic::Calibrate()
{
	int		i;
	for (i=0; i<FFTSIZE; i++)
		m_calibrationdata[i] = m_fftdata[i];
}
