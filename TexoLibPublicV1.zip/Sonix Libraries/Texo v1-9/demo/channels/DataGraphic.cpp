#include "stdafx.h"
#include "Channels.h"
#include "DataGraphic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataGraphic
// 
// 03.14.00 LP created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// sets the initial values.
//////////////////////////////////////////////////////////////////////////
CDataGraphic::CDataGraphic()
{
	m_max = 1;
	m_min = -1;
	m_npoints = 100;
	m_offset = 0;
	m_selecting = false;
	m_dataselected = false;
	
	m_copyBitmap = false;
	m_bColor = false;

	m_backColor = RGB(240,240,255);//RGB(0xfb, 0xfb, 0xd3);
}

CDataGraphic::~CDataGraphic()
{
}

BEGIN_MESSAGE_MAP(CDataGraphic, CWnd)
	//{{AFX_MSG_MAP(CDataGraphic)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDM_CONTEXT_COPY, OnContextCopy)
	ON_COMMAND(IDM_EXCEL, OnExcel)
	ON_COMMAND(IDM_UPDATELIST, OnUpdatelist)	
	ON_COMMAND(IDM_FREQ, OnFreq)
	ON_COMMAND(IDM_COPYBITMAP, OnCopybitmap)
	ON_COMMAND(IDM_CHANGECOLOR, OnChangecolor)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OnPaint
// 
// 03.14.00 LP created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// draws the graphic.
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnPaint() 
{    
	CPaintDC	dc(this);
	CPen		redpen(PS_SOLID, 1, RGB(0xff, 0x00, 0x00));
	CPen		bluepen(PS_SOLID, 1, RGB(0x00, 0x00, 0xff));
	CPen		blackpen(PS_SOLID, 1, RGB(0x00, 0x00, 0x00));
	CString s;
	int	start, end, posx;
	
	CRect r;
	GetClientRect(&r);

	CFont font;
	font.CreatePointFont(90, _T("Arial"));

	// create an offscreen bitmap to draw the graphic
	CDC	bkDc;
	CBitmap	bm;
	bkDc.CreateCompatibleDC(&dc);
	bm.CreateCompatibleBitmap(&dc, r.Width(), r.Height());
	bkDc.SelectObject(&bm);

	// fill the dc with a soft yellow pattern	
	bkDc.FillSolidRect(r, m_backColor);

	start = m_selection_start < m_selection_end ? m_selection_start : m_selection_end;
	end = m_selection_start > m_selection_end ? m_selection_start : m_selection_end;

	if(m_dataselected)
	{
		bkDc.SelectObject(&blackpen);

		for(posx = start; posx <= end; posx++)
		{
			bkDc.MoveTo(posx, r.top);
			bkDc.LineTo(posx, r.bottom);
		}
	}

	// draw curve m_data
	if(!m_bColor)
		bkDc.SelectObject(&redpen);
	else
		bkDc.SelectObject(&bluepen);

	posx = 0;
	bkDc.MoveTo(posx, GetPosY(r, posx));
	for (posx = 0; posx <= r.Width(); posx++)
		bkDc.LineTo(posx, GetPosY(r, posx));

	// if possible, draw curve m_data1
	if (m_data1.GetSize())
	{
		if(!m_bColor)
			bkDc.SelectObject(&bluepen);
		else
			bkDc.SelectObject(&redpen);

		posx = 0;
		bkDc.MoveTo(posx, GetPosY(r, posx, 1));
		for (posx = 0; posx <= r.Width(); posx++)
			bkDc.LineTo(posx, GetPosY(r, posx, 1));
	}
	
	bkDc.SelectObject(font);
	bkDc.SetBkColor(m_backColor);

	bkDc.TextOut(0,0, m_display);
	dc.BitBlt(0, 0, r.Width(), r.Height(), &bkDc, 0, 0, SRCCOPY);

	if(m_copyBitmap)
	{
		m_copyBitmap = false;
		HBITMAP hBitmap = (HBITMAP)bm.Detach();
		OpenClipboard();
		EmptyClipboard();
		SetClipboardData(CF_BITMAP, hBitmap);
		CloseClipboard();
	}
}

/////////////////////////////////////////////////////////////////////////////
// GetPosY
// 
// 03.14.00 LP created
//
// class                  : CDataGraphic
// input parameters       : r		:	window rectangle
//							posx	:	x position of pixel
//							dataID	:	0 to access m_data, 1 to access m_data1, etc...
// output parameters      : n/a
// returned value	      : y position of pixel
//
// description:
// given the posx value, finds the posy y coordinate of the data.
//////////////////////////////////////////////////////////////////////////
int CDataGraphic::GetPosY(CRect & r, int posx, int dataID, bool formatfordisplay, CDWordArray *data)
{
	int x = 0, y = 0;
		
	// depending on dataID, access m_data, m_data1, etc...
	if(!data)
	{
		if(dataID == 1)
			data = &m_data1;
		else
			data = &m_data;
	}

    if(!r.Width())
        return 0;

	// m_npoints are shown in r->Width(), x is:
	x = ((posx * m_npoints) / r.Width()) + m_offset;
	// retrieve the data at x
	if (x < data->GetSize())
		y = (long) data->GetAt(x);
	else
		y = 0;

	// extend sign bit
	if (y & 0x8000) 
		y |= 0xffff8000;
        
	if(!formatfordisplay)
		return y;

	// format y given m_max and m_min
	if (y > m_max) y = m_max;
	if (y < m_min) y = m_min;
	
	if(m_max == m_min)
		y = 0;
	else
		y = r.bottom - ( ((y-m_min)*r.Height()) / (m_max - m_min) );
	
	// return the y coordinate
	return y;
}

/////////////////////////////////////////////////////////////////////////////
// OnLButtonDown
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// handles the left mouse button when selecting data in a graphic
// also de-selects data when data is already selected
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CRect r;
	GetClientRect(&r);

	if(!m_dataselected)
	{
		m_selecting = true;	
		m_selection_start = point.x;
		m_selection_end = point.x;

		if(m_selection_start < r.left)
			m_selection_start = r.left;
		if(m_selection_start > r.right)
			m_selection_start = r.right;
		if(m_selection_end < r.left)
			m_selection_end = r.left;
		if(m_selection_end > r.right)
			m_selection_end = r.right;

		m_dataselected = true;

		SetCapture();
	}
	else
		m_dataselected = false;
	
	RedrawWindow();

	CWnd::OnLButtonDown(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// OnMouseMove
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// updates the selection end point and redraws the window when selecting data
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnMouseMove(UINT nFlags, CPoint point) 
{
	CRect r;
	GetClientRect(r);

	if(m_selecting)
	{
		m_selection_end = point.x;
		if(m_selection_end < r.left)
			m_selection_end = r.left;
		if(m_selection_end > r.right)
			m_selection_end = r.right;
		RedrawWindow();
	}

	CWnd::OnMouseMove(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// OnLButtonUp
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// sets the flag that a selection is no longer taking place
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_selecting = false;
	RedrawWindow();
	ReleaseCapture();

	if(abs(m_selection_end - m_selection_start) < 5)
	{
		m_dataselected = false;
		::PostMessage(GetParent()->GetSafeHwnd(), WM_CHANNEL_SELECT, m_index, 0);		
	}

	CWnd::OnLButtonUp(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// OnContextMenu
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// handles the right mouse button to display the context menu
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnContextMenu(CWnd* pWnd, CPoint point) 
{
    UNUSED_ALWAYS(pWnd);

	if(m_data.GetSize() == 0)
		return;

	DWORD res;
	CMenu menu;
	
	if(!m_dataselected)
		res = 1;
	else
		res = 0;
    
	if (menu.LoadMenu(IDR_CONTEXTMENU))
	{
		CMenu* pPopup = menu.GetSubMenu(res);
		ASSERT(pPopup != NULL);

		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON,
			point.x, point.y, this);
	}
}

/////////////////////////////////////////////////////////////////////////////
// OnContextCopy
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// handles the context menu 'Copy' command, copies the selected data to the clipboard
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnContextCopy() 
{
	int posx;
	int start = m_selection_start < m_selection_end ? m_selection_start : m_selection_end,
		end = m_selection_start > m_selection_end ? m_selection_start : m_selection_end;
	
	CRect r;
	GetClientRect(r);

	CString str, s = _T("");
	for (posx = start; posx <= end; posx++)
	{
		str.Format(_T("%d\r\n"), GetPosY(r, posx, 0, false));
		s+=str;
	}

	OpenClipboard();
	EmptyClipboard();
	
	int size = s.GetLength() + 1;
	HANDLE hData = ::GlobalAlloc(GMEM_MOVEABLE, (size) * sizeof(TCHAR));
	LPTSTR pData = (LPTSTR)::GlobalLock(hData);
	::lstrcpy(pData, s.GetBuffer(size));
	::GlobalUnlock(hData);

#ifdef _UNICODE
	SetClipboardData(CF_UNICODETEXT, hData);
#else
	SetClipboardData(CF_TEXT, hData);
#endif

	CloseClipboard();	
}

/////////////////////////////////////////////////////////////////////////////
// OnExcel
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// copies the data and displays a graph in excel
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnExcel() 
{
	int i;

	// Copy the data
	OnContextCopy();

	// Run Excel
	ShellExecute(GetSafeHwnd(), _T("open"), _T("excel.exe"), NULL, NULL, SW_SHOWNORMAL);

	Sleep(500);

	// Run the keyboard sequence to paste the data and create a graph
	keybd_event(VK_CONTROL,0,0,0);
    keybd_event('V',0,0,0);
    keybd_event('V',0,KEYEVENTF_KEYUP,0);
    keybd_event(VK_CONTROL,0,KEYEVENTF_KEYUP,0);

	Sleep(100);

	keybd_event(VK_MENU,0,0,0);
    keybd_event('I',0,0,0);
    keybd_event('I',0,KEYEVENTF_KEYUP,0);
    keybd_event(VK_MENU,0,KEYEVENTF_KEYUP,0);
	
	keybd_event('H',0,0,0);
    keybd_event('H',0,KEYEVENTF_KEYUP,0);

	for(i = 0; i < 2; i++)
	{
		keybd_event(VK_DOWN,0,0,0);
		keybd_event(VK_DOWN,0,KEYEVENTF_KEYUP,0);
	}

	keybd_event(VK_TAB,0,0,0);
	keybd_event(VK_TAB,0,KEYEVENTF_KEYUP,0);

	for(i = 0; i < 3; i++)
	{
		keybd_event(VK_LEFT,0,0,0);
		keybd_event(VK_LEFT,0,KEYEVENTF_KEYUP,0);
	}

	keybd_event(VK_MENU,0,0,0);
    keybd_event('F',0,0,0);
    keybd_event('F',0,KEYEVENTF_KEYUP,0);
    keybd_event(VK_MENU,0,KEYEVENTF_KEYUP,0);
}

/////////////////////////////////////////////////////////////////////////////
// OnFreq
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// context menu to message box the frequency
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnFreq() 
{
	CString s;
	s.Format(_T("Freq = %.3f MHz"), GetFreq());
	MessageBox(s);	
}

/////////////////////////////////////////////////////////////////////////////
// OnUpdatelist
// 
// 05.22.2003 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnUpdatelist() 
{	
}

/////////////////////////////////////////////////////////////////////////////
// GetFreq
// 
// 11.16.01 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
// Computes frequency of wave based on selected length
//////////////////////////////////////////////////////////////////////////
double CDataGraphic::GetFreq()
{
	if(!m_dataselected)
		return 0;

	int posx;
	int start = m_selection_start < m_selection_end ? m_selection_start : m_selection_end,
		end = m_selection_start > m_selection_end ? m_selection_start : m_selection_end;
	
	CRect r;
	GetClientRect(r);

	long cross = 0, sum = 0;
	long y, ncross, prev = 0;

	CDWordArray data;
	data.Append(m_data);

	CWordArray wa;

	for (posx = start; posx <= end; posx++)
	{
		y = GetPosY(r, posx, 0, false, &data);

		sum++;

		// check if we crossed the horizontal axis
		if( ((prev >= 0 && y < 0) || (prev > 0 && y <= 0) || 
			(prev <= 0 && y > 0) || (prev < 0 && y >= 0) ) && posx != start)
		{
			if(wa.GetSize() == 0)
				ncross = 3;
			else
				ncross = 2;

			if(++cross == ncross)
			{
				cross = 0;
				wa.Add((WORD)(sum));
				sum = 0;					
			}
		}
		
		prev = y;
	}

	if(wa.GetSize() == 0)
		return 0;

	double avg = 0;
	for(y = 0; y < wa.GetSize(); y++)
		avg += wa.GetAt(y);
	avg /= wa.GetSize();

	double freq = (1.0 / (avg * 25.0) * 1000.0);

	return freq;
}

/////////////////////////////////////////////////////////////////////////////
// OnCopybitmap
// 
// 05.22.2003 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnCopybitmap() 
{
	m_copyBitmap = true;
	RedrawWindow();
}

/////////////////////////////////////////////////////////////////////////////
// OnChangecolor
// 
// 05.22.2003 KD created
//
// class                  : CDataGraphic
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CDataGraphic::OnChangecolor() 
{
	m_bColor = !m_bColor;	
	RedrawWindow();
}

void CDataGraphic::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CRect r;
	GetClientRect(&r);
	m_selecting = true;	
	m_selection_start = r.left;
	m_selection_end = r.right;

	CWnd::OnLButtonDblClk(nFlags, point);
}
