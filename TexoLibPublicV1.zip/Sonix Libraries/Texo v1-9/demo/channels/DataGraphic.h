#if !defined(AFX_DATAGRAPHIC_H__02C95214_F9C4_11D3_B8BC_0050BAA88BAD__INCLUDED_)
#define AFX_DATAGRAPHIC_H__02C95214_F9C4_11D3_B8BC_0050BAA88BAD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif

class CDataGraphic : public CWnd
{

public:
	CDataGraphic();
	virtual ~CDataGraphic();
	
	double GetFreq();	
	int GetPosY(CRect & r, int posx, int dataID = 0, bool formatfordisplay = true, CDWordArray *data = NULL);
	void SetMinMax(int min, int max) { m_min = min; m_max = max; }
	
	bool m_bColor;
	bool m_copyBitmap;
	bool m_dataselected;
	bool m_selecting;
	
	int m_selection_end;
	int m_selection_start;	
	int m_offset;
	int m_npoints;
	int m_index;
	COLORREF m_backColor;
	
	CString m_display;
	CDWordArray m_data;
	CDWordArray m_data1;	

protected:
	//{{AFX_MSG(CDataGraphic)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnContextCopy();
	afx_msg void OnExcel();
	afx_msg void OnUpdatelist();	
	afx_msg void OnFreq();
	afx_msg void OnCopybitmap();
	afx_msg void OnChangecolor();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	int m_max;
	int m_min;
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_DATAGRAPHIC_H__02C95214_F9C4_11D3_B8BC_0050BAA88BAD__INCLUDED_)
