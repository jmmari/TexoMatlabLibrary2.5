#include "stdafx.h"
#include "Channels.h"
#include "SignalDlg.h"
#include <texo.h>
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CChannelsApp theApp;

//using namespace UTX_MFC_CONVERSIONS;

CFFTDlg::CFFTDlg()
{	
}

void CFFTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFFTDlg)	
	DDX_Control(pDX, IDC_SLIDERFFTOFFSET, m_sliderfftoffset);
	DDX_Control(pDX, IDC_SLIDERFFTZOOM, m_sliderfftzoom);
	DDX_Control(pDX, IDC_SLIDERFFTAMPLITUDE, m_sliderfftamplitude);	
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFFTDlg, CDialog)
	//{{AFX_MSG_MAP(CFFTDlg)
	ON_WM_HSCROLL()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CALIBRATE, OnCalibrate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

bool CFFTDlg::Create(CWnd *pParent)
{
	m_parent = (CDialog*)pParent;

    if(!CDialog::Create(IDD_FFTDLG, pParent))
		return false;

	ShowWindow(SW_SHOWNORMAL);

    m_fftamplitude = 100;
	m_fftzoompos = 100;
	m_fftoffsetpos = 0;

	m_sliderfftzoom.SetRange(30, 500);
	m_sliderfftzoom.SetPos(m_fftzoompos);

	m_sliderfftoffset.SetRange(-512, 512);
	m_sliderfftoffset.SetPos(m_fftoffsetpos);
	
	m_sliderfftamplitude.SetRange(5, 300);
	m_sliderfftamplitude.SetPos(m_fftamplitude);

	UpdateData(FALSE);

	m_fftgraphic = CreateFFTGraphicWindow(IDC_FFT);
    
    m_fftgraphic->m_zoom = m_fftzoompos;
	m_fftgraphic->m_offset = m_fftoffsetpos;
	m_fftgraphic->m_amplitude = m_fftamplitude;
		
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// CreateFFTGraphicWindow
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
CFFTGraphic* CFFTDlg::CreateFFTGraphicWindow(int frameID)
{
	CWnd *cnt = GetDlgItem(frameID);
	CRect r;

	// retrieve the control's rectangle in local coordinates
	cnt->GetWindowRect(&r);
	ScreenToClient(&r);

	// create a CDataGraphic object in the rectangle r
	CFFTGraphic	*dg;
	dg = new CFFTGraphic;
	dg->Create(NULL, NULL, WS_BORDER | WS_CHILD | WS_VISIBLE, r, this, 0);

	// return the newly created data graphic object
	return dg;
}

/////////////////////////////////////////////////////////////////////////////
// UpdateFFT
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTDlg::UpdateFFT(CDWordArray * data)
{    
    m_fftgraphic->m_zoom = m_fftzoompos;
	m_fftgraphic->m_offset = m_fftoffsetpos;
	m_fftgraphic->m_amplitude = m_fftamplitude;
        
    m_fftgraphic->Process(data);
}

/////////////////////////////////////////////////////////////////////////////
// OnOK
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTDlg::OnOK() 
{
	UpdateData(TRUE);

	// save values in the registry
	m_fftzoompos = m_sliderfftzoom.GetPos();
	m_fftoffsetpos = m_sliderfftoffset.GetPos();
	m_fftamplitude = m_sliderfftamplitude.GetPos();
		
	EndDialog(0);
	DestroyWindow();
}

/////////////////////////////////////////////////////////////////////////////
// OnHScroll
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	if (*pScrollBar == m_sliderfftamplitude)
		m_fftamplitude = m_sliderfftamplitude.GetPos();
	if (*pScrollBar == m_sliderfftzoom)
		m_fftzoompos = m_sliderfftzoom.GetPos();
	if (*pScrollBar == m_sliderfftoffset)
		m_fftoffsetpos = m_sliderfftoffset.GetPos();

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

/////////////////////////////////////////////////////////////////////////////
// OnDestroy
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTDlg::OnDestroy() 
{	
	CDialog::OnDestroy();
		
	delete m_fftgraphic;	
}

/////////////////////////////////////////////////////////////////////////////
// OnCalibrate
// 
// 05.20.2003 KD created
//
// class                  : CFFTDlg
// input parameters       : n/a
// output parameters      : n/a
// returned value	      : n/a
//
// description:
//////////////////////////////////////////////////////////////////////////
void CFFTDlg::OnCalibrate() 
{	
	m_fftgraphic->Calibrate();	
}
