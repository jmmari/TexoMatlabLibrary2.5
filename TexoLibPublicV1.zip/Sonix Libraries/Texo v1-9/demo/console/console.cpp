// texo demonstration program
// Ultrasonix Medical Corporation (2007)
//
// description:     
// program type:    console
// inputs:          menu selection
// outputs:         data file via menu selection

// header files
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <texo.h>
#include <texo_def.h>

// constants
#define NUMCHANNELS         32
#define MAXELEMENTS         128
#ifndef DATA_PATH
    #define DATA_PATH       "../../dat/"
#endif

// prototypes
bool selectProbe(int connector);
bool createSequence(int sequence);
bool run();
bool stop();
bool newImage(void *, unsigned char *, int);
bool sequenceRF();
bool sequenceSingleElement();
bool sequenceSingleChannel();
bool sequencePhasedArrayChannels();
bool sequenceARFI();
bool setupMotor();
void printStats();
bool saveData();
void wait();

// global variables
texo tex;
bool running = false;
bool validprobe = false;
bool validsequence = false;
int depth = 50;

// program entry point
int main()
{    
    char sel;
	
    // initialize and set the data file path
    if(!tex.init(DATA_PATH, 2, 2, 0, 0, 0))
        return -1;
    
    // set the new frame callback
    tex.setCallback(newImage, 0);

    // initialize global parameters
    tex.setPower(15, 15, 15);
    tex.addTGC(0.80);
      
    for(;;)
    {
        printf("make a selection:\n");
        printf("\n");
        printf("(A) select probe connector 1\n");
        printf("(B) select probe connector 2\n");
        printf("(C) select probe connector 3\n");
        printf("\n");
        printf("(1) load rf collection sequence\n");
        printf("(2) load single element sequence\n");
        printf("(3) load single channel sequence\n");
        printf("(4) load phased-array sequence\n");
        printf("(5) load ARFI sequence\n");        
        printf("\n");
        printf("(M) setup motor\n");
        printf("(R) run sequence\n");
        printf("(S) stop sequence\n");
        printf("\n");
        printf("(D) store data to disk\n");
        printf("(X) exit\n");
        printf("\n");
        scanf("%c", &sel);
        
        switch(sel)
        {
            case 'a': case 'A': selectProbe(0); break;
            case 'b': case 'B': selectProbe(1); break;
            case 'c': case 'C': selectProbe(2); break;
            case '1': createSequence(1); break;
            case '2': createSequence(2); break;
            case '3': createSequence(3); break;
            case '4': createSequence(4); break;
            case '5': createSequence(5); break;
            case 'm': case 'M': setupMotor(); break;
            case 'r': case 'R': run(); break;
            case 's': case 'S': stop(); break;
            case 'd': case 'D': saveData(); break;
            case 'x': case 'X': goto goodbye;
        }

        wait();        
    }

goodbye:
    
    if(running)
        stop();

    // clean up
    tex.shutdown();

	return 0;
}

void wait()
{
    printf("\npress any key to continue");
    while(!kbhit());
    getch();
    fflush(stdin);
    system("cls");
}

// statistics printout for after sequence has been loaded
void printStats()
{
    // print out sequence statistics
    printf("sequence statistics:\n");
    printf("frame size = %d bytes\n", tex.getFrameSize());
    printf("frame rate= %.1f fr/sec\n", tex.getFrameRate());
    printf("buffer size = %d frames\n\n", tex.getMaxFrameCount());    
}

// selects a probe, the function will fail if the connector is invalid or if there is no probe
// on the specified connector.
bool selectProbe(int connector)
{    
    if(!tex.activateProbeConnector(connector))
    {
        fprintf(stderr, "could not activate connector %d\n", connector);
        return false;
    }

    validprobe = true;
    return true;
}

// runs a sequence
bool run()
{
    if(!validsequence)
    {
        fprintf(stderr, "cannot run, no sequence selected\n");
        return false;
    }
    
    if(running)
    {
        fprintf(stderr, "sequence is already running\n");
        return false;
    }

    if(tex.runImage())
    {
        running = true;
        return true;
    }

    return false;
}

// stops a sequence from running
bool stop()
{
    if(!running)
    {
        fprintf(stderr, "nothing to stop, sequence is not running\n");
        return false;
    }
            
    if(tex.stopImage())
    {
        running = false;        
        fprintf(stdout, "acquired (%d) frames\n", tex.getCollectedFrameCount());

        return true;
    }

    return false;
}

bool createSequence(int sequence)
{    
    if(!validprobe)
    {
        fprintf(stderr, "cannot create sequence, no probe selected\n");
        return false;
    }

    printf("enter desired depth in mm (10 - 300):\n");
    scanf("%d", &depth);    
    if(depth < 10 || depth > 300)
    {
        fprintf(stderr, "invalid depth entered\n");
        return false;
    }

    // tell program to initialize for new sequence
    if(!tex.beginSequence())
        return false;

    // build sequence
    switch(sequence)
    {
        case 1:
            if(!sequenceRF())
                return false;
            break;
        case 2:
            if(!sequenceSingleElement())
                return false;
            break;
        case 3:
            if(!sequenceSingleChannel())
                return false;
            break;
        case 4:
            if(!sequencePhasedArrayChannels())
                return false;
            break;
        case 5:
            if(!sequenceARFI())
                return false;
            break;
    }

    // tell program to finish sequence
    if(tex.endSequence() == -1)
        return false;

    printStats();

    validsequence = true;
    return true;
}

// transmits and receives across the entire probe to acquire focused RF data from each element.
bool sequenceRF()
{
    int i, lineSize;
    texoTransmitParams tx;
    texoReceiveParams rx;

    tx.centerElement = 0;
    tx.aperture = 64;
    tx.focusDistance = 30000;
    tx.angle = 0;
    tx.frequency = tex.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;
    tx.trex = false;

    rx.centerElement = 0;
    rx.aperture = 32;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = depth * 1000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = true;
    rx.useManualDelays = false;
    rx.decimation = 1;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;
    
    for(i = 0; i < tex.getProbeNumElements(); i++)
    {
        // add 5 to the virtual element, to make symettrical time delays
        // we should do this because the aperture values must be even for now
        tx.centerElement = (i * 10) + 5;
        rx.centerElement = (i * 10) + 5;

        lineSize = tex.addLine(rfData, tx, rx);

        if(lineSize == -1)
            return false;
    }

    return true;
}

// transmits and receives across the entire probe to acquire single element RF data.
bool sequenceSingleElement()
{
    int i, lineSize;
    texoTransmitParams tx;
    texoReceiveParams rx;

    tx.centerElement = 0;
    // ** for single element transmit **
    tx.aperture = 0;
    tx.focusDistance = 30000;
    tx.angle = 0;
    tx.frequency = tex.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;
    tx.trex = false;

    rx.centerElement = 0;
    rx.aperture = 32;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = depth * 1000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = false;
    rx.useManualDelays = false;
    rx.decimation = 1;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;
    
    for(i = 0; i < tex.getProbeNumElements(); i++)
    {
        // add 5 to the virtual element, to make symettrical time delays
        // we should do this because the aperture values must be even for now
        tx.centerElement = (i * 10);
        rx.centerElement = (i * 10);
        
        // ** for single element receive **
        rx.channelMask[0] = 1 << (i % 32);

        lineSize = tex.addLine(rfData, tx, rx);

        if(lineSize == -1)
            return false;
    }

    return true;
}

// transmits and receives across the entire probe to acquire single channel RF data (full transmit still)
bool sequenceSingleChannel()
{
    int i, lineSize;
    texoTransmitParams tx;
    texoReceiveParams rx;

    tx.centerElement = 0;    
    tx.aperture = 64;
    tx.focusDistance = 30000;
    tx.angle = 0;
    tx.frequency = tex.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;
    tx.trex = false;

    rx.centerElement = 0;
    rx.aperture = 32;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = depth * 1000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = false;
    rx.useManualDelays = false;
    rx.decimation = 1;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;
    
    for(i = 0; i < tex.getProbeNumElements(); i++)
    {
        // add 5 to the virtual element, to make symettrical time delays
        // we should do this because the aperture values must be even for now
        tx.centerElement = (i * 10) + 5;
        rx.centerElement = (i * 10) + 5;
        
        // ** for single channel receive **
        rx.channelMask[0] = 1 << (i % 32);

        lineSize = tex.addLine(rfData, tx, rx);

        if(lineSize == -1)
            return false;
    }

    return true;
}

// acquires 32 channels for each 64 elements
bool sequencePhasedArrayChannels()
{
    int a, i, lineSize;
    int min, max, angle, ascans;

    texoTransmitParams tx;
    texoReceiveParams rx;

    // always keep tx/rx centered
    tx.centerElement = 315;    
    tx.aperture = 64;
    tx.focusDistance = 70000;
    tx.angle = 0;
    tx.frequency = tex.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;
    tx.trex = false;

    // always keep tx/rx centered
    rx.centerElement = 315;
    rx.aperture = 32;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = depth * 1000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    // ensure focus is applied, so that receive angle is considered
    rx.applyFocus = true;
    rx.useManualDelays = false;
    // want 40 MHz? set this to 0 and DDR=1, or use new PCI card
    rx.decimation = 1;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;

    min = 45000;
	max = -45000;
    ascans = tex.getProbeNumElements();
	
    // acquire on each element
    for(a = 0; a < ascans; a++)
    {        
        // compute angle
	    angle = min + (((max - min) * a) / (ascans - 1));    
        rx.angle = tx.angle = angle;

        tex.addReceive(rx);
        rx.tableIndex = a;

        // acquire all channels
        for(i = 0; i < 32; i++)
        {        
            // ** for single channel receive **
            rx.channelMask[0] = 1 << (i % 32);

            lineSize = tex.addLine(rfData, tx, rx);

            if(lineSize == -1)
                return false;
        }
    }

    return true;
}

// transmits extended pulses for ARFI
bool sequenceARFI()
{
    int i, lineSize;
    texoTransmitParams tx;
    texoReceiveParams rx;

    tx.centerElement = 64;
    tx.aperture = 64;
    tx.focusDistance = 100000;
    tx.angle = 0;
    tx.frequency = tex.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;
    tx.trex = false;

    rx.centerElement = 64;
    rx.aperture = 32;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = depth * 1000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = true;
    rx.useManualDelays = false;
    rx.decimation = 1;
    rx.customLineDuration = 0;
    rx.lgcValue = 0;
    rx.tgcSel = 0;
    rx.tableIndex = -1;
        
    for(i = 0; i < 10; i++)
    {
        rx.customLineDuration = 1000000;
        tex.addLine(rfData, tx, rx);
    }
    
    tx.trex = true;
    rx.customLineDuration = 100000;
    rx.acquisitionDepth = 0;
    lineSize = tex.addLine(rfData, tx, rx);

    return true;
}

bool setupMotor()
{
    int status, fpv, spf;

    printf("enable (1) or disable (0) motor?:\n");
    scanf("%d", &status);

    if(status == 0)
    {
        tex.setupMotor(false, 0, 0);
        return true;
    }

    printf("enter # frames per volume (must be odd):\n");
    scanf("%d", &fpv);
    if(fpv % 2 == 0)
    {
        fprintf(stderr, "invalid entry\n");
        return false;
    }

    printf("enter # steps per frame (must be one of: 2,4,8,16):\n");
    scanf("%d", &spf);    
    if(spf != 2 && spf != 4 && spf != 8 && spf != 16)
    {
        fprintf(stderr, "invalid entry\n");
        return false;
    }

    printf("-- a sequence must be loaded in order for changes to take effect --\n");

    tex.setupMotor(true, fpv, spf);

    return true;
}

// store data to disk
bool saveData()
{
    char path[100];
    int numFrames, frameSize;
    FILE * fp;

    numFrames = tex.getCollectedFrameCount();
    frameSize = tex.getFrameSize();

    if(numFrames < 1)
    {
        fprintf(stderr, "no frames have been acquired\n");
        return false;
    }

    printf("enter a filename: ");
    scanf("%s", path);

    fp = fopen(path, "wb+");
    if(!fp)
    {
        fprintf(stderr, "could not store data to specified path\n");
        return false;
    }

    fwrite(tex.getCineStart(), frameSize, numFrames, fp);
    
    fclose(fp);

    fprintf(stdout, "successfully stored data\n");

    return true;
}

// called when a new frame is received
bool newImage(void *, unsigned char * /*data*/, int /*frameID*/)
{    
    // withhold from printing out anything right now
    // fprintf(stdout, "new frame recieved addr=(0x%08x) id=(%d)\n", data, frameID);    
    return true;
}
