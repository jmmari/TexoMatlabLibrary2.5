#include "stdafx.h"
#include "utils.h"
#include <math.h>

CString STRCVT::CH2CS(char *c)
{
    CString cs;
    unsigned int i;

    for(i = 0; i < strlen(c); i++)
        cs += c[i];

    return cs;
}

CString STRCVT::STL2CS(std::string s)
{
    CString cs;

    unsigned int i;

    for(i = 0; i < s.size(); i++)
        cs += s[i];

    return cs;
}

std::string STRCVT::CS2STL(CString cs)
{
    std::string s;

    int i;

    for(i = 0; i < cs.GetLength(); i++)
        s += (char)cs[i];

    return s;
}