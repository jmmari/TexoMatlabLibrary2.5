#include "stdafx.h"
#include "elTest.h"
#include "elTestDlg.h"
#include "utils.h"

#include <math.h>

#ifndef DATA_PATH
    #define DATA_PATH   "../../dat/"
#endif

BEGIN_MESSAGE_MAP(CElTestApp, CWinApp)
	//{{AFX_MSG_MAP(CElTestApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

CElTestApp::CElTestApp()
{
}

CElTestApp theApp;

BOOL CElTestApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif

    // init electronics
    if(!m_texo.init(DATA_PATH, 2, 2, 0, 0, 0))
    {
        AfxMessageBox(_T("Error initializing electronics"), MB_ICONERROR, 0);
        return FALSE;
    }

    // initialize global parameters
    m_texo.setPower(15, 15, 15);
    m_texo.addTGC(0.80);    

    CElTestDlg dlg(&m_texo);
	
    m_pMainWnd = &dlg;
	dlg.DoModal();

    m_texo.shutdown();
    
	return FALSE;
}

bool CElTestApp::AddText(CEdit * e, CString s)
{
	if(!e)
		return false;
	
	// get the string content
	TCHAR *buf = s.GetBuffer(255);

	// append it in the CEdit
	e->SetSel(32767, 32767);
	e->ReplaceSel(buf, s.GetLength());
	
	// release the string buffer
	s.ReleaseBuffer();

    return true;
}

bool CElTestApp::CreateSequence()
{
     // tell program to initialize for new sequence
    if(!m_texo.beginSequence())
        return false;

    int i, lineSize;
    texoTransmitParams tx;
    texoReceiveParams rx;

    tx.centerElement = 0;
    tx.aperture = 0;    
    tx.focusDistance = 50000;
    tx.angle = 0;
    tx.frequency = m_texo.getProbeCenterFreq();
    strcpy(tx.pulseShape, "+-");
    tx.speedOfSound = 1540;
    tx.useManualDelays = false;
    tx.tableIndex = -1;
    tx.useDeadElements = false;

    rx.centerElement = 0;
    rx.aperture = NUMCHANNELS;
    rx.angle = 0;
    rx.maxApertureDepth = 30000;
    rx.acquisitionDepth = 20000;
    rx.saveDelay = 0;
    rx.speedOfSound = 1540;
    rx.channelMask[0] = rx.channelMask[1] = 0xFFFFFFFF;
    rx.applyFocus = false;
    rx.useManualDelays = false;
    rx.tableIndex = -1;    
    rx.customLineDuration = 0;
    rx.decimation = 1;
    rx.lgcValue = 0;
    rx.tgcSel = 0;

    for(i = 0; i < m_texo.getProbeNumElements(); i++)
    {
        tx.centerElement = (i * 10) + 5;
        rx.centerElement = (i * 10) + 5;

        rx.channelMask[0] = 1 << (i % NUMCHANNELS);

        lineSize = m_texo.addLine(rfData, tx, rx);

        if(lineSize == -1)
            return false;
    }

    // tell program to finish sequence
    if(m_texo.endSequence() == -1)
        return false;
    
    return true;
}

bool CElTestApp::AnalyzeData(double * elementData)
{
    int i, j, numFrames, frameSize, lineSize, numSamples;
    unsigned char * begin;
    signed short * data;
    double avg, avgs[MAXELEMENTS];
    int numElements = m_texo.getProbeNumElements();
        
    numFrames = m_texo.getCollectedFrameCount();
    frameSize = m_texo.getFrameSize();

    lineSize = (frameSize - 4) / numElements;
    numSamples = lineSize / 2;

    if(numFrames < 1)
    {
        AfxMessageBox(_T("No frames were acquired"), MB_ICONERROR, 0);
        return false;
    }

    begin = m_texo.getCineStart();
    begin += 4;
    
    for(int f = 0; f < numFrames; f++)
    {
        data = (signed short*)begin;
        begin += frameSize;

        // calculate average of each element
        for(i = 0; i < numElements; i++)
        {
            avg = 0;                
            for(j = 0; j < numSamples; j++)
                avg += abs(*data++);

            if(f > 0)
                avgs[i] = (avgs[i] + (avg / numSamples)) / 2;
            else
                avgs[i] = (avg / numSamples);
        }
    }

    // calculate global average of all elements combined
    avg = 0;
    for(i = 0; i < numElements; i++)
        avg += avgs[i];
    avg /= numElements;
    
    // assign a percentage of the global average for each element
    for(i = 0; i < numElements; i++)
        elementData[i] = avgs[i] / avg;
            
    return true;
}

void CElTestApp::LoadProbes(CDialog * dlg)
{
    char name[80];
    int i;

    for(i = 0; i < 3; i++)
    {
        if(m_texo.getProbeName(i, name, 80))    
        {
            dlg->GetDlgItem(IDC_PROBE1 + i)->SetWindowText(STRCVT::CH2CS(name));
            dlg->GetDlgItem(IDC_PROBE1 + i)->EnableWindow(TRUE);
        }
        else
        {
            dlg->GetDlgItem(IDC_PROBE1 + i)->SetWindowText(_T("N/A"));
            dlg->GetDlgItem(IDC_PROBE1 + i)->EnableWindow(FALSE);
        }
    }
}

HBITMAP CElTestApp::GetRotatedBitmap( CDC * sourceDC, int srcW, int srcH, float radians, COLORREF clrBack )
{    
	CDC destDC;	
	destDC.CreateCompatibleDC( NULL );
	
	float cosine = (float)cos(radians);
	float sine = (float)sin(radians);

	// Compute dimensions of the resulting bitmap
	// First get the coordinates of the 3 corners other than origin
	int x1 = (int)(-srcH * sine);
	int y1 = (int)(srcH * cosine);
	int x2 = (int)(srcW * cosine - srcH * sine);
	int y2 = (int)(srcH * cosine + srcW * sine);
	int x3 = (int)(srcW * cosine);
	int y3 = (int)(srcW * sine);

	int minx = min(0,min(x1, min(x2,x3)));
	int miny = min(0,min(y1, min(y2,y3)));
	int maxx = max(x1, max(x2,x3));
	int maxy = max(y1, max(y2,y3));

	int w = maxx - minx;
	int h = maxy - miny;

	// Create a bitmap to hold the result
	HBITMAP hbmResult = ::CreateCompatibleBitmap(CClientDC(NULL), w, h);
        
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject( destDC.m_hDC, hbmResult );

	// Draw the background color before we change mapping mode
	HBRUSH hbrBack = CreateSolidBrush( clrBack );
	HBRUSH hbrOld = (HBRUSH)::SelectObject( destDC.m_hDC, hbrBack );
	destDC.PatBlt( 0, 0, w, h, PATCOPY );
	::DeleteObject( ::SelectObject( destDC.m_hDC, hbrOld ) );

	// Set mapping mode so that +ve y axis is upwords
	/*sourceDC.SetMapMode(MM_ISOTROPIC);
	sourceDC.SetWindowExt(1,1);
	sourceDC.SetViewportExt(1,-1);
	sourceDC.SetViewportOrg(0, bm.bmHeight-1);*/

	destDC.SetMapMode(MM_ISOTROPIC);
	destDC.SetWindowExt(1,1);
	destDC.SetViewportExt(1,-1);
	destDC.SetWindowOrg(minx, maxy);

	// Now do the actual rotating - a pixel at a time
	// Computing the destination point for each source point
	// will leave a few pixels that do not get covered
	// So we use a reverse transform - e.i. compute the source point
	// for each destination point

	for( int y = miny; y < maxy; y++ )
	{
		for( int x = minx; x < maxx; x++ )
		{
			int sourcex = (int)(x*cosine + y*sine);
			int sourcey = (int)(y*cosine - x*sine);
			if( sourcex >= 0 && sourcex < srcW && sourcey >= 0
					&& sourcey < srcH )
            {
                COLORREF  crf = sourceDC->GetPixel(sourcex,sourcey);

				//destDC.SetPixel(x,y,sourceDC.GetPixel(sourcex,sourcey));
                destDC.SetPixel(x,y, crf);
            }
		}
	}

	// Restore DCs	
	::SelectObject( destDC.m_hDC, hbmOldDest );

	return hbmResult;
}