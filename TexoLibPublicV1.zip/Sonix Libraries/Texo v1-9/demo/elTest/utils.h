#ifndef UTILS_H
#define UTILS_H

namespace STRCVT
{
    CString CH2CS(char *);
    std::string CS2STL(CString);
    CString STL2CS(std::string);
};

#endif